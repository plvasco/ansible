# AMI Cleanup

This README file shows how to run the ami_cleanup script to delete AMIs based on DeleteAfter Tag

## Requirements
-	IAM Permissions: These IAM policy actions are required in order to run this script. This is an example policy you can attach to a user to give them the proper IAM authorization.

	    {
                "Version": "2010-10-10",
	        "Statement": [
		    {
		        "Effect": "Allow",
	                "Action": [
		            "ec2:DescribeImages",
					"ec2:DeregisterImage",
					"ec2:DeleteSnapshot",
					"ec2:DescribeImageAttribute"
		        ],
		        "Resource": "*"
		    }
		]
	    } 

-   Set python path and configure AWS CLI

## Delete AMIs based on DeleteBefore Tag
~~~
Usage: ami_cleanup.py [-h]
            [-key CUSTOMER_MASTER_KEY]
            [-region REGION] 
            [-p PROFILE]
            [-key_id AWS_ACCESS_KEY_ID]
            [-secret_key AWS_SECRET_ACCESS_KEY]

All the above options are optional.

optional arguments:
  -h, --help            show this help message and exit
  -key CUSTOMER_MASTER_KEY, --customer_master_key CUSTOMER_MASTER_KEY
                        Customer master key
  -region REGION, --region REGION
                        AWS region
  -p PROFILE, --profile PROFILE
                        Profile to use
  -key_id AWS_ACCESS_KEY_ID, --aws_access_key_id AWS_ACCESS_KEY_ID
                        AWS Access Key ID to use
  -secret_key AWS_SECRET_ACCESS_KEY, --aws_secret_access_key AWS_SECRET_ACCESS_KEY
                        AWS Secret Access Key to use

~~~

## Examples
- Example 1: To delete all AMIs with default AWS CLI profile:
~~~
python ami_cleanup.py
~~~
- Example 2: To delete all AMIs with with AWS CLI profile userx:
~~~
python ami_cleanup.py -p userx
~~~
- Example 3: To delete all AMIs in region us-east-1 with AWS Access Key ID yyy and Secret Access Key zzz:
~~~
python ami_cleanup.py --region us-east-1 --aws_access_key_id yyy --aws_secret_access_key zzz
~~~
