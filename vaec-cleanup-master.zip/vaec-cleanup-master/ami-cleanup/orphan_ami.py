import sys
import boto3
import argparse
from datetime import datetime

#python3 orphan_ami.py --account-id 477194928391 --role vaec-authorizer-role --region us-gov-west-1

parser = argparse.ArgumentParser(description='Identify orphan AMIs')
parser.add_argument('--account-id', dest='remote_account_id', required=True, help='AWS remote Account ID')
parser.add_argument('--role', dest='remote_role', required=True, help='IAM authorizer role from remote AWS accountD')
parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
args = parser.parse_args()

def main():
    """ Set up AWS Session + Client + Resources """
    try:
        sts_client = boto3.client('sts', region_name = args.region_id)
        assumedRoleObject = sts_client.assume_role(
                RoleArn=("arn:aws-us-gov:iam::%s:role/%s" %(args.remote_account_id, args.remote_role)), 
                RoleSessionName="ResourceCleanup")
        credentials = assumedRoleObject['Credentials']

        r_ec2_client = boto3.client('ec2',
            aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'],
            region_name = args.region_id)
        
        all_amis = set(get_all_amis(r_ec2_client, args.remote_account_id))
        print("All AMIs: %d %s \n------\n" % (len(all_amis), all_amis) )

        all_used = set(get_used_amis_by_instances(r_ec2_client,args.remote_account_id))
        print("Used AMIs: %d %s \n------\n" % (len(all_used), all_used) )

        orphan_amis = all_amis - all_used 
        print("Orphan AMIs: %d %s \n------\n" % (len(orphan_amis), orphan_amis) )

        all_amis_not_owned = all_used - all_amis 
        print("AMIs not owned: %d %s \n------\n" % (len(all_amis_not_owned), all_amis_not_owned) )

    except Exception as ex:
        print(str(ex))
        raise(ex)

# https://stackoverflow.com/questions/42784704/get-unused-amis-using-boto3-witn-aws-lambda

def get_used_amis_by_instances(ec, ownerid):
    response = ec.describe_instances(
        Filters=[
            { 'Name': 'owner-id', 'Values': [ownerid] },
        ]
    )
    amis_used_list = []
    for reservation in response['Reservations']:
        for ec2 in reservation['Instances']:
            amis_used_list = amis_used_list + [ec2['ImageId']]
    return amis_used_list

  
def get_all_amis(ec, ownerid):
    response = ec.describe_images(
        Filters=[
            { 'Name': 'owner-id', 'Values': [ownerid] },
        ]
    )
    all_amis = []
    for ami in response['Images']:
        all_amis = all_amis + [ami['ImageId']]
    return all_amis

if __name__ == "__main__":
  main()

