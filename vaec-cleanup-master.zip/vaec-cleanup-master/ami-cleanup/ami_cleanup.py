import sys
import boto3
import argparse
from datetime import datetime

keyForTagDeleteAfterDate = "DeleteAfterDate"
today = datetime.today()

def main(argv):
    parser = argparse.ArgumentParser(description='Delete EC2 AMIs based on DeleteAfterDate tag')
    parser.add_argument('-r', '--region', help='AWS region', required=False)
    parser.add_argument('-p', '--profile', help='Profile to use', required=False)
    parser.add_argument('-key_id', '--aws_access_key_id', help='AWS Access Key ID to use', required=False)
    parser.add_argument('-secret_key', '--aws_secret_access_key', help='AWS Secret Access Key to use', required=False)
    args = parser.parse_args()

    """ Set up AWS Session + Client + Resources """
    if args.profile:
        # Create custom session
        print('Using profile {}'.format(args.profile))
        session = boto3.session.Session(profile_name=args.profile)
    else:
        # Use default session
        session = boto3.session.Session(region_name=args.region,
                                        aws_access_key_id=args.aws_access_key_id,
                                        aws_secret_access_key=args.aws_secret_access_key)

    ec = session.client('ec2')
    images_response= ec.describe_images(Filters=[{'Name': 'tag-key', 'Values': [keyForTagDeleteAfterDate]}])

    for image in images_response['Images']:
        try:
            for tag in image['Tags']:
                if tag['Key'] == keyForTagDeleteAfterDate:
                    try:
                        del_date=int(t['Value'])
                    except:
                        del_date=date_today+1

                    if (del_date < date_today):
                        ec.deregister_image(ImageId=image['ImageId'])
                        print('%d deregistered %s (DeleteAfter=%d)' % (date_today, image['ImageId'], del_date))

                        ## Make this part of snapshot cleanup ?
                        for map in image['BlockDeviceMappings']:
                            ec.delete_snapshot(SnapshotId=map['Ebs']['SnapshotId'])
                            print('%d deleted %s (DeleteAfter=%d)' % (date_today, map['Ebs']['SnapshotId'], del_date))
                        except Exception as ex:
                            print(str(ex))
                    else:
                        print('%d skipping %s (DeleteAfter=%d)' % (date_today, image['ImageId'], del_date))
                        break
        except Exception as ex:
            print(str(ex))

if __name__ == '__main__':
    main(sys.argv)
