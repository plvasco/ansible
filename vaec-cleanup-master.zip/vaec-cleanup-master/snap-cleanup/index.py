import boto3
import botocore
import logging
import threading
import time
import datetime
from datetime import date, timedelta
from botocore.exceptions import ClientError

#GLOBAL VARIABLES
logger = logging.getLogger()
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)
snapshot_dict={}
image_snapshots=[]

def get_snapshot_vol_dict(thread_name,ec2):
        client = boto3.client('sts')
        logger.info(thread_name + ": Getting Account ID")
        account_id = client.get_caller_identity()["Account"]
        logger.info(thread_name + ": Listing all snapshots")
        paginator = ec2.get_paginator('describe_snapshots')
        filters = [{'Name': 'status'  , 'Values': ['completed']}, {'Name': 'owner-id', 'Values': [account_id]}]
        operation_parameters = {'Filters': filters,}
        # Unpack operation parameters with the filters
        page_iterator = paginator.paginate(**operation_parameters)
        for page in page_iterator:
                for snapshot in page['Snapshots']:
                        has_tag=0
                        for tag in snapshot['Tags']:
                                if tag['Key'] == "DeleteAfterDate":
                                        has_tag=1
                                        deleteafterstring=tag['Value']
                                        try:
                                                datetime.datetime.strptime(deleteafterstring, '%Y%m%d')
                                        except ValueError:
                                                logger.error("Incorrect data format, should be YYYYMMDD updating")
                                                snapshot_dict[snapshot['SnapshotId']] = snapshot['VolumeId']
                        if has_tag == 0:
                                snapshot_dict[snapshot['SnapshotId']] = snapshot['VolumeId']
        logger.info(thread_name + ": Returning list of all snapshots")

def get_ami_snapshot_list(thread_name,ec2):
        client = boto3.client('sts')
        logger.info(thread_name + ": Getting Account ID")
        account_id = client.get_caller_identity()["Account"]
        logger.info(thread_name + ": Listing all snapshots that are apart of AMIs")
        images_response=ec2.describe_images(Filters=[{'Name': 'owner-id', 'Values': [account_id]}])
        for image in images_response['Images']:
                for blockdevice in image['BlockDeviceMappings']:
                        if "dev" in blockdevice['DeviceName']:
                                if "SnapshotId" in blockdevice['Ebs']:
                                        image_snapshots.append(blockdevice['Ebs']['SnapshotId'])
        logger.info(thread_name + ": Returning list of all snapshots that are apart of amis")

def is_orphan(thread_name,ec2,vol_id,snap):
        paginator = ec2.get_paginator('describe_volumes')
        filters = [{'Name': 'volume-id'  , 'Values': [vol_id]}]
        operation_parameters = {'Filters': filters,}
        page_iterator = paginator.paginate(**operation_parameters)
        logger.info(thread_name + ": Checking if " + snap + " is orphaned")
        for page in page_iterator:
                for volume in page['Volumes']:
                        if volume['VolumeId'] == vol_id:
                                return False
        logger.info(thread_name + ": Tagging " + snap + " as orphan")
        futuredate=(date.today()+timedelta(days=90)).strftime('%Y%m%d')
        response=ec2.create_tags(Resources=[snap],Tags=[{'Key':'DeleteAfterDate','Value': futuredate},])
        logger.info(thread_name + ": Response of tagging: " + str(response))

def lambda_handler(event, context):
        non_ami_snaps={}
        try:
                client_config = botocore.config.Config(max_pool_connections=100,)
                ec2=boto3.client('ec2', config=client_config)
        except ClientError as e:
                logger.error(e)
        threads = list()
        logger.info("Main       : create and start thread 0.")
        snap_thread = threading.Thread(target=get_snapshot_vol_dict, args=("thread-0",ec2,))
        threads.append(snap_thread)
        logger.info("Main       : create and start thread 1.")
        ami_thread = threading.Thread(target=get_ami_snapshot_list, args=("thread-1",ec2,))
        threads.append(ami_thread)
        snap_thread.start()
        ami_thread.start()
        for index, thread in enumerate(threads):
                logger.info("Main    : before joining thread %d.", index)
                thread.join()
                logger.info("Main    : thread %d done", index)
        for snap in snapshot_dict:
                if snap in image_snapshots:
                        continue
                else:
                        non_ami_snaps[snap] = snapshot_dict[snap]
        threads = list()
        index=0
        for snap in non_ami_snaps:
                logger.info("Main       : create and start thread %d.", index)
                thread_name="thread-" + str(index)
                thread = threading.Thread(target=is_orphan, args=(thread_name,ec2,non_ami_snaps[snap],snap,))
                threads.append(thread)
                thread.start()
                index=index+1
        for index, thread in enumerate(threads):
                logging.info("Main      : before joining thread %d.", index)
                thread.join()
                logging.info("Main      : thread %d done", index)

if __name__ == "__main__":
        def main():
                _start = time.time()
                lambda_handler("", "")
                print("Thread execution time: %s seconds" % (time.time() - _start))
        main()
