import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger()
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 orphan_sg_cleanup.py
#python3 orphan_sg_cleanup.py --account-id all --region us-gov-west-1
#python3 orphan_sg_cleanup.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='Cleanup orphaned SGs')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
args = parser.parse_args()

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)
        sessionmod.iterate_orgs_accounts(fn_cleanup_orphan_sg, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_cleanup_orphan_sg(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2c = session_assumed.client('ec2')


        all_netifs = rec2c.describe_network_interfaces()
        all_sg = rec2c.describe_security_groups()

        netifs_sg_set = set()
        sg_set = set()

        for netif in all_netifs["NetworkInterfaces"]:
          for sg in netif["Groups"]:
              netifs_sg_set.add(sg["GroupId"])

        for sg in all_sg["SecurityGroups"]:
            if not sg["GroupName"] == 'default':
                sg_set.add(sg ["GroupId"])

        orphan_sgs = sg_set - netifs_sg_set

        logger.info("%s %s Orphan SGs: %d %s \n-----\n" % (region, acctid, len(orphan_sgs), orphan_sgs))

        if not args.to_dryrun:
            for osg in orphan_sgs:
              try:
                logger.info('%s %s Deleting orphan SG %s' %(region, acctid, osg))
                rec2c.delete_security_group(GroupId=osg)
              except Exception as ex:
                logger.error(ex)

    except Exception as ex:
        logger.error(ex)



# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
