import sys
import boto3
import argparse
from datetime import datetime

#python3 ovol.py --account-id 477194928391 --role vaec-authorizer-role --region us-gov-west-1

parser = argparse.ArgumentParser(description='Identify orphaned Volumes')
parser.add_argument('--account-id', dest='remote_account_id', required=True, help='AWS remote Account ID')
parser.add_argument('--role', dest='remote_role', required=True, help='IAM authorizer role from remote AWS accountD')
parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
args = parser.parse_args()

def main():
    """ Set up AWS Session + Client + Resources """
    try:
        sts_client = boto3.client('sts', region_name = args.region_id)
        assumedRoleObject = sts_client.assume_role(
                RoleArn=("arn:aws-us-gov:iam::%s:role/%s" %(args.remote_account_id, args.remote_role)), 
                RoleSessionName="IdUnusedAmis")
        credentials = assumedRoleObject['Credentials']

        r_ec2_client = boto3.client('ec2',
            aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'],
            region_name = args.region_id)
        
        orphaned_volume_list = get_orphaned_volumes(r_ec2_client)
        print("Orphaned Volumes: %d %s \n------\n" % (len(orphaned_volume_list), orphaned_volume_list) )

    except Exception as ex:
        print(str(ex))
        raise(ex)

def get_orphaned_volumes(ec):
    # Report header.
    report = "The Following Volumes were found as Orphaned: \n"
    volume_count = 0
    volume_list = []
    no_iops = False

    # Start a pagination object for the describe_volumes
    paginator = ec.get_paginator('describe_volumes')

    # Create filter for only available therefore deemed 'orphaned' volumes.
    filters = [
        {'Name': 'status'  , 'Values': ['available']}
    ]
    operation_parameters = {
        'Filters': filters,
    }

    # Unpack operation parameters with the filters
    page_iterator = paginator.paginate(**operation_parameters)

    # Loop each page of results
    for page in page_iterator:
        # Loop each volume in each page.
        for volume in page['Volumes']:
            if volume['State'] == 'available':
                # Register with the counter
                volume_count = volume_count + 1
                volume_list = volume_list + [volume['VolumeId']]
                # Report addition
                try:
                    volume['Iops']
                except KeyError:
                    no_iops = True
                    pass
                report = report + "VolumeId: {} | State: {} | Size: {} | VolumeType: {} | Iops: {} | CreateTime: {}\n".format(
                    str(volume['VolumeId']),
                    str(volume['State']),
                    str(volume['Size']),
                    str(volume['VolumeType']),
                    '' if no_iops else str(volume['Iops']),
                    str(volume['CreateTime'])
                )
                # Take some action?
                # ec.delete_volume(
                #     VolumeId=volume['VolumeId']
                # )

    if volume_count == 0:
        print("Nothing to report")
    else:
        print(report)

    return volume_list

if __name__ == "__main__":
  main()
