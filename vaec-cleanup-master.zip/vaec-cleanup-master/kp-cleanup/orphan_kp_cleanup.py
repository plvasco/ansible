import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger()
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 orphan_kp_cleanup.py
#python3 orphan_kp_cleanup.py --account-id all --region us-gov-west-1
#python3 orphan_kp_cleanup.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='Cleanup orphaned ec2 keypairs')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--role', dest='remote_role', default='vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
args = parser.parse_args()

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)
        session_name=__file__.split('.py')[0].replace('/', '_')
        sessionmod.iterate_accounts_regions(cleanup_orphan_kp, args.remote_account_id, args.region_id, args.remote_role, session_name)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def cleanup_orphan_kp(acctid, region, role, session_name):
    try:
        session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(acctid, role)),
                        session_name, region)
        rec2c = session_assumed.client('ec2')

        all_ec2 = rec2c.describe_instances()
        ec2_kp_set = set()

        for reservation in all_ec2['Reservations']:
            for ec2inst in reservation['Instances']:
                if 'KeyName' in ec2inst:
                    ec2_kp_set.add(ec2inst['KeyName'])
                else:
                    logger.info("%s %s %s no keypair" %(region, acctid, ec2inst['InstanceId']))

        all_kp = rec2c.describe_key_pairs()
        kp_set = set()
        for kp in all_kp['KeyPairs']:
           kp_set.add(kp['KeyName'])

        orphan_kps = kp_set - ec2_kp_set

        logger.info("%s %s Orphan keypairs: %d %s \n-----\n" %(region, acctid, len(orphan_kps), orphan_kps))

        if not args.to_dryrun:
            for okp in orphan_kps:
              try:
                logger.info('%s %s Deleting orphan keypair %s' %(region, acctid, okp))
                rec2c.delete_key_pair(KeyName=okp)
              except Exception as ex:
                logger.error(ex)

    except Exception as ex:
        logger.error(ex)



# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
