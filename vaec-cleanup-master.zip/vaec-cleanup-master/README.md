# VAEC Cleanup

This solution tags and removes unused resources.


## EC2 AMI cleanup
### Policy

Following cleanup applies to AMIs deployed by VAEC to all AWS accounts (Generally with AMI Name starting with "vaec-", with a few exceptions for older AMIs)

AMI with a Creation Date is older than Today - 180 days:
- Tag AMI + snapshot with key= DeleteAfter value =Today + 7 days

AMI with a Creation Date is older than Today - 90 days:
- Verify that updated AMI is available in the account
- If AMI does not have a tag with key=DeleteAfterDate, tag AMI with key=DeleteAfterDate value= today + 7 days

Cleanup periodically based on DeleteAfterDate

### Implementation
#### Verify and tag AMIs for cleanup:
- if tag with key=_DeleteAfterDate_ exists:
    - If tag value is invalid, DeleteAfterDate= today + 60 days
    
- if tag with key=_DeleteAfterDate_ does not exists:
    - If AMI is unused, tag AMI with DeleteAfterDate= today + 60 days

#### Perform cleanup:
- if tag with key=_DeleteAfterDate_ exists, and tag value is valid:
    - If tag date value < date_today:
      - Deregister AMI
      - Delete mapped snapshots
 
## EC2 Orphaned Volume cleanup
### Policy
- If an EC2 volume in not attached to EC2 instance, the volume was created more than 90 days ago and does not have a tag with key=DeleteAfterDate:
  - Tag Volume with DeleteAfterDate= today + 7 days
  - Create volume snapshot, tag snapshot with DeleteAfterDate= today + 90 days
  - Tag any existing snapshots for that volume with DeleteAfterDate= today + 90 days 
  - Cleanup volume periodically based on DeleteAfterDate
  - Cleanup snapshot periodically based on DeleteAfterDate

### Implementation
#### Verify and tag Volumes for cleanup:
- if key=DeleteAfterDate tag exists:
    - If tag value is invalid, re-tag DeleteAfterDate= today + 7 days
    
- If `DeleteAfterDate` tag does not exist:
    - If volume _CreateTime_ was more than 90 days ago:
      - Tag volume with DeleteAfterDate= today + 7 days
      - Create volume snapshot, and tag snapshot with DeleteAfterDate= today + 90 days

#### Perform cleanup:
**Volume cleanup**
- if key=DeleteAfterDate tag exists, and tag value is valid:
        - If tage date value < date_today:
            - Delete volume

**Orphaned volume snapshot cleanup**
- `This is already handled by vaec-snapshot`
- if key=DeleteAfterDate tag exists, and tag value is valid:
        - If tage date value < date_today:
            - Deregister AMI
            - Delete mapped snapshots


## EC2 snapshot cleanup
### Policy
- If snapshot was created more than 3 months ago, and does not have a tag with key=DeleteAfterDate:
    - If snapshot is associated with existing AMI, ignore for now
    - If snapshot is associated with existing EC2 volume, ignore for now
    - Tag orphaned snapshot with DeleteAfterDate= today + 90 days
- Cleanup periodically based on DeleteAfterDate

### Implementation
#### Verify and tag snapshots for cleanup:
- if tag with key=_DeleteAfterDate_ exists:
    - If tag value is invalid, re-tag DeleteAfterDate= today + 180 days
    
- if tag with key=_DeleteAfterDate_ does not exists:
    - If snapshot is associated with existing AMI, ignore for now
    - If snapshot is associated with existing EC2 volume, ignore for now
    - Tag snapshot with DeleteAfterDate= today + 90 days

#### Perform cleanup:
- `This is already handled by vaec-snapshot`
- if tag with key=_DeleteAfterDate_ exists, and tag value is valid:
    - If tag date value < date_today:
      - Delete snapshot
 
 
