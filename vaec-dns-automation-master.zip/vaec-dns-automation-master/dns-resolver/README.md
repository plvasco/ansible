# VAEC DNS Resolver

## Outbound resolver update 1/18/2022 VAEC-22038

- AWS Case IDs 9501216441 and 9502632151 (Jan 2022)
- Outbound resolver IPs increased from 6 to 20 in both regions. **CAUTION: AWS Console for DNS Resolver only shows 10 IPs. Use CLI to check the IPs.**
- CloudFormation currently limits IPs to max 6. IPs increased in _core-gov-internal_ in both regions with CLI command as follows:

us-gov-east-1:
~~~
aws route53resolver associate-resolver-endpoint-ip-address --resolver-endpoint-id rslvr-out-174590ddf02547268 --ip-address="SubnetId=subnet-09b23568de9034e6c" --region us-gov-east-1
aws route53resolver associate-resolver-endpoint-ip-address --resolver-endpoint-id rslvr-out-174590ddf02547268 --ip-address="SubnetId=subnet-037d7b87a9d58a99f" --region us-gov-east-1
aws route53resolver get-resolver-endpoint --resolver-endpoint-id rslvr-out-174590ddf02547268 --region us-gov-east-1
aws route53resolver list-resolver-endpoint-ip-addresses --resolver-endpoint-id rslvr-out-174590ddf02547268 --region us-gov-east-1
~~~
us-gov-west-1:
~~~
aws route53resolver associate-resolver-endpoint-ip-address --resolver-endpoint-id rslvr-out-92223d9f4f30400d9 --ip-address="SubnetId=subnet-57a48832"
aws route53resolver associate-resolver-endpoint-ip-address --resolver-endpoint-id rslvr-out-92223d9f4f30400d9 --ip-address="SubnetId=subnet-da2e7cad"
aws route53resolver get-resolver-endpoint --resolver-endpoint-id  rslvr-out-92223d9f4f30400d9
aws route53resolver list-resolver-endpoint-ip-addresses --resolver-endpoint-id rslvr-out-92223d9f4f30400d9
~~~
- Once CloudFormation supports >6 IPs, each _vaec-dns-resolver.yml_ stack needs to be updated to reflect actual # IPs.


## Implementation for each VPC

DNS for each VPC provisioned by VAEC is handled by Route53 Resolver:

- VPC has a DHCPOptionSet that points to _AmazonProvidedDNS_.
  - The _/etc/resolv.conf_ will reflect VPC DNS IP address that vares by VPC.
  - It is not necessary to specify IP address of DNS servers or _169.254.169.253_ in _/etc/resolv.conf_ and in fact should be avoided.

- A shared Resolver Rule _core-ad-vagov-outbound-rule_ is associated with each VPC.
  - AWS VPC DNS can resolve _va.gov_ forward DNS.

- Using VPC DNS with Route53 Resolver for resolving _va.gov_ has following advantages:
  - Better reliability since VPC or servers are not pointing to IP address of specific DNS servers
  - VAEC can quickly update Resolver Rule target DNS IP addresses if needed for maintenance purposes (or if DNS server has issues) without impacting client servers of VPCs
   - Using VPC DNS also allows project teams to use Route53 private hosted zone in GovCloud if needed.
   - Some endpoints such as EFS only resolve using VPC DNS

- CloudFormation:
  - [us-gov-west-1/vaec-dns-resolver.yml](us-gov-west-1/vaec-dns-resolver.yml)
  - [us-gov-east-1/vaec-dns-resolver.yml](us-gov-east-1/vaec-dns-resolver.yml)

## Design

![dns-resolver](dns-resolver.png)


###  DNS Resolver Rule Target IPs

Resolver Rule Target IPs:

| Resolver Rule  | us-gov-east-1 | us-gov-west-1 |
| --- | --- | --- |
| core-ad-vagov-outbound-rule & core-ad-vagov-reverse-outbound-rule | 10.248.5.4, 10.248.5.68 | 10.247.42.69, 10.247.42.135, 10.247.42.78, 10.247.42.142, 10.247.42.79, 10.247.42.143 | 


#### [Case 7227205221] DNS Resolver Rule Target IPs

We have a specific question about DNS Resolver Rule Target IPs, documentation states the following:

_When a DNS query matches the name that you specify in Domain name, the outbound endpoint forwards the query to the IP addresses that you specify here. These are typically the IP addresses for DNS resolvers on your network._

When multiple Target IPs are provided for RuleType=FORWARD, exactly how does query forwarding work? 
- Is there a specific order in which Target IPs are selected (similar to /etc/resolv.conf) 
- OR is one Target IP selected at random from the list?
- OR is the query forwarded to all Target IPs, and the first response is selected?
- OR something else?

> Greetings from AWS Premium Support.Thanks for writing to us , my name is Shivang from Networking Team and I will be assisting you on this case today.
From the case notes I understand that you have specific query regarding forwarding the DNS queries via the outbound end point to the target IPs .

> I would like to tell you that Route 53 selects the IP at random. It does not forward the query to all the target IPs which aligns to your understanding as mentioned in the 2nd scenario. If one target IP is not operation then it retries another one.

> Elaborating further: When a resource in your VPC makes a request to a Target IP that has failed, the endpoint will retry the request to the target ip as well as to other target IPs that you have configured in your rule. If the other target ip which is responding, the client will get an answer to their DNS query ,the outbound endpoint does not perform any health checks on the Target IPs However in the case of a failure, the request will be tried across the targets you have configured.

### Reverse DNS lookup
- Reverse va.gov DNS lookup using VPC DNS has limitations, so _core-ad-vagov-reverse-outbound-rule_ is not deployed across AWS accounts and VPCs.
- If reverse DNS lookup is required, update VPC DHCP OptionSet to use the region-specific IPs above followed by _AmazonProvidedDNS_.


## Inbound Resolver (Temporary - us-gov-west-1 only)
This is temporary to help with AD DC 42.68 upgrade. The stack [vaec-dns-resolver-inbound.yml](us-gov-west-1/vaec-dns-resolver-inbound.yml) to be executed in us-gov-west-1 in core-gov-internal after the 4.2.68 DC is terminated and IP freed up

| Parameter  | us-gov-east-1 | us-gov-west-1 |
| --- | --- | --- |
| pVpcId     | vpc-05956738f87bde519 | vpc-c255e2a7 |
| pSubnetIds | subnet-01da5190cd10b9c4b,subnet-0ae7b8b288422ce8f | subnet-92ab87f7,subnet-7f2e7c08 |
| pEndPtIps  | 10.248.5.55,10.248.5.115 | **10.247.42.68**,10.247.42.170 |



### CloudWatch Logs Insights
Navigate to CloudWatch Logs -> Insights

#### VPC FlowLogs in AD VPC
The VPC FlowLogs in AD VPC can be analyzed to produce a count of _scrAddr_ IPs that are querying 10.247.42.68 on port 53:
- Navigate to core-gov-internal (348286891446) -> CloudWatch -> Logs -> Insights
- Select Log Group `vaec-flowlog-vpc-c255e2a7`
- Select appropriate time frame, e.g. `1h` for the past hour
- Input the following query:
~~~
filter (@logStream='eni-f561d7ab-all' and dstPort=53 and dstAddr='10.247.42.68')
| stats count(*) by srcAddr
~~~
- Click `Run Query`
- Once query completes, results can be downloaded under Actions -> Download Query Results (CSV)


#### Insights query to evaluate SERVERFAIL and NXDOMAIN
Route53 Resolver Query Log has been configured in core-gov-internal.

- Select Log Group `/vaec/r53-resolver-qlog`
- Input from the following query examples:

~~~
filter rcode = 'SERVFAIL' or rcode='NXDOMAIN' # and query_name =~ 'eav.va.gov'
| stats count(*) by rcode, srcaddr, query_name

filter query_name =~ 'eav.va.gov'
| stats count(*) by rcode, srcaddr, query_name

fields @message 
parse @message '"rcode":"*"' as rcode
| parse @message '"srcaddr":"*"' as srcaddr
| filter rcode == "SERVERFAIL"
| stats count(*) by srcAddr


filter rcode != 'NOERROR' and rcode != 'NXDOMAIN' and rcode != ''
| display rcode, srcaddr, query_name, query_type

filter rcode != 'NOERROR' and rcode != 'NXDOMAIN'
| stats count(*) by srcaddr

filter rcode = 'SERVFAIL'
| display rcode, srcaddr, query_name, query_type

filter rcode = 'SERVFAIL'
| stats count(*) by srcaddr
~~~


## AmazonProvidedDNS resiliency/redundancy

[AWS CASE 12296939311] 3/21/2023

While multiple IPs can be listed in VPC DHCPOptionSet for DNS resolution, AmazonProvidedDNS eventually points to a single IP address for DNS resolution inside VPC. We are looking for documentation on resiliency/redundancy related to AmazonProvidedDNS, esp. since it's a single IP address within a VPC.

The documentation does say the following, but we are looking for more details or insight:

The Route 53 Resolver (also called "Amazon DNS server" or "AmazonProvidedDNS") is a DNS Resolver service which is built into each availability zone within an AWS Region.


**Response**

Thank you for contacting AWS Premium Support. My name is Sean and I will be the Engineer assisting you today.

I understand that you are looking for information about how the AmazonProvidedDNS works, as well as its resiliency. I will be happy to help you with this.

AmazonProvidedDNS is an Amazon Route 53 Resolver server, made available for use in your VPC[1]. While the primary private address of this Resolver is your ‘.2’, or in other words the primary private IPv4 CIDR range of your VPC plus two, the Route 53 Resolver is also located at 169.254.169.253 (IPv4), and fd00:ec2::253 (IPv6). However despite these individual addresses, this Resolver is not an individual instance located within your VPC per se.

This Resolver is protected with a fleet of redundant and highly available DNS servers and related components in the underlying Route 53 infrastructure and built into each availability zone within an AWS Region. If an issue presents with one of the underlying DNS servers in the fleet, Route 53 will simply remove it without disruption to the DNS service and the DNS queries will then be handled by one of the other DNS servers in the fleet, providing a resilient and highly available architecture. We do not provide an SLA regarding the 'AmazonProvidedDNS' so I cannot state that there is 0% risk of failure, however the chance of failure is extremely small and the service is designed for 99.99% availability. 

I hope this information has been helpful. If you have any further questions or concerns, please feel free to reach out to me here and I will be happy to help. 

References:
[1] https://docs.aws.amazon.com/vpc/latest/userguide/vpc-dns.html#AmazonDNS


We value your feedback. Please share your experience by rating this and other correspondences in the AWS Support Center. You can rate a correspondence by selecting the stars in the top right corner of the correspondence.

Best regards,
Sean G.
Amazon Web Services


## Reference
- https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver.html#resolver-overview-forward-vpc-to-network-using-rules
- https://d1.awsstatic.com/whitepapers/hybrid-cloud-dns-options-for-vpc.pdf
