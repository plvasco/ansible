# vaec-dns-automation
Repository for code/scripts to automate DNS Record creation/modification triggered by Service Now Tickets

## VAEC DNS Resolver for AWS
Refer to [dns-resolver](dns-resolver).

## VAEC NLB for AWS
Refer to [dns-nlb](dns-nlb).


## DNS Teams and Zone Management

Various domain controller teams have different responsibilities for the various DNS zones they own for internal VA DNS.

There are about 9 domain controller/active directory teams we're aware of today.

| DNS zone        | ServiceNow Assignment Team            | Email                    |
| -----------     | ------------------------------------- | -------------------------|
| vaec.va.gov     | OIT VAEC Azure GovCloud Tier 1        |                          |
| cem.va.gov      | IO.HBMC.FF.MEMORIAL.SYSTEMS           |                          |
| cem workstations| RD2 CTX QITC                          |                          |
| mdm.va.gov      | IO.SS.FF.ACTIVEDIRECTORY.TEAM8        |                          |
| vba.va.gov      | IO.SS.FO.ActiveDirectory.Team5        |                          |
| zone triage*    | IO.SS.FO.ActiveDirectory.Triage       |                          |
| all new zones*  | NTL SUP DNS / OIT CIS DS Team      | VHAETMADTeam@va.gov      |

`NTL DNS SUP` is the National 24x7 Domain Controller team. They are mainly a short staffed (~10 people) team and to coordinate a DNS cutover not during business hours, you must send them an email to schedule a personnel.

`IO.SS.FO.ActiveDirectory.Triage` is a router group which can facilitate which group your ticket should go to, based on who has access to work in the particular DNS zone.


## DNS response check
Script to check response times from specific DNS IP - check the _real_ number:
~~~
 for ((it=1;it<=15;it++)); do time echo "$(dig @10.247.42.68 google.com | grep "Query time"|sed "s/;; Query time:/=>/")"; sleep 1; done; echo "--";
~~~


## DNS domain for projects

From a technical perspective, assuming AppCode=xxx, preference is to use xxx.vaec.va.gov

Insted of  xxx.vaec.va.gov, using a shared vaec.va.gov or nprod.vaec.va.gov works, however:

-	It is more organized if all project-related entries were under xxx.vaec.va.gov subdomain

- Prevent overloading ofshared domains such as vaec.va.gov

-	Using shared DNS subdomain va.gov / vaec.va.gov / nprod.vaec.va.gov:
      -	Tracing back hostname in shared DNS subdomain back to a specific project requires manual legwork
      -	If the project is retired or has some other changes, the shared DNS entry is unlikely to get cleaned up. In fact entries in shared DNS subdomains seldom get removed because we are not 100% sure.
      -	No self-service or automation for the customer in the future – they won’t get access to shared DNS subdomains.

- If having a shortest possible URL is the goal, wouldn’t a SNOW ticket for Myapp.va.gov be even best (drop the ‘vaec.’)?

- If we are going to be using va.gov / vaec.va.gov / nprod.vaec.va.gov, under what conditions?

- To use DNS subdomains as intended, automate and provide a path to self-service, I would pick _myapp.xxx.vaec.va.gov_

- As we mature, I think we want to get ECSO to weigh in, write down somewhere how DNS is going to be managed and operated, options and conditions.

## Route53 private hosted zones
AWS GovCloud R53 only supports private hosted zones – we don’t prevent teams from setting up private zones (in lieu of private DNS servers, really) such as _example.com_ or even _xxx.vaec.va.gov_.
-	Most VAEC provisioned VPCs use DHCPOptionSet with domain-name-servers = AmazonProvidedDNS; so this allows VPCs to use private hosted zones
-	These zones would be private to a VPC, for ‘internal’ use. These zones have no visibility outside the VPC.
-	If the application has significant connectivity from/to outside the VPC to VA endpoints, then we discourage use of private zone ending in _va.gov_ since it could potentially conflicts with actual VA DNS, and complicates troubleshooting.
