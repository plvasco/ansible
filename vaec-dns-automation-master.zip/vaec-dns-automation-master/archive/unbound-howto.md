# Unbound how-to

~~~
#!/bin/bash
set -x

# Begin Unbound DNS install and config

vpc_dns=169.254.169.253
onprem_domain=va.gov
onprem_dns=10.247.42.101

# Install updates and dependencies
yum install -y unbound bind-utils

# Write Unbound configuration file with values from variables
cp /etc/unbound/unbound.conf /etc/unbound/unbound.conf.bak
touch /etc/unbound/unbound.log
chown unbound:unbound /etc/unbound/unbound.log
cat << EOF | tee /etc/unbound/unbound.conf
server:
        interface: 0.0.0.0
        access-control: 127.0.0.0/8 allow
        access-control: 10.0.0.0/8 allow
	logfile: unbound.log
	do-ip4: yes
        do-udp: yes
        do-tcp: yes
	harden-dnssec-stripped: no
forward-zone:
        name: "."
        forward-addr: ${vpc_dns}
forward-zone:
        name: "${onprem_domain}"
        forward-addr: ${onprem_dns}
EOF

# export AWS_DOMAIN="compute.internal"
# echo "nameserver 127.0.0.1" > /etc/resolv.conf
# echo $(curl http://169.254.169.254/latest/meta-data/local-hostname) | sed s/va.gov/$AWS_REGION\.$AWS_DOMAIN/ > /etc/hostname
# hostname $(echo $(curl http://169.254.169.254/latest/meta-data/local-hostname) | sed s/va.gov/$AWS_REGION\.$AWS_DOMAIN/)

setenforce 0
firewall-cmd --add-service=dns
firewall-cmd --add-service=dns --permanent
setenforce 1

service unbound start
~~~
