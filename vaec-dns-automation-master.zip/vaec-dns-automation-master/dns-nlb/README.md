# DNS NLB

AWS Network Load Balancer in front of VA AD Domain Controllers that also serve as DNS servers

- Pointing DNS queries to NLB IPs instead of directly to AD DCs provides better redundancy, performance, and minimizes/eliminates downtime associated with  maintenance of DCs.
- NLB IPs are used as DNS server IPs for VPCs that require reverse DNS (PTR) lookup.
- Target Group includes multiple AD DCs in order to better spread out the load for performance
- DNS queries can still be pointed directly to AD DCs, so implementing NLB does not impact existing configurations.

