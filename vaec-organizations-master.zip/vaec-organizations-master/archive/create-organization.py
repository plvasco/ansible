#!/usr/bin/python

import argparse
import sys
import boto3
import csv
import logging
import sessionmod
from botocore.exceptions import ClientError

#CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger = logging.getLogger()
logger.addHandler(out_hdlr)
logger.setLevel(logging.INFO)

def main(argv):
    parser = argparse.ArgumentParser(description='Invite Accounts to AWS Organization hosted in core-gov-internal')
    parser.add_argument('--account-list-file', dest='account_list_file', default='VAEC-AWS-Accounts.csv', help='AWS account list CSV file')
    parser.add_argument('--role', dest='remote_role', required=False, default= 'vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
    parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
    args = parser.parse_args()

    org_master_client = boto3.client('organizations')

    try:
	f = open(args.account_list_file,"r")
	accountlistreader = csv.DictReader(f)
    except Exception as ex:
	logger.exception(ex)

    for account_row in accountlistreader:
        if account_row['AccountStatus'].strip().lower() == 'active':
            print("Currently reading: ",account_row['GovCloudNum'])	
            try:
                response = org_master_client.describe_account(AccountId=account_row['GovCloudNum'])

            except org_master_client.exceptions.AccountNotFoundException as ex:
        #		logger.exception(ex)
                logger.info("*** Account Not found Exception ***")
                logger.info("*** Checking for open invitations ***")
                role_arn = ("arn:aws-us-gov:iam::%s:role/%s" %(account_row['GovCloudNum'], args.remote_role))
                session = sessionmod.aws_session(role_arn, 'aws-org', args.region_id)
                remote_org_client = session.client('organizations')
                remote_response = remote_org_client.list_handshakes_for_account(
                            Filter={
                                'ActionType': 'INVITE'
                                }			
                        )

                logger.info("*** Handshake results ***")
                if remote_response['Handshakes'] == []:
                    
                    logger.info("There are no invites")
                    logger.info("Master inviting account")
                            master_response = org_master_client.invite_account_to_organization(
                                Target={
                                        'Id': account_row['GovCloudNum'],
                                        'Type': 'ACCOUNT'
                                        }
                                )
                    logger.info("Remote account accepting invite")	
                    remote_response = remote_org_client.list_handshakes_for_account(
                            Filter={
                                'ActionType': 'INVITE'
                                }			
                        )
                            handshake_id = remote_response['Handshakes'][0]['Id']
                            remote_org_client.accept_handshake(HandshakeId=handshake_id)
                else:
                    
                    logger.info("There are "+str(len(remote_response['Handshakes']))+" invites.")
                    logger.info("Remote account accepting invite")	
                            handshake_id = remote_response['Handshakes'][0]['Id']
                            remote_org_client.accept_handshake(HandshakeId=handshake_id)

                #pass
            else:
                        logger.info("*** Account found displaying results ***")
                    logger.info(response['Account']['Name']+": Status:"+response['Account']['Status'])
                role_arn = ("arn:aws-us-gov:iam::%s:role/%s" %(account_row['GovCloudNum'], args.remote_role))
                session = sessionmod.aws_session(role_arn, 'aws-org', args.region_id)
                remote_org_client = session.client('organizations')
                remote_response = remote_org_client.list_handshakes_for_account(
                            Filter={
                                'ActionType': 'INVITE'
                                }			
                        )
                logger.info("*** Handshake results ***")
                for handshake in remote_response['Handshakes']:
                    logger.info(handshake['State'])
                    if handshake['State'] == 'OPEN':
                        logger.info("*** Declined open handshake ***")
                        remote_org_client.decline_handshake(HandshakeId=handshake['Id'])
                #logger.info(response)

if __name__== "__main__":
  main(sys.argv)
