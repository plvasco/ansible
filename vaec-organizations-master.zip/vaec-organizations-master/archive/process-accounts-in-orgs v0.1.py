import argparse
import sys
import csv
import re
import logging
from xlsx2csv import Xlsx2csv
import boto3
import sessionmod
import orgsmod
import tagmod
from botocore.exceptions import ClientError

#CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger = logging.getLogger()
logger.addHandler(out_hdlr)
logger.setLevel(logging.INFO)

#Example account list
#python3 process-accounts-in-orgs.py --account-list-file acct-list-test.csv
#python3 process-accounts-in-orgs.py --force --nodryrun
#python3 process-accounts-in-orgs.py --account-id 477194928391


parser = argparse.ArgumentParser(description='Iterate account list to add account to AWS Organizations and update tags')
parser.add_argument('--role', dest='remote_role', required=False, default='vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
parser.add_argument('--account-id', dest='remote_account_id', default='', help='Single AWS account Id to be processed in Organizations')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
parser.add_argument('--force', dest='to_enforce', action='store_true', default=False, help='Force applying all desired key-value pairs, Default is disabled')
parser.add_argument('--account-list-file', dest='account_list_file', default='VAEC-AWS-Accounts.xlsx:VAEC-AWS-Accounts', help='AWS account list in csv as fileprefix.csv or Excel as fileprefix.xlsx:sheetname')

args = parser.parse_args()

#---------------------------------------------------------------------------
# Update AWS Organizations based on provided Account List CSV file

def main(argv):
    try:

        if args.remote_account_id and not re.match(r'[0-9]{12}', args.remote_account_id):
            logger.error("account-id: %s invalid in arguments" %(args.remote_account_id))
            return 1

        orgsmod.to_dryrun = args.to_dryrun
        tagmod.to_dryrun = args.to_dryrun
        tagmod.to_enforce = args.to_enforce

        region_id='us-gov-west-1'
        session_name=__file__.split('.py')[0].replace('/', '_')
        lsession_assumed = sessionmod.aws_session(
                    ("arn:aws-us-gov:iam::%s:role/%s" %('348286891446', 'vaec-authorizer-role')),
                    session_name, region_id)
        lorgc = lsession_assumed.client('organizations')

        # Get list of active accounts in AWS Organizations
        active_account_list = sessionmod.get_active_account_list(lorgc)
        
        csvfile=getcsvfile(args.account_list_file)
        if csvfile:
            with open(csvfile, mode='r') as accountlistcsv:
                accountlistreader = csv.DictReader(accountlistcsv)
                for account_row in accountlistreader:
                    to_process=True
                    acct_id=account_row['GovCloudNum']
                    if not acct_id:
                        to_process=False
                    elif not re.match(r'[0-9]{12}', acct_id):
                        logger.error("GovCloudNum: %s invalid in %s" %(acct_id, args.account_list_file))
                        to_process=False
                    elif args.remote_account_id and args.remote_account_id != acct_id:
                            to_process=False

                    if to_process:
                        acct_status=account_row['AccountStatus']
                        logger.info("GovCloudNum: %s AccountStatus: %s -------------" % (acct_id, acct_status))

                        if account_row['AccountStatus'].strip().lower() == 'active':
                            # --- Join account to Organizations 
                            if acct_id not in active_account_list:
                                orgsmod.join_account_to_org(lorgc, acct_id, region_id, args.remote_role)

                            # --- Tag account in Organizations 
                            desired_tag_list=[]
                            if account_row['VAECID']:
                                desired_tag_list.append({'Key':'VAECID', 'Value':account_row['VAECID']})
                            if account_row['ProjectShort']:
                                desired_tag_list.append({'Key':'ProjectShort', 'Value':account_row['ProjectShort']})
                            if account_row['ProjectName']:
                                desired_tag_list.append({'Key':'ProjectName', 'Value':account_row['ProjectName']})
                            if account_row['AppCode']:
                                desired_tag_list.append({'Key':'AppCode', 'Value':account_row['AppCode']})

                            tagmod.tag_orgs_resource(lorgc, acct_id, desired_tag_list)                    

    except ClientError as ex:
        logger.error(ex)
        raise ex

#---------------------------------------------------------------------------
def getcsvfile(fileinfo):
    try:
        csvfile=''
        if '.xlsx:' in fileinfo.lower():
            filename=fileinfo.split(':')[0]
            sheetname=fileinfo.split(':')[1]
            fileprefix=fileinfo.split('.')[0]
 
            # Open xlsx file
            xlsx=Xlsx2csv(filename, outputencoding='utf-8')
            sheetid=xlsx.getSheetIdByName(sheetname)

            if sheetid:
                csvfile='/tmp/' + fileprefix + '_' + sheetname + '.csv'
                xlsx.convert(csvfile, sheetid=sheetid)
            else:
                print("File '%s' Sheet '%s' not found" % (filename,sheetname))
 
        elif '.csv' in fileinfo.lower():
            csvfile=fileinfo
        else:
            print("'%s' has unsupported file type" % (fileinfo))

    except Exception as ex:
        print(ex)
        raise ex

    return csvfile
 
if __name__== "__main__":
  main(sys.argv)
