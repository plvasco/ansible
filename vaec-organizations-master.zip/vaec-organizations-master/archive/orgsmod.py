import boto3
import logging
from botocore.exceptions import ClientError

#CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger = logging.getLogger()
logger.addHandler(out_hdlr)
logger.setLevel(logging.INFO)


#---------------------------------------------------------------------------
def invite_account_to_org(remote_account_id, region_id, remote_role):

    try:
        logger.debug("Remote account: %s Region: %s" % (remote_account_id, region_id))

        org_session_assumed = aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        'organizations_member_add', region_id)
        org_member_client = org_session_assumed.client('organizations')
        
	org_master_client = boto3.client('organizations')
	
	logger.info("Master Account Sending invite to %s" % (remote_account_id))
        response = org_master_client.invite_account_to_organization(
	        Target={
        	        'Id': remote_account_id,
                        'Type': 'ACCOUNT'
                        }
                )

	logger.info("Member account reading invite handshake")
        response = org_member_client.list_handshakes_for_account(
	        Filter={
        	        'ActionType': 'INVITE'
                	}
        )

	logger.info("Member account accepting intivite")
        handshake_id = response['Handshakes'][0]['Id']
        response = org_member_client.accept_handshake(HandshakeId=handshake_id)
	logger.info("Invite Handshake status %s" % (response['Handshake']['State']))
 
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
# Assume remote account role
def aws_session(role_arn, session_name, region):

    try:
        logger.debug("Assuming Cross Account Role: " + role_arn)
        sts_client = boto3.client('sts', region_name=region)
        response = sts_client.assume_role(RoleArn=role_arn, RoleSessionName=session_name)
        session = boto3.Session(
                        aws_access_key_id=response['Credentials']['AccessKeyId'],
                        aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                        aws_session_token=response['Credentials']['SessionToken'],
                        region_name=region)
        return session
    except ClientError as ex:
        logger.exception(ex)
        raise ex