#!/usr/bin/python

import orgsmod
import argparse
import sys

#Example single account
# TODO Turn this into argparse --help output
#python3 .py --region us-gov-east-1 --account-id 477194928391
#python3 .py --region us-gov-east-1 --param-file test.csv  --role vaec-authorizer-role --account-id 477194928391

#---------------------------------------------------------------------------
# Use this for updating parameters for single account

def main(argv):
    parser = argparse.ArgumentParser(description='Add a newly provisioned AWS GovCloud Account to VAEC\'s AWS Organizations')
    parser.add_argument('--role', dest='remote_role', required=False, default= 'vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
    parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='AWS Region identifier')
    parser.add_argument('--account-id', dest='remote_account_id', required=True, help='Remote account ID')
    args = parser.parse_args()

    orgsmod.invite_account_to_org(args.remote_account_id, args.region_id, args.remote_role)

if __name__== "__main__":
  main(sys.argv)
