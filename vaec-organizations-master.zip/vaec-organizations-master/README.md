# vaec-organizations

Making an AWS account member of AWS Organizations allows the following:
- Centrally manage AWS services (e.g. GuardDuty) that are integrated to Organizations
- Automatically share resources (e.g. Transit Gateway, Route53 Resolver Rule for VA DNS) for use by member account
- Auto-deploy permissions via StackSets.
   - VAEC authorizer role for provisioning
   - VA monitoring - Apptio, Netskope, Turbot, AWS Config, Dynatrace, VAEC Centralized Logging, etc.
   - Each service has a separate activation step


## AWS GovCloud Organizations structure

| OU   | ID               | Description
---    | ---              | ---
Root   | r-zf8e           | Organizations root, core-gov-internal
gov-a  | ou-zf8e-wo5icci9 | All GovCloud accounts (Prod ADFS)
gov-b  | ou-zf8e-fdkvwkag | devtest-gov-external, devtest-gov-internal (Dev ADFS)

See [vaec-commercial](https://github.ec.va.gov/AWS/vaec-commercial) for VA AWS Commercial accounts.

## Account list file
By default VAEC Organizations is updated from [vaec-aws-accounts.csv](vaec-aws-accounts.csv). Processing an account also updates tags on an Organizations account entry if the values in the input file differ.

> _vaec-aws-accounts.csv_ is only updated by SMEs after careful QA. Any errors may cause significant downstream rework.

- SME updates the following values to reflect desired account grouping:

Parameter       | Values
 ---            | ---
GovCloudGroup   | noaccess, inactive, closed, gov-a, gov-b, {blank}
CommercialGroup | c-readonly, c-us, c-suspended, {blank}


## Provisining via PowerShell on GFE
Refer to [vaec_process_account.md](vaec_process_account.md) for running provisioning using PowerShell across multiple repositories from GFE.

## Process accounts in GovCloud Organizations

### Process specific accounts
- To process/activate a single account in the list file, add the _--account-id_ argument to the above, for example:
~~~
python process-accounts-in-orgs.py --force --nodryrun --account-id 001234567899,987654321678,913672162035 --action process
~~~

### Process all accounts 

_--action=process_ with _--account-id=all_ Used to process/activate all accounts, and suggested when there are changes across multiple accounts esp. tags

- Execute the following command for `vaec-aws-accounts.csv` in repo folder:

~~~
python process-accounts-in-orgs.py --force --nodryrun --account-id=all --action=process
~~~

- Execute the following command for `.csv` in another folder/filename:

~~~
python process-accounts-in-orgs.py --force --nodryrun --account-list-file {FOLDER}/VAEC-AWS-Accounts.csv --account-id=all --action=process
~~~


### Deactivate / remove account from Organizations - SME only

> Deactivation and removal of account from Organizations is disruptive and can cause outage if dependencies are not addressed. Do not execute without approval and shadow by SME

- SME updates account list file and marks specific account entry as _inactive_ or _closed_
- Deactivation precedes removal and should be executed in order:

- Execute _deactivate_ using _python_execute_ in vaec-organization-pipeline  - this will move account from existing Organizations OU to Root - this will remove the StackSets instances for this account:
~~~
python process-accounts-in-orgs.py --nodryrun --account-id 123456789012 --action deactivate
~~~

(B) Execute _remove_  using _python_execute_ in vaec-organization-pipeline - this will completely remove account from GovCloud AWS Organizations membership:

~~~
python process-accounts-in-orgs.py --nodryrun --account-id 123456789012 --action remove
~~~

> To prevent accidental removal of entire Organizations membership _--account-id = all_ is disabled for _--action=deactivate_ or _--action-remove_


### Note:
- _process-accounts-in-orgs.py_ only processes accounts with GovCloudStatus=`active` in CSV file, rest are ignored
- AWS Account numbers are 12 digits, and Excel treats them as _number_, removes leading zeros. If the AWS Account number begins with leading zeros, then ensure that it includes a single apostrophe `'` before the account number.
  - For example, account number `001234567899` should be input in Excel as `'001234567899`


## Process accounts in Commercial Organizations

Commercial Organizations structure is different from GovCloud. Also Commercial accounts are added to Organizations prior to VAEC getting access. Commercial accounts which are paired with existing GovCloud Accounts are processed as follows:


To configure Organizations membership for VA AWS Commercial account
~~~
python process-commercial-orgs.py --force --nodryrun --account-id 123456789012 --action process
~~~


- SME updates account list file and marks specific account entry as _c-suspended_:

~~~
python process-commercial-orgs.py --nodryrun --account-id 123456789012 --action deactivate
~~~

- Note that unlike GovCloud, VA Commercial accounts are not removed from Organizations


- [update-commercial-alt-contact.py](update-commercial-alt-contact.py) is used to update AWS Commercial accounts alternate contacts. The email address for alternate contacts is derived from the root/primary email:

~~~
python update-commercial-alt-contact.py --nodryrun --account-id 123456789012
~~~


## Retrieving tags from AWS Organizations by AWS account ID
- [get-tags-from-orgs.py](get-tags-from-orgs.py) is utility python program to retrieve tags from AWS Organizations by AWS account ID. This is used in vaec-vpc-tgw-pipeline mainly to retrieve vaec:ProjectShort tag key for VPC creation.

## Get list of accounts in AWS Organizations
- [get-accountids-from-orgs.py](get-accountids-from-orgs.py) is utility python program to retrieve a list of comma-separated AWS account ids tags from AWS Organizations.


## vaec-organizations-pipeline:

All above tasks can also be executed using jenkins [vaec-organization-pipeline](https://pd.ecs.vaec.va.gov/job/vaec-pipelines/job/vaec-organizations-pipeline/)

### Pipeline parameter details

ANSIBLE_TAG | AWS_REGION | ACCOUNTID | COMMAND
 --- | --- | --- | --- |
orgs_process_member | us-gov-west-1 | all, comma-separated list of account-ids |
script_execute | NA | NA |
python_execute | NA | NA |
