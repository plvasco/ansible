import argparse
import boto3
import logging
import sessionmod
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_ssm.py
#python3 vaec_inventory_ssm.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_ssm.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC inventory SSM')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        print("Account,Region,IsManaged,InstanceId,InstanceType,IpAddress,PlatformName,PlatformType,PlatformVersion,AgentType,AgentVersion")
        sessionmod.iterate_orgs_accounts(fn_print_ssm_inventory, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_ssm_inventory(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rssmc = session_assumed.client('ssm', config = boto_config)

        paginator = rssmc.get_paginator('get_ops_summary')
        page_iterator = paginator.paginate(ResultAttributes=[ {'TypeName': 'AWS:EC2InstanceInformation'}])
        for page in page_iterator:
            for iinfo in page['Entities']:
                for c in iinfo['Data']['AWS:EC2InstanceInformation']['Content']:
                    print('%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s' %(acctid, region, 
                                    c['IsManaged'],
                                    c['InstanceId'],
                                    c['InstanceType'],
                                    c['IpAddress'],
                                    c['PlatformName'],
                                    c['PlatformType'],
                                    c['PlatformVersion'],
                                    c['AgentType'],
                                    c['AgentVersion']))

        # paginator = rssmc.get_paginator('describe_instance_information')
        # page_iterator = paginator.paginate()
        # for page in page_iterator:
            # for instinfo in page['InstanceInformationList']:
                # print('%s,%s,%s,%s,%s,%s,%s,%s,%s' %(acctid, region, instinfo['InstanceId'], instinfo['IPAddress'],
                                     # instinfo['PlatformType'], instinfo['PlatformName'], 
                                     # instinfo['ResourceType'], instinfo['AssociationStatus'],instinfo['PingStatus']))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
