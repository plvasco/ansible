import argparse
import boto3
import logging
import sessionmod
import json
import datetime
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_s3.py
#python3 vaec_inventory_s3.py --account-id all
#python3 vaec_inventory_s3.py --account-id 477194928391

S3_STORAGE_TYPES=['StandardStorage', 'IntelligentTieringFAStorage', 'IntelligentTieringIAStorage', 'IntelligentTieringAAStorage', 'IntelligentTieringAIAStorage', 'IntelligentTieringDAAStorage', 'StandardIAStorage', 'StandardIASizeOverhead', 'StandardIAObjectOverhead', 'OneZoneIAStorage', 'OneZoneIASizeOverhead', 'ReducedRedundancyStorage', 'GlacierInstantRetrievalStorage', 'GlacierStorage', 'GlacierStagingStorage', 'GlacierObjectOverhead', 'GlacierS3ObjectOverhead', 'DeepArchiveStorage', 'DeepArchiveObjectOverhead', 'DeepArchiveS3ObjectOverhead', 'DeepArchiveStagingStorage']

parser = argparse.ArgumentParser(description='VAEC inventory S3 buckets')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-ids')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-ids')
parser.add_argument('--storage-types', dest='storage_types', default='StandardStorage,GlacierStorage',  help='all or Comma separeated S3 storage types')
args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

if args.storage_types.strip() == 'all':
    storage_type_list=S3_STORAGE_TYPES
else:
    storage_type_list= [t.strip() for t in args.storage_types.split(',') if t.strip() in S3_STORAGE_TYPES ]
print(storage_type_list)

PERIOD=86400
TIMEDELTA=86400*2

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)
        print('account_id,bucket,storage_type,average_size,unit')
        sessionmod.iterate_orgs_accounts(fn_inventory_s3, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_inventory_s3(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)

        rcwc = session_assumed.client('cloudwatch', config = boto_config)
        rs3c = session_assumed.client('s3', config = boto_config)

        end_time= datetime.datetime.now(datetime.timezone.utc)
        start_time= end_time - datetime.timedelta(seconds=TIMEDELTA)

        buckets_list=rs3c.list_buckets()

        
        for b in buckets_list['Buckets']:
            for st in storage_type_list:
                m=rcwc.get_metric_statistics(
                        Namespace='AWS/S3', MetricName='BucketSizeBytes', Statistics=['Average'],
                        StartTime=start_time, EndTime=end_time, Period=PERIOD,
                        Dimensions=[
                                    {'Name': 'BucketName', 'Value': b['Name']},
                                    {'Name': 'StorageType', 'Value': st}
                                   ])
                if m['Datapoints']:
                    sz = m['Datapoints'][0].get('Average', '')
                    u  = m['Datapoints'][0].get('Unit', '')
                    print('%s,%s,%s,%s,%s' %(acctid,b['Name'], st, sz, u))


    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()



# aws cloudwatch get-metric-statistics --namespace AWS/S3 --start-time 2015-07-15T10:00:00 --end-time 2015-07-31T01:00:00 --period 86400 --statistics Average --region eu-west-1 --metric-name BucketSizeBytes --dimensions Name=BucketName,Value=toukakoukan.com Name=StorageType,Value=StandardStorage

# aws cloudwatch get-metric-statistics --namespace AWS/S3 --start-time "$(echo "$(date +%s) - 86400" | bc)" --end-time "$(date +%s)" --period 86400 --statistics Average --region us-east-1 --metric-name BucketSizeBytes --dimensions Name=BucketName,Value="LernentecBucket" Name=StorageType,Value=StandardStorage
