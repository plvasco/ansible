import argparse
import boto3
import logging
import sessionmod
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_elb.py
#python3 vaec_inventory_elb.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_elb.py --account-id 477194928391 --region all --no-tags

parser = argparse.ArgumentParser(description='VAEC inventory ELB')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--no-tags', dest='to_include_tags', action='store_false', default=True, help='Exclude tag info')

args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        print("account,region,vpc_id,elb_name,elb_type, elb_scheme,elb_createtime,elb_tags")
        sessionmod.iterate_orgs_accounts(fn_print_elb_inventory, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_elb_inventory(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        elbc = session_assumed.client('elbv2', config = boto_config)

        paginator = elbc.get_paginator('describe_load_balancers')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for elb in page['LoadBalancers']:
                existing_tags=''
                if args.to_include_tags:
                    existing_tags = elbc.describe_tags(ResourceArns=[elb['LoadBalancerArn']])['TagDescriptions'][0]['Tags']
                print("{},{},{},{},{},{},{},\"{}\"".format(acctid, region, elb['VpcId'], elb['LoadBalancerName'], elb['Type'], elb['Scheme'], elb['CreatedTime'], existing_tags))


        elbc = session_assumed.client('elb', config = boto_config)

        paginator = elbc.get_paginator('describe_load_balancers')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for elb in page['LoadBalancerDescriptions']:
                existing_tags=''
                if args.to_include_tags:
                    existing_tags = elbc.describe_tags(LoadBalancerNames=[elb['LoadBalancerName']])['TagDescriptions'][0]['Tags']
                print("{},{},{},{},{},{},{},\"{}\"".format(acctid, region, elb['VPCId'], elb['LoadBalancerName'], 'classic', elb['Scheme'], elb['CreatedTime'], existing_tags))


    except Exception as ex:
        logger.error(ex)




# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
