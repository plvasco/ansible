import argparse
import boto3
import logging
import sessionmod
import json
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_ses.py
#python3 vaec_inventory_ses.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_ses.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC inventory SES')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')
args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print('acctid,region,domains,emails')
        sessionmod.iterate_orgs_accounts(fn_inventory_ses, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_inventory_ses(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rsesc = session_assumed.client('ses', config = boto_config)

        dlist= rsesc.list_identities(IdentityType='Domain')['Identities']
        elist= rsesc.list_identities(IdentityType='EmailAddress')['Identities']

        print('%s,%s,%s,%s' %(acctid,region,dlist, elist))
    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
