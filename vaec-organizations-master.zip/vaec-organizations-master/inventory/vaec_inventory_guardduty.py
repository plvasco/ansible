import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_guardduty.py
#python3 vaec_inventory_guardduty.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_guardduty.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC inventory GuardDuty detectors')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print("region,account,detector_id")
        sessionmod.iterate_orgs_accounts(print_guarduty_detectors, args.remote_account_id, args.region_id)
            
    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def print_guarduty_detectors(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rgd2c = session_assumed.client('guardduty')
        response=rgd2c.list_detectors();
        if response and response['DetectorIds']:
            print("{},{},{}".format(region, acctid, response['DetectorIds']))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))
        raise(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
