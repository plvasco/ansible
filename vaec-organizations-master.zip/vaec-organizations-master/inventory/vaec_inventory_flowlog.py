import argparse
import boto3
import logging
import json
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

# --------------------------------------------------------------------------------------------------------
#python3 vaec_inventory_flowlog.py --account-id 477194928391 --region us-gov-west-1

parser = argparse.ArgumentParser(description='Inventory VAEC VPC flowlog')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        print("account-id, region, vpc-id, vpc-flowlog-id,log-group,destination-arn,metric-filters")
        sessionmod.iterate_orgs_accounts(fn_describe_vpc_flowlogs, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

def get_all_vpcs(ec2_resource):
    return [vpc.id for vpc in list(ec2_resource.vpcs.all())]

# ----------------------------------------------------------------

def fn_describe_vpc_flowlogs(acctid, region):
    metric_filter=[]
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        ec2r = session_assumed.resource('ec2')
        ec2c = session_assumed.client('ec2')
        logc = session_assumed.client('logs')
        #logger.info("Finding VPC flowlogs in AccountID: %s, Region: %s" %(acctid, region))
        vpc_list=get_all_vpcs(ec2r)
        if not vpc_list:
            #logger.info("No VPCs found in AccountID: %s, Region: %s" %(acctid, region))
            print(acctid +","+ region+",None,None,None,None,None")
            return

        for vpc_id in vpc_list:
            response = ec2c.describe_flow_logs(
                            DryRun=False,
                            Filters=[
                                {
                                    'Name': 'resource-id',
                                    'Values': [
                                        vpc_id
                                    ]
                                },
                                {
                                    'Name': 'log-destination-type',
                                    'Values': [
                                        'cloud-watch-logs',
                                    ]
                                }
                            ]
                        )
            if not response['FlowLogs']:
                print(acctid +","+ region+"," + vpc_id+",None,None,None,None")
                #logger.info("No VPC flowlogs in AccountID: %s, Region: %s, for VPC %s" %(acctid, region, vpc_id))
            else:
                for vpc_flowlog in response['FlowLogs']:
                    filter_response = logc.describe_subscription_filters(
                                   logGroupName=vpc_flowlog['LogGroupName']
                                  )
                    metric_filter=is_metric_filter_exist(logc,vpc_flowlog['LogGroupName'])
                    if not filter_response['subscriptionFilters']:
                        print(acctid +","+ region+"," + vpc_id+","+vpc_flowlog['FlowLogId'] +"," + vpc_flowlog['LogGroupName']+",None,"+str(metric_filter))
                        # if metric_filter_flag:
                        #     print(acctid +","+ region+"," + vpc_id+","+vpc_flowlog['FlowLogId'] +"," + vpc_flowlog['LogGroupName']+",None,"+metric_filter)
                        # else:
                        #     print(acctid +","+ region+"," + vpc_id+","+vpc_flowlog['FlowLogId'] +"," + vpc_flowlog['LogGroupName']+",None,None")
                        #logger.info("AccountID: %s, Region: %s, VPC: %s, log group:%s, Destination arn: %s" %(acctid, region, vpc_id, vpc_flowlog['LogGroupName'],'None'))
                    else:
                        for sub_filters in filter_response['subscriptionFilters']:
                            print(acctid +","+ region+"," + vpc_id+","+vpc_flowlog['FlowLogId'] +"," + vpc_flowlog['LogGroupName']+","+sub_filters['destinationArn']+","+str(metric_filter))
                            # if metric_filter_flag:
                            #     print(acctid +","+ region+"," + vpc_id+","+vpc_flowlog['FlowLogId'] +"," + vpc_flowlog['LogGroupName']+","+sub_filters['destinationArn']+","+metric_filter)
                            # else:
                            #     print(acctid +","+ region+"," + vpc_id+","+vpc_flowlog['FlowLogId'] +"," + vpc_flowlog['LogGroupName']+","+sub_filters['destinationArn']+",None")
                            #print(acctid +","+ region+"," + vpc_id+","+vpc_flowlog['FlowLogId'] +"," + vpc_flowlog['LogGroupName']+","+sub_filters['destinationArn'])
                            #logger.info("AccountID: %s, Region: %s, VPC: %s, log group: %s, Destination arn: %s" %(acctid, region, vpc_id, vpc_flowlog['LogGroupName'],sub_filters['destinationArn']))

    except Exception as ex:
        logger.error(ex)

def is_metric_filter_exist(log_client, log_group_name):
    returnValue=False
    filters=[]
    try:
        response = log_client.describe_metric_filters(
            logGroupName=log_group_name
        )
        #print(response)
        # if response['metricFilters']:
        #     filters="filternames"
        for m in response['metricFilters']:
            filters.append(m['filterName'])
        return filters
    except Exception as ex:
        returnValue=False
        #No Metric filters. so it is ok to deleted log group
        #logger.info("No metric filter exists for %s", log_group_name)


# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
