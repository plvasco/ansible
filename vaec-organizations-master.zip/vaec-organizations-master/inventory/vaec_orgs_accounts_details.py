import boto3
import argparse
import sessionmod
import tagmod
from botocore.config import Config

parser = argparse.ArgumentParser(description='Get details of AWS accounts')
parser.add_argument('--region', dest='region_id', choices=['us-gov-west-1', 'us-east-2'], default='us-east-2', help='all is invalid')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--skip-alt-contact', dest='to_get_alt_contact', action='store_false', default=True, help='Skip pulling account alternate contact info (faster)')
parser.add_argument('--skip-tags', dest='to_get_tags', action='store_false', default=True, help='Skip pulling Orgs entry tags (faster)')

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})
args = parser.parse_args()
in_acct_list = [a.strip() for a in args.remote_account_id.split(',')]

#---------------------------------------------------------------------------
def main():
    try:
        # lsession_assumed = sessionmod.aws_session3(sessionmod.get_orgs_mgmt_account(args.region_id), args.region_id)
        # lorgc = lsession_assumed.client('organizations', config = boto_config)

        lorgc  = boto3.client('organizations', config=boto_config)
        lacctc = boto3.client('account', config=boto_config)

        orgs_acctlist=sessionmod.get_all_accounts_details(lorgc)
        print('Status,Id,Email,Name,Billing,Operations,Security,Tags')
        for acct in orgs_acctlist:
            if ('all' in in_acct_list) or (acct['Id'] in in_acct_list):
            
                alt_contact_dict = {'BILLING': {}, 'OPERATIONS': {}, 'SECURITY': {}}
                if (args.region_id in ['us-east-2']) and args.to_get_alt_contact:
                    for key in alt_contact_dict:
                        try:
                            alt_contact = lacctc.get_alternate_contact(AccountId=acct['Id'], AlternateContactType = key)
                            alt_contact_dict[key]=alt_contact['AlternateContact']
                        except Exception as ex1:
                            # print(ex1)
                            continue

                tag_dict={}
                if args.to_get_tags:
                    tag_dict = tagmod.tags_list2dict(tagmod.get_tags_from_orgs_resource(lorgc, acct['Id']))

                print('%s,%s,%s,%s,"%s","%s","%s","%s"' %(acct['Status'], acct['Id'], acct['Email'], acct['Name'],
                            alt_contact_dict['BILLING'], alt_contact_dict['OPERATIONS'], alt_contact_dict['SECURITY'], tag_dict))

    except Exception as ex:
        raise ex

if __name__== "__main__":
  main()
