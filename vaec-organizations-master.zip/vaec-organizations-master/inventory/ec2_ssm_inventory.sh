#!/bin/bash

export PATH=$PATH:/usr/local/bin

s3_target='s3://vaec-inventory/ec2ssm/'

outfile1=ec2-`date +"%F-%T"`.csv
python3 vaec_inventory_ec2inst.py > $outfile1
gzip $outfile1
aws s3 cp $outfile1.gz $s3_target --region us-gov-west-1
rm $outfile1.gz

outfile2=ssm-`date +"%F-%T"`.csv
python3 vaec_inventory_ssm.py > $outfile2
gzip $outfile2
aws s3 cp $outfile2.gz $s3_target --region us-gov-west-1
rm $outfile2.gz
