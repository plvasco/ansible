import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_dhcpos.py
#python3 vaec_inventory_dhcpos.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_dhcpos.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC inventory VPC DHCP optionset')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print("account,region,vpc-id,dhcp-options-id,dhcp-options-config")
        sessionmod.iterate_orgs_accounts(fn_print_dhcpos_usage, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_dhcpos_usage(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        for vpc in rec2r.vpcs.all():

            print("{},{},{},{},\"{}\"".format(vpc.owner_id, region, vpc.vpc_id,
                                vpc.dhcp_options.dhcp_options_id,
                                str(vpc.dhcp_options.dhcp_configurations)))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
