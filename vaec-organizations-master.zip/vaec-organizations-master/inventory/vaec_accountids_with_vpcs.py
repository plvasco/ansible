import argparse
import boto3
import sessionmod
import netmod

#python3 vaec_accountids_with_vpcs.py --region us-gov-west-1

parser = argparse.ArgumentParser(description='Get list of accounts with valid VPCs in region')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', required=True, help='region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    acctid_list=[]
    try:
        if not args.region_id == 'all':
            sessionmod.iterate_orgs_accounts(fn_inventory_accts, args.remote_account_id, args.region_id, acctid_list)

    except Exception as ex:
        raise(ex)

    print(','.join(acctid_list))

# ----------------------------------------------------------------
def fn_inventory_accts(acctid, region, acctid_list):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        for vpc in rec2r.vpcs.all():
            cid = netmod.get_vpc_connection_id(vpc, region)
            if cid:
                acctid_list.append(acctid)
                break

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()

