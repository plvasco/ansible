import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_rds.py
#python3 vaec_inventory_rds.py --account-id all --region us-gov-west-1 --dbinstances
#python3 vaec_inventory_rds.py --account-id 477194928391 --region all --dbclusters

parser = argparse.ArgumentParser(description='VAEC RDS inventory')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')

group = parser.add_mutually_exclusive_group(required=True)
group.add_argument('--dbinstances', dest='to_report_dbinst', action='store_true', default=False, help='Report DB instance details')
group.add_argument('--dbclusters', dest='to_report_dbclust', action='store_true', default=False, help='Report DB cluster details')

args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        if args.to_report_dbclust:
            print("region,account_id,DatabaseName,DBClusterIdentifier,Engine,EngineVersion,EngineMode,MultiAZ,AvailabilityZones,DBClusterInstanceClass,AllocatedStorage,StorageType,StorageEncrypted,DeletionProtection,Endpoint,Port,PubliclyAccessible,ClusterCreateTime")
            sessionmod.iterate_orgs_accounts(fn_describe_rds_db_cluster, args.remote_account_id, args.region_id)

        if args.to_report_dbinst:
            print("region,account_id,DBInstanceIdentifier,DBClusterIdentifier,Engine,EngineVersion,EngineMode,MultiAZ,AvailabilityZone,DBInstanceClass,AllocatedStorage,StorageType,StorageEncrypted,DBInstanceStatus,LicenseModel,Endpoint,Port,InstanceCreateTime")
            sessionmod.iterate_orgs_accounts(fn_describe_rds_db_inst, args.remote_account_id, args.region_id)


    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_describe_rds_db_cluster(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rrdsc = session_assumed.client('rds')

        paginator = rrdsc.get_paginator('describe_db_clusters')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for c in page['DBClusters']:
                print('{},{},{},{},{},{},{},{},"{}",{},{},{},{},{},{},{}'.format(region, acctid, 
                                c.get('DatabaseName', ''),
                                c['DBClusterIdentifier'],
                                c['Engine'],
                                c['EngineVersion'],
                                c['EngineMode'],
                                c['MultiAZ'],
                                c['AvailabilityZones'],
                                c.get('DBClusterInstanceClass',''),
                                c['AllocatedStorage'],
                                c.get('StorageType',''),
                                c['StorageEncrypted'],
                                c['DeletionProtection'],
                                c['Endpoint'], c['Port'],
                                c.get('PubliclyAccessible',''),
                                c['ClusterCreateTime']))

    except Exception as ex:
        logger.error('{},{},{}'.format(region, acctid, ex))

# ----------------------------------------------------------------
def fn_describe_rds_db_inst(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rrdsc = session_assumed.client('rds')

        paginator = rrdsc.get_paginator('describe_db_instances')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for c in page['DBInstances']:
                print('{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}'.format(region, acctid, 
                                c['DBInstanceIdentifier'],
                                c.get('DBClusterIdentifier', ''),
                                c['Engine'],
                                c['EngineVersion'],
                                c.get('EngineMode', ''),
                                c['MultiAZ'],
                                c['AvailabilityZone'],
                                c['DBInstanceClass'],
                                c['AllocatedStorage'],
                                c['StorageType'],
                                c['StorageEncrypted'],
                                c['DBInstanceStatus'],
                                c['LicenseModel'],
                                c['Endpoint']['Address'],c['Endpoint']['Port'],
                                c['InstanceCreateTime']))

    except Exception as ex:
        logger.error('{},{},{}'.format(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
