import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_vpc_peering.py
#python3 vaec_inventory_vpc_peering.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_vpc_peering.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC VPC peering inventory')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

all_vpc_peerings_list = []

# ----------------------------------------------------------------

def main():
    try:
        global all_vpc_peerings_list
        # logger.debug(args)

        sessionmod.iterate_orgs_accounts(fn_describe_vpc_peering, args.remote_account_id, args.region_id)

        print("pcx_name, pcx_id, requester_region, requester_account_id, requester_vpc_id, requester_connection_id, requester_vpc_name, requester_cidr_block, accepter_region, accepter_account_id, accepter_vpc_id, accepter_connection_id, accepter_vpc_name, accepter_cidr_block")

        unique_list= []
        for x in all_vpc_peerings_list:
            if x not in unique_list: 
                unique_list.append(x) 
                print(x)
        
    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_describe_vpc_peering(acctid, region):
    try:
        global all_vpc_peerings_list
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        for pcx in rec2r.vpc_peering_connections.all():

            # pcx_tag-Name
            pcx_tag_name=''
            if pcx.tags:
                for t in pcx.tags:
                    if t['Key'] == 'Name':
                        pcx_tag_name=t['Value'].strip()
            
            # VPC attributes
            requester_vpc_attrib = get_vpc_attrib(pcx.requester_vpc_info['OwnerId'], pcx.requester_vpc_info['Region'], pcx.requester_vpc_info['VpcId'])

            accepter_vpc_attrib = get_vpc_attrib(pcx.accepter_vpc_info['OwnerId'], pcx.accepter_vpc_info['Region'], pcx.accepter_vpc_info['VpcId'])
            
            # cidrs
            requester_cidr_blocks=[]
            for requester_cbs in pcx.requester_vpc_info['CidrBlockSet']:
                requester_cidr_blocks.append(requester_cbs['CidrBlock'])

            accepter_cidr_blocks=[]
            for accepter_cbs in pcx.accepter_vpc_info['CidrBlockSet']:
                accepter_cidr_blocks.append(accepter_cbs['CidrBlock'])

            out_str="{},{},{},{},{},{},{},\"{}\",{},{},{},{},{},\"{}\"".format(
                             pcx_tag_name, pcx.vpc_peering_connection_id, pcx.requester_vpc_info['Region'],
                             pcx.requester_vpc_info['OwnerId'], pcx.requester_vpc_info['VpcId'], requester_vpc_attrib['ConnectionID'],
                             requester_vpc_attrib['Name'], str(requester_cidr_blocks), pcx.accepter_vpc_info['Region'], 
                             pcx.accepter_vpc_info['OwnerId'], pcx.accepter_vpc_info['VpcId'], accepter_vpc_attrib['ConnectionID'],
                             accepter_vpc_attrib['Name'], str(accepter_cidr_blocks))
            all_vpc_peerings_list += [out_str]
    except Exception as ex:
        logger.error(ex)

# ----------------------------------------------------------------
def get_vpc_attrib(acctid, region, vpcid):

    ret_val= { 'Name': '', 'ConnectionID': '' }

    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        vpc = rec2r.Vpc(vpcid)
        if vpc.tags:
            for t in vpc.tags:
                if t['Key'] == 'Name':
                    ret_val['Name'] = t['Value'].strip()
                elif t['Key'] in ['ConnectionID', 'vaec:ConnectionID']:
                    ret_val['ConnectionID'] = t['Value'].strip()

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

    return ret_val
    
# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
