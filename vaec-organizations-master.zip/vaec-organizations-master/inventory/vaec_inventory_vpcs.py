import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_vpcs.py
#python3 vaec_inventory_vpcs.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_vpcs.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC VPC inventory')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print("region,account_id,ConnectionID,vaec:ConnectionID,CKID,vpc-id,Name,cidr_block,igw_exists")
        sessionmod.iterate_orgs_accounts(fn_describe_vpc_info, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_describe_vpc_info(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        for vpc in rec2r.vpcs.all():
            tag_name=''
            tag_connectionid=''
            tag_vaec_connectionid=''
            tag_vaec_ckid=''

            if vpc.tags:
                for t in vpc.tags:
                    if t['Key'] == 'Name':
                        tag_name=t['Value'].strip()
                    elif t['Key'] == 'ConnectionID':
                        tag_connectionid=t['Value'].strip()
                    elif t['Key'] == 'vaec:ConnectionID':
                        tag_vaec_connectionid=t['Value'].strip()
                    elif t['Key'] == 'vaec:CKID':
                        tag_vaec_ckid=t['Value'].strip()

            igw_exists=False
            for i in vpc.internet_gateways.all():
                igw_exists=True
                
            # cidr_blocks=[]
            # for cba in vpc.cidr_block_association_set:
                # cidr_blocks.append(cba['CidrBlock'])

            cidr_blocks=''
            for cba in vpc.cidr_block_association_set:
                cidr_blocks += cba['CidrBlock'].strip() + ' '
            cidr_blocks = cidr_blocks.strip().replace(' ', ', ')

            print("{},{},{},{},{},{},{},\"{}\",{}".format(region, vpc.owner_id, tag_connectionid, tag_vaec_connectionid, tag_vaec_ckid, vpc.vpc_id, tag_name, cidr_blocks,igw_exists))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
