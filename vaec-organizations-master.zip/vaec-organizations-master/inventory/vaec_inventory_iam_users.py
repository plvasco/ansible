import argparse
import boto3
import csv
import logging
import sessionmod
import time

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_iam_users.py --account-id 477194928391
#python3 vaec_inventory_iam_users.py --account-id 477194928391 --skip-users 'user1,user2'

parser = argparse.ArgumentParser(description='VAEC Inventory active IAM users')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--skip-users', dest='skip_users', default='<root_account>,Administrator', help='comma separated list of users to skip')

args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print('account_id,user,arn,user_creation_time,password_enabled,password_last_used,password_last_changed,password_next_rotation,mfa_active,access_key_1_active,access_key_1_last_rotated,access_key_1_last_used_date,access_key_1_last_used_region,access_key_1_last_used_service,access_key_2_active,access_key_2_last_rotated,access_key_2_last_used_date,access_key_2_last_used_region,access_key_2_last_used_service,cert_1_active,cert_1_last_rotated,cert_2_active,cert_2_last_rotated')
        sessionmod.iterate_orgs_accounts(fn_inventory_iam_users, args.remote_account_id, 'us-gov-west-1')

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
# Request the credential report, download and parse the CSV.
def get_credential_report(iam_client):
    resp1 = iam_client.generate_credential_report()
    if resp1['State'] == 'COMPLETE' :
        try:
            response = iam_client.get_credential_report()
            credential_report_csv = response['Content'].decode('utf8')
            reader = csv.DictReader(credential_report_csv.splitlines())
            # print(reader.fieldnames)
            credential_report = []
            for row in reader:
                credential_report.append(row)
            return(credential_report)
        except Exception as ex:
            raise(ex)
    else:
        time.sleep(10)
        return get_credential_report(iam_client)

# ----------------------------------------------------------------
def fn_inventory_iam_users(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        riamc = session_assumed.client('iam')

        credential_report = get_credential_report(riamc)

        for row in credential_report:

            if row['user'] in args.skip_users: # Skip root account
                continue

            if (row['password_enabled'].lower() == 'true' or
               row['access_key_1_active'].lower() == 'true' or
               row['access_key_2_active'].lower() == 'true') :
                print('%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s' %(acctid, row['user'], row['arn'], row['user_creation_time'], row['password_enabled'], row['password_last_used'], row['password_last_changed'], row['password_next_rotation'], row['mfa_active'], row['access_key_1_active'], row['access_key_1_last_rotated'], row['access_key_1_last_used_date'], row['access_key_1_last_used_region'], row['access_key_1_last_used_service'], row['access_key_2_active'], row['access_key_2_last_rotated'], row['access_key_2_last_used_date'], row['access_key_2_last_used_region'], row['access_key_2_last_used_service'], row['cert_1_active'], row['cert_1_last_rotated'], row['cert_2_active'], row['cert_2_last_rotated']))


    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
