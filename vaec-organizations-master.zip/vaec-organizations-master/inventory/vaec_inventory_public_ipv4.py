import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_public_ipv4_igw.py
#python3 vaec_inventory_public_ipv4_igw.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_public_ipv4_igw.py --account-id 348286891446 --region all

parser = argparse.ArgumentParser(description='VAEC inventory public IPv4 on EC2 instances')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print("acctid,region,public_ipv4,private_ipv4,igw_exists")
        sessionmod.iterate_orgs_accounts(fn_print_public_ipv4, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_public_ipv4(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        vpc_igw={}
        for vpc in rec2r.vpcs.all():
            igw_exists=False
            for i in vpc.internet_gateways.all():
                igw_exists=True
            vpc_igw[vpc.id]=igw_exists

        for ni in rec2r.network_interfaces.all():
            for priv_ip in ni.private_ip_addresses:
                assoc=priv_ip.get('Association', None)
                if assoc:
                    public_ipv4 = assoc.get('PublicIp', None)
                    if public_ipv4:
                        print("{},{},{},{},{}".format(acctid, region, public_ipv4, priv_ip['PrivateIpAddress'],vpc_igw[ni.vpc_id]))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
