import argparse
import boto3
import logging
import sessionmod
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_ec2inst.py
#python3 vaec_inventory_ec2inst.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_ec2inst.py --account-id 477194928391 --region all --no-tags

parser = argparse.ArgumentParser(description='VAEC inventory EC2 instances')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--no-tags', dest='to_include_tags', action='store_false', default=True, help='Exclude tag info')

args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        print("account,region,vpc_id,subnet_id,instance_id,instance_type,platform,state,private_ip_address,image_id,image_owner,image_ownership,image_public,tags")
        sessionmod.iterate_orgs_accounts(fn_print_ec2inventory, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_ec2inventory(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2', config = boto_config)

        for inst in rec2r.instances.all():
            (platform, image_owner, image_public) = get_img_details(rec2r, inst)
            tags=""
            if args.to_include_tags:
                tags=inst.tags

            image_ownership = ''
            if acctid == image_owner:
                image_ownership = "SAME_ACCOUNT"

            print('{},{},{},{},{},{},{},{},{},{},{},{},{},"{}"'.format(acctid, region, inst.vpc_id, inst.subnet_id, inst.instance_id,
                    inst.instance_type, platform, inst.state['Name'], inst.private_ip_address, inst.image_id, image_owner, image_ownership, image_public, tags))
    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

def get_img_details(rec2r, inst):
    platform=None
    image_owner=None
    image_public=None
    if inst.platform:
        platform = inst.platform.capitalize()
    try:
        img=rec2r.Image(inst.image_id)
        if img:
            platform=img.platform_details
            image_owner=img.owner_id
            image_public=img.public
    except:
        pass
    return [platform, image_owner, image_public]

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
