import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_volumes.py
#python3 vaec_inventory_volumes.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_volumes.py --account-id 348286891446 --region all

parser = argparse.ArgumentParser(description='VAEC inventory EC2 EBS Volumes')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print("acctid,region,vol.id,vol.availability_zone,vol.encrypted,vol.size,vol.create_time,attached_to,attached_on")
        sessionmod.iterate_orgs_accounts(fn_print_vol_inventory, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_vol_inventory(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        for vol in rec2r.volumes.all():
            attached_to=''
            attached_on=''
            if vol.attachments:
                attached_to=vol.attachments[0]['InstanceId']
                attached_on=vol.attachments[0]['AttachTime']
            print("{},{},{},{},{},{},{},{},{}".format(acctid, region, vol.id, vol.availability_zone, vol.encrypted, vol.size, vol.create_time, attached_to, attached_on))
    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
