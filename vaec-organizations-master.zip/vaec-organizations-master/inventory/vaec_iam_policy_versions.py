import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_iam_policy_usage.py --iam-policy-name vaec/project-admin-iam-boundary
#python3 vaec_iam_policy_usage.py --account-id 477194928391 --iam-policy-name vaec/project-admin

parser = argparse.ArgumentParser(description='VAEC IAM role last used')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all is invalid')
parser.add_argument('--iam-policy-name', dest='iam_policy_name', required=True, help='IAM policy name with path to be checked')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)
        print('account_id,policy_arn,VersionId,IsDefaultVersion,CreateDate')
        sessionmod.iterate_orgs_accounts(fn_iam_policy_versions, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_iam_policy_versions(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        riamc = session_assumed.client('iam')
  
        policy_arn=("arn:{}:iam::{}:policy/{}".format(sessionmod.get_partition(region), acctid, args.iam_policy_name))
        paginator = riamc.get_paginator('list_policy_versions')
        page_iterator = paginator.paginate(PolicyArn=policy_arn)
        for page in page_iterator:
            for v in page['Versions']:
                print('{},{},{},{},{}'.format(acctid, policy_arn, v['VersionId'], v['IsDefaultVersion'], v['CreateDate'],))

    except Exception as ex:
        logger.error('{},{},{}'.format(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
