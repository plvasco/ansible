import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_iam_user_check.py --user-name fname.lastname
#python3 vaec_iam_user_check.py --account-id 348286891446 --user-name fname.lastname

parser = argparse.ArgumentParser(description='VAEC IAM user check')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--user-name', dest='user_name', required=True, help='IAM user name')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        sessionmod.iterate_orgs_accounts(fn_iam_user_check, args.remote_account_id, 'us-gov-west-1')

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_iam_user_check(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        riamc = session_assumed.client('iam')

        response = riamc.get_user(UserName=args.user_name)
        logger.info('%s %s' %(acctid, response['User']))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
