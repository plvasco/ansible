import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_cfn_stack_check.py --stack-name vaec-project-admin --region us-gov-west-1
#python3 vaec_cfn_stack_check.py --account-id 348286891446 --stack-name ent-jump-vpc1-subnet1
#python3 vaec_cfn_stack_check.py --account-id 477194928391 --stack-name vaec-landingzone-flowloggroup --region us-gov-west-1

parser = argparse.ArgumentParser(description='VAEC CFN stack check')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--stack-name', dest='stack_name', required=True, help='Cloudformation stack name')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print('region_id,account_id,StackName,StackStatus,CreationTime,LastUpdatedTime')
        sessionmod.iterate_orgs_accounts(fn_cfn_stack_check, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_cfn_stack_check(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rcfnc = session_assumed.client('cloudformation')
    
        paginator = rcfnc.get_paginator('describe_stacks')
        page_iterator = paginator.paginate(StackName=args.stack_name)
        for page in page_iterator:
            print('%s,%s,%s,%s,%s,%s' %(region, acctid, 
                                       page['Stacks'][0]['StackName'],
                                       page['Stacks'][0]['StackStatus'],
                                       page['Stacks'][0]['CreationTime'],
                                       page['Stacks'][0].get('LastUpdatedTime','NA')))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
