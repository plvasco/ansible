import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_iam_role_check.py --iam-role-name vaec-landingzone-flowloggroup --region us-gov-west-1
#python3 vaec_iam_role_check.py --account-id 348286891446 --iam-role-name vaec-vpc-peering
#python3 vaec_iam_role_check.py --account-id 477194928391 --iam-role-name vaec-landingzone-flowloggroup --region us-gov-west-1

parser = argparse.ArgumentParser(description='VAEC IAM role last used')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')
parser.add_argument('--iam-role-name', dest='iam_role_name', required=True, help='IAM role name to be checked')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print('region_id, account_id, iam_role_arn')
        sessionmod.iterate_orgs_accounts(fn_iam_role_usage, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_iam_role_usage(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        riamr = session_assumed.resource('iam')
        role = riamr.Role(args.iam_role_name)
        print('%s,%s,%s' %(region, acctid, role.arn))
            
    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()

