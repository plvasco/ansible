import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_support_cases.py
#python3 vaec_inventory_support_cases.py --account-id all --region us-gov-east-1
#python3 vaec_inventory_support_cases.py --account-id 477194928391 --include-resolved

parser = argparse.ArgumentParser(description='VAEC RDS inventory')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', choices=['us-gov-west-1', 'us-east-1'], default='us-gov-west-1', help='region-id') # Support sts is in us-east-1
parser.add_argument('--include-resolved', dest='include_resolved', action='store_true', default=False, help='Include resolved cases')
args = parser.parse_args()

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)
        print("account_id,displayId,severityCode,status,serviceCode,categoryCode,submittedBy,timeCreated,subject")
        sessionmod.iterate_orgs_accounts(fn_describe_support_cases, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_describe_support_cases(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rrdsc = session_assumed.client('support')

        paginator = rrdsc.get_paginator('describe_cases')
        page_iterator = paginator.paginate(includeResolvedCases=args.include_resolved, includeCommunications=False)
        for page in page_iterator:
            for c in page['cases']:
                print('{},{},{},{},{},{},{},{},"{}"'.format(acctid,
                                c['displayId'],
                                c['severityCode'],
                                c['status'],
                                c['serviceCode'],
                                c['categoryCode'],
                                c['submittedBy'],
                                c['timeCreated'],
                                c['subject']))
    except Exception as ex:
        logger.error('{},{},{}'.format(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
