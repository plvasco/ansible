import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_cfn_list_imports.py --export-name vaec-landingzone-flowloggroup --region us-gov-west-1
#python3 vaec_cfn_list_imports.py --account-id 348286891446 --export-name ent-jump-vpc1-subnet1
#python3 vaec_cfn_list_imports.py --account-id 477194928391 --export-name vaec-landingzone-flowloggroup --region us-gov-west-1
#python3 vaec_cfn_list_imports.py --account-id 477194928391 --export-name "vaec-init-tag-,Enterprise-AD-" --region us-gov-west-1

parser = argparse.ArgumentParser(description='VAEC list CFN imports for exported name')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--export-name', dest='export_name', required=True, help='Cloudformation export name or substring')
args = parser.parse_args()

export_name_list = [e.strip() for e in args.export_name.split(',')]

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print('region_id, account_id, export_name, imported_by')
        sessionmod.iterate_orgs_accounts(fn_cfn_list_import, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_cfn_list_import(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rcfnc = session_assumed.client('cloudformation')

        try:
            exports_to_check=[]
            paginator1 = rcfnc.get_paginator('list_exports')
            page_iterator1 = paginator1.paginate()
            for page in page_iterator1:
                for ex in page['Exports']:
                    for el in export_name_list:
                        if el in ex['Name']:
                            exports_to_check.append(ex['Name'])

            # print(exports_to_check)
            if exports_to_check:
                for ec in exports_to_check:
                    try:
                        paginator2 = rcfnc.get_paginator('list_imports')                    
                        page_iterator2 = paginator2.paginate(ExportName=ec)
                        for page in page_iterator2:
                            print('%s,%s,%s,\"%s\"' %(region, acctid, ec, page['Imports']))
                    except:
                        # print('%s,%s,%s,\"[]\"' %(region, acctid, ec))
                        continue
        except Exception as ex1:
            logger.error('%s,%s,%s' %(region, acctid, ex1))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
