import argparse
import boto3
import botocore
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_get_ram_share_assoc.py --region us-gov-west-1 --ram-share-arn 'arn:aws-us-gov:ram:us-gov-west-1:348286891446:resource-share/94b57f54-4f17-7c84-9bcf-70999375b23c, arn:aws-us-gov:ram:us-gov-west-1:348286891446:resource-share/70b71c4d-49fe-6169-14a0-9a190ea4128b'

#python3 vaec_get_ram_share_assoc.py --region us-gov-east-1 --ram-share-arn 'arn:aws-us-gov:ram:us-gov-east-1:348286891446:resource-share/feb67c1e-5580-e1ca-4fb0-8fea183d53c2, arn:aws-us-gov:ram:us-gov-east-1:348286891446:resource-share/3eb71ba9-e5ee-0c22-13f3-5f437e021ab3'


parser = argparse.ArgumentParser(description='Get list of VAEC RAM Share Principals')
parser.add_argument('--account-id', dest='remote_account_id', default='348286891446', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--ram-share-arn', dest='ram_share_arn', required=True, help='comma-separated RAM Share ARNs')

args = parser.parse_args()
ram_share_arn_list= [r.strip() for r in args.ram_share_arn.split(',')]

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)
        ram_share_assoc(args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def ram_share_assoc(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rramc = session_assumed.client('ram')

        paginator = rramc.get_paginator('list_principals')
        page_iterator = paginator.paginate(resourceOwner='SELF', resourceShareArns=ram_share_arn_list)
        print('arn, id, external')
        for page in page_iterator:
            for p in page['principals']:
                print('%s,%s,%s' %(p['resourceShareArn'],p['id'],p['external']))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
