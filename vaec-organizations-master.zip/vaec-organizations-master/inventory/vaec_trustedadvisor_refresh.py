import argparse
import boto3
import logging
import sessionmod
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_trustedadvisor_refresh.py
#python3 vaec_trustedadvisor_refresh.py --nodryrun
#python3 vaec_trustedadvisor_refresh.py --account-id 477194928391 --nodryrun

parser = argparse.ArgumentParser(description='VAEC Trusted Advisor refresh')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='region-id')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')

args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        session_name=__file__.split('.py')[0].replace('/', '_')
        sessionmod.iterate_orgs_accounts(fn_ta_refresh, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_ta_refresh(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rsc = session_assumed.client('support', config = boto_config)
        logger.info("[Dryrun=%s] %s TA refresh" %(args.to_dryrun, acctid))

        response_checks = rsc.describe_trusted_advisor_checks(language='en')

        chkid_list=[]
        for c in response_checks['checks']:
            # logger.info("%s %s %s %s" %(acctid, c['id'], c['name'], c['category']))
            if not c['id'] in chkid_list:
                chkid_list.append(c['id'])

        response_status = rsc.describe_trusted_advisor_check_refresh_statuses(checkIds=chkid_list)

        for s in response_status['statuses']:
            if s['millisUntilNextRefreshable'] > 0:
                chkid_list.remove(s['checkId'])

        for chkid in chkid_list:
            try:
                # logger.info("[Dryrun=%s] %s %s" %(args.to_dryrun, acctid, chkid))
                if not args.to_dryrun:
                    response= rsc.refresh_trusted_advisor_check(checkId=chkid)
            except ClientError as e:
                if not e.response['Error']['Code'] == 'InvalidParameterValueException':
                    logger.error("\t%s %s" %(chkid, e.response['Error']['Code']))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
