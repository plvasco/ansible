import argparse
import boto3
import logging
import sessionmod
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_beanstalk.py
#python3 vaec_inventory_beanstalk.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_beanstalk.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC inventory Beanstalk')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')

args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        print("account,region,EnvironmentName,EnvironmentId,ApplicationName,Health,HealthStatus,DateCreated")
        sessionmod.iterate_orgs_accounts(fn_print_beanstalk_inventory, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_beanstalk_inventory(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        beanstalkc = session_assumed.client('elasticbeanstalk', config = boto_config)

        paginator = beanstalkc.get_paginator('describe_environments')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for b in page['Environments']:
                print("{},{},{},{},{},{},{},{}".format(acctid, region, b.get('EnvironmentName', '-'), b['EnvironmentId'], b['ApplicationName'], b['Health'], b.get('HealthStatus','-'), b['DateCreated']))

    except Exception as ex:
        logger.error(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
