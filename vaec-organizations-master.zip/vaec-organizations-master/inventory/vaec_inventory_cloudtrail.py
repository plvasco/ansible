import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_cloudtrail.py --nodryrun
#python3 vaec_inventory_cloudtrail.py --account-id all --region us-gov-east-1
#python3 vaec_inventory_cloudtrail.py --account-id 477194928391,272417811699

parser = argparse.ArgumentParser(description='VAEC inventory CloudTrail')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or comma separated list of account-ids')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='specific region-id')
args = parser.parse_args()

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        print("account,trail_home_region,trail_name,trail_arn")
        sessionmod.iterate_orgs_accounts(fn_inventory_cloudtrail, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_inventory_cloudtrail(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        ctc = session_assumed.client('cloudtrail')
        paginator = ctc.get_paginator('list_trails')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for t in page['Trails']:
                print("%s,%s,%s,%s" %(acctid, t['HomeRegion'], t['Name'], t['TrailARN']))

    except Exception as ex:
        logger.error(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
