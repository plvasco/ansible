import argparse
import boto3
import logging
import sessionmod
import json
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_tgw_routes.py
#python3 vaec_inventory_tgw_routes.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_tgw_routes.py --account-id 477194928391 --region all --no-tags

parser = argparse.ArgumentParser(description='VAEC inventory EC2 instances')
parser.add_argument('--account-id', dest='remote_account_id', default='348286891446', help='account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')

args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})
ret_json={'TransitGateways': []}

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        sessionmod.iterate_orgs_accounts(fn_print_ec2inventory, args.remote_account_id, args.region_id)
        # print(json.dumps(ret_json, default=str))
        
    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_ec2inventory(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2c = session_assumed.client('ec2', config = boto_config)

        paginator1 = rec2c.get_paginator('describe_transit_gateways')
        page_iterator1 = paginator1.paginate(Filters=[{'Name': 'owner-id','Values': [acctid]}])
        for p1 in page_iterator1:
            for tgw in p1['TransitGateways']:
                paginator2 = rec2c.get_paginator('describe_transit_gateway_route_tables')
                page_iterator2 = paginator2.paginate(Filters=[{'Name': 'transit-gateway-id', 'Values': [tgw['TransitGatewayId']]}])
                tgw['TransitGatewayRouteTables']=[]
                for p2 in page_iterator2:
                    for rtb in p2['TransitGatewayRouteTables']:
                        response=rec2c.search_transit_gateway_routes(TransitGatewayRouteTableId=rtb['TransitGatewayRouteTableId'],
                                                Filters=[{'Name': 'state','Values': ['active','blackhole']}], MaxResults=10)
                        print(response.get('AdditionalRoutesAvailable', 'NoAdditionalRt'))
                        rtb['Routes']=response['Routes']
                        tgw['TransitGatewayRouteTables'].append(rtb)
                ret_json['TransitGateways'].append(tgw)

    except Exception as ex:
        logger.error(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
