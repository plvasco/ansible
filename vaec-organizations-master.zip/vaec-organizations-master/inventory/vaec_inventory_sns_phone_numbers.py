import argparse
import boto3
import logging
import sessionmod
import json
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_sns_phone_numbers.py
#python3 vaec_inventory_sns_phone_numbers.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_sns_phone_numbers.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC inventory SNS phone numbers')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')
args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print('acctid,region,PhoneNumber,CreatedAt,Status,Iso2CountryCode,RouteType,NumberCapabilities')
        sessionmod.iterate_orgs_accounts(fn_inventory_sns_phones, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_inventory_sns_phones(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rsns = session_assumed.client('sns', config = boto_config)

        paginator = rsns.get_paginator('list_origination_numbers')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for pn in page['PhoneNumbers']:
                print('{},{},{},{},{},{},{},"{}"'.format(acctid, region, pn['PhoneNumber'], pn['CreatedAt'], pn['Status'], pn['Iso2CountryCode'], pn['RouteType'], pn['NumberCapabilities']))


        paginator = rsns.get_paginator('list_sms_sandbox_phone_numbers')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for pn in page['PhoneNumbers']:
                print('{},{},{},{},{}'.format(acctid, region, pn['PhoneNumber'], 'SMSSandbox', pn['Status']))

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()


