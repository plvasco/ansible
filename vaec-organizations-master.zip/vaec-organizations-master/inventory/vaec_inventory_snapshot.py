import argparse
import boto3
import logging
import sessionmod
from botocore.config import Config

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_snapshot.py
#python3 vaec_inventory_snapshot.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_snapshot.py --account-id 348286891446 --region all

parser = argparse.ArgumentParser(description='VAEC inventory EC2 Snapshots')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print("count, snap.owner_id, region, snap.id, snap.state, snap.encrypted, snap.description, snap.start_time")
        sessionmod.iterate_orgs_accounts(print_snapshot_inventory, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def print_snapshot_inventory(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2', config = boto_config)

        count=0
        for snap in rec2r.snapshots.filter(OwnerIds=[acctid]):
            count += 1
            print("{},{},{},{},{},{},'{}',{}".format(count, snap.owner_id, region, snap.id, snap.state, snap.encrypted, snap.description, snap.start_time))
    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))



# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
