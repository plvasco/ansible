import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_subnets.py
#python3 vaec_inventory_subnets.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_subnets.py --account-id 477194928391 --region all

parser = argparse.ArgumentParser(description='VAEC inventory subnet usage')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print("region,account,tag-Name,subnet-id,vpc-id,subnet-ipv4,subnet-total-ips,subnet-available-ips,subnet-used-ips,subnet-usage")
        sessionmod.iterate_orgs_accounts(fn_print_subnet_usage, args.remote_account_id, args.region_id)
            
    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_subnet_usage(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        for subnet in rec2r.subnets.all():
            tag_name=''
            if subnet.tags:
                for t in subnet.tags:
                    if t['Key'] == 'Name':
                        tag_name=t['Value']
            
            total_ips = 2**(32-int(subnet.cidr_block.split('/')[1]))-5

            print("{},{},{},{},{},{},{:d},{},{:d},{:.2%}".format(region,
                                subnet.owner_id, tag_name, subnet.subnet_id, subnet.vpc_id,
                                subnet.cidr_block, total_ips, subnet.available_ip_address_count,
                                total_ips - int(subnet.available_ip_address_count),
                                1-int(subnet.available_ip_address_count)/total_ips))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))
        raise(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
