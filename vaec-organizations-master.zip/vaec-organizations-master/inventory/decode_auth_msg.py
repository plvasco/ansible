import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 decode_auth_msg.py --account-id 348286891446 --region us-gov-west-1 --encoded-message 'xxxxxxxxxxxx'

parser = argparse.ArgumentParser(description='STS Decode Auth Message')
parser.add_argument('--account-id', dest='remote_account_id', required=True, help='account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')
parser.add_argument('--encoded-message', dest='encoded_msg', required=True, help='Encoded Message')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        session_assumed = sessionmod.aws_session3(args.remote_account_id, args.region_id)

        rstsc = session_assumed.client('sts')
        response = rstsc.decode_authorization_message(EncodedMessage=args.encoded_msg)

        print(response['DecodedMessage'])

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
