import argparse
import boto3
import botocore
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_iam_group_check.py --group-name group_name
#python3 vaec_iam_group_check.py --account-id 477194928391 --group-name 'project-administrators, project-readonly, vaec-powerusers, vaec-administrators, vaec-readonly'
# python3 vaec_iam_group_check.py  --group-name 'project-administrators, project-readonly, vaec-powerusers, vaec-administrators, vaec-readonly'

parser = argparse.ArgumentParser(description='VAEC IAM group check')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--group-name', dest='group_name', required=True, help='Comma-separated list of IAM group name')

args = parser.parse_args()
group_name_list= [g.strip() for g in args.group_name.split(',')]


# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        logger.info(',acctid,group,users,inline_policies,attached_policies')
        sessionmod.iterate_orgs_accounts(fn_iam_group_check, args.remote_account_id, 'us-gov-west-1')

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_iam_group_check(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        riamc = session_assumed.client('iam')

        for grpname in group_name_list:
            users=[]
            try:
                response1 = riamc.get_group(GroupName=grpname)
                users=[]
                for u in response1['Users']:
                    users.append(u['UserName'])
            except Exception as ex:
                users=['NoSuchEntity']

            ipol=[]
            try:
                response2 = riamc.list_group_policies(GroupName=grpname)
                ipol=response2['PolicyNames']
            except Exception as ex:
                ipol = ['NoSuchEntity']

            apol=[]
            try:
                response2 = riamc.list_attached_group_policies(GroupName=grpname)
                for ap in response2['AttachedPolicies']:
                    apol.append(ap['PolicyName'])
            except Exception as ex:
                apol = ['NoSuchEntity']

        logger.info(',%s,%s,"%s","%s","%s"' %(acctid, grpname, users, ipol, apol))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
