import argparse
import boto3
import logging
import sessionmod
import datetime
import json
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

# python3 vaec_inventory_iam_user_ak.py --account-id 477194928391

parser = argparse.ArgumentParser(description='VAEC inventory IAM user access keys')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', choices=['us-gov-west-1', 'us-east-2'], help='all or region-id')
args = parser.parse_args()

POLICYARN=('arn:%s:iam::%s:policy/' %(sessionmod.get_partition(args.region_id),'%s'))
USERARN=('arn:%s:iam::%s:user/' %(sessionmod.get_partition(args.region_id),'%s'))
SKIPPOLICYNAME= ['project-admin', 'c-project-admin', 'vaec-administrator']

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)
        print("account_id,account_alias,user_name,ak,ak_status,ak_create_date,ak_active_days,ak_last_used_date,ak_last_used_days,principal")
        sessionmod.iterate_orgs_accounts(fn_iam_user_ak, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_iam_user_ak(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        riamc = session_assumed.client('iam')
        datetime_now = datetime.datetime.now(datetime.timezone.utc)

        policy_arn_substr = (POLICYARN % (acctid))
        user_arn_substr = (USERARN % (acctid))

        # -- account alias
        account_alias=get_accountalias(riamc)

        # -- determine IAM policies to check for user principals
        policies_to_check = get_policies_to_check(riamc, policy_arn_substr)

        # -- determine IAM policy statements to check for user principals
        policy_stmts_to_check = get_policy_stmts_to_check(riamc, policies_to_check)

        paginator = riamc.get_paginator('list_users')
        page_iterator= paginator.paginate()
        for page in page_iterator:
            for u in page['Users']:
                try:
                    aks = riamc.list_access_keys(UserName=u['UserName'])
                    for ak in aks['AccessKeyMetadata']:
                        ak_active_days=(datetime_now - ak['CreateDate']).days
                        lu_datetime =riamc.get_access_key_last_used(AccessKeyId=ak['AccessKeyId'])['AccessKeyLastUsed'].get('LastUsedDate','N/A')
                        if lu_datetime == 'N/A':
                            lu_days=-1
                        else:
                            lu_days=(datetime_now - lu_datetime).days

                        userprincipals=get_user_principal(riamc, u['UserName'], user_arn_substr, policy_stmts_to_check)
                        print('%s,%s,%s,%s,%s,%s,%d,%s,%d,"%s"' %(acctid, account_alias, u['UserName'],
                                ak['AccessKeyId'], ak['Status'], ak['CreateDate'], ak_active_days, lu_datetime, lu_days, userprincipals))
                except ClientError as e:
                        print("%s,%s,%s,%s" %(acctid, account_alias, u['UserName'], e.response['Error']['Code']))

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
def get_accountalias(riamc):
    account_alias=''
    r_alias = riamc.list_account_aliases()['AccountAliases']
    if r_alias:
        account_alias=r_alias[0]
    return account_alias

# ----------------------------------------------------------------
def get_policies_to_check(riamc, policy_arn_substr):
    set_policies_to_check=set()
    try:
        rpaginator = riamc.get_paginator('list_roles')
        rpage_iterator = rpaginator.paginate(PathPrefix='/')
        for rpage in rpage_iterator:
            for r in rpage['Roles']:
                if r['RoleName'].startswith('adfs-'):
                    ppaginator = riamc.get_paginator('list_attached_role_policies')
                    ppage_iterator = ppaginator.paginate(RoleName = r['RoleName'])
                    for ppage in ppage_iterator:
                        for p in ppage['AttachedPolicies']:
                            if p['PolicyArn'].startswith(policy_arn_substr) and (p['PolicyName'] not in SKIPPOLICYNAME):
                                set_policies_to_check.add(p['PolicyArn'])
    except ClientError as e:
        logger.error('%s' %(e))

    return set_policies_to_check

# ----------------------------------------------------------------
def get_policy_stmts_to_check(riamc, policies_to_check):
    ret_stmts=[]
    try:
        for parn in policies_to_check:
            p = riamc.get_policy(PolicyArn=parn)
            pver = riamc.get_policy_version(PolicyArn=parn, VersionId=p['Policy']['DefaultVersionId'])
            ret_stmts.append(pver['PolicyVersion']['Document']['Statement'])
    except ClientError as e:
        logger.error('%s' %(e))

    return ret_stmts

# ----------------------------------------------------------------
def get_samid(userid):
    retstr=userid.strip().lower()
    if userid.endswith('0'):
        retstr=retstr[:-1]
    if userid.startswith('*'):
        retstr=retstr[1:]
    return retstr

# ----------------------------------------------------------------
def get_user_principal (riamc, inuser, user_arn_substr, policy_stmts_to_check):
    samidset=set()
    try:
        for stmtgrp in policy_stmts_to_check:
            # print(stmtgrp)
            for stmt in stmtgrp:
               if (stmt['Effect'] == 'Allow') and stmt.get('Condition', None):
                    found_res=False
                    r=stmt['Resource']
                    if (r == "*") or (r == (user_arn_substr + inuser)) or (r == (user_arn_substr + "*")):
                        found_res = True
                    else:
                        for r in stmt['Resource']:
                            if (r == "*") or (r == (user_arn_substr + inuser)) or (r == (user_arn_substr + "*")):
                                found_res = True
                                break
                    found_action=False
                    for a in stmt['Action']:
                        if (a == "*") or (a == "iam:CreateAccessKey"):
                            found_action = True
                            break
                    if found_res and found_action:
                        for k1,v1 in stmt['Condition'].items():
                            for k2,v2 in v1.items():
                                if k2 == "saml:sub":
                                      for u in v2:
                                          samidset.add(u)
                                          # samidset.add(get_samid(u))
    except ClientError as e:
        logger.error('%s' %(e))

    if not len(samidset):
        samidset=None

    return samidset

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
