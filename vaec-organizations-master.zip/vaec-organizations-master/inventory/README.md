# Inventory scripts

General usage:
~~~
python3 vaec_SCRIPT.py [parameter] > output.csv
~~~


## VPC peering inventory

[vaec_inventory_vpc_peering.py](vaec_inventory_vpc_peering.py) lists the peering connection for listed accounts, and also de-duplicates as needed:
~~~
python3 vaec_inventory_vpc_peering.py
python3 vaec_inventory_vpc_peering.py --account-id 477194928391 --region all
~~~
