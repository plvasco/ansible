import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_inventory_ami.py
#python3 vaec_inventory_ami.py --account-id all --region us-gov-west-1
#python3 vaec_inventory_ami.py --account-id 348286891446 --region all

parser = argparse.ArgumentParser(description='VAEC inventory EC2 AMIs')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        print("img.owner_id, region, img.name, img.image_id, img.creation_date, img.platform")
        sessionmod.iterate_orgs_accounts(fn_print_ami_inventory, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_print_ami_inventory(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        for img in rec2r.images.filter(Owners=[acctid]):
            print("{},{},{},{},{},{}".format(img.owner_id, region, img.name, img.image_id, img.creation_date, img.platform))
    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))



# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
