# Provisioning Notes

The Powershell script [vaec_process_account.ps1](vaec_process_account.md) is a _shortcut_ to process onboarding and offboarding of new AWS accounts in GovCloud and commercial by running commands across multiple AWS repositories and Turbot.

## Prerequisites

Clone the following GitHub Enterprise repositories:
- AWS/vaec-shared-lib
- AWS/vaec-organizations
- AWS/vaec-landingzone
- AWS/vaec-vpc
- ECSO/vaec-ops-scripts

Note:
- Assume this is executed from GFE and user can assume role with appropriate permissionsWindows
- Windows PowerShell is required
- GitHub folder varies by user, note the _GitFolder_ for commands below. default is  _$GitFolder=$Env:UserProfile\Documents\git_ of PIV user.

~~~
cd <GitFolder>\vaec-organizations\
~~~

## Deploy new GovCloud + Commerical account

~~~
vaec_process_account.ps1 -Action add -GovCloudID <GovCloudID> -GovCloudTurbotParent <VASI_IT_Portfolio> -CommercialID <CommericalID> -ToDryrun:$false -CommercialTurbotParent Locked [-GitFolder <GitFolder>]
~~~


## Run after creating new VPC

~~~
vaec_process_account.ps1 -Action post-vpc -GovCloudID <GovCloudID> -ToDryrun:$false [-GitFolder <GitFolder>]
~~~
