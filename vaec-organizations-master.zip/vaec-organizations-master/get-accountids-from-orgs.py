import argparse
import sys
import boto3
import sessionmod

#usage example
# bash-4.2$ out=`python3 get-accountids-from-orgs.py`
# bash-4.2$ echo $out

parser = argparse.ArgumentParser(description='Get list of accounts from AWS Organizations')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all is invalid')

args = parser.parse_args()

#---------------------------------------------------------------------------
def main(argv):
    try:
        lsession_assumed = sessionmod.aws_session3(sessionmod.get_orgs_mgmt_account(args.region_id), args.region_id)
        lorgc = lsession_assumed.client('organizations')
        return sessionmod.get_active_account_list(lorgc)

    except Exception as ex:
        raise(ex)


if __name__== "__main__":
  accountids = main(sys.argv)
  print(','.join(accountids))
  sys.exit(0)

