Param (
        [string]$GitFolder=$Env:UserProfile.TrimEnd("0") + "\Documents\git",
        [string][ValidateSet("add", "remove", "post-vpc")]$Action,
        [string]$GovCloudID,
        [string]$CommercialID,
        [string][ValidateSet('','Benefits_and_Memorial_Services', 'Corporate_Services', 'Health_Services', 'Labs', 'Launch_Zone', 'Technology_and_Platform_Services', 'Unassigned', 'Veteran_Experience_Services')]$GovCloudTurbotParent='',
        [string][ValidateSet('','Locked')]$CommercialTurbotParent='',
        [switch]$ToDryrun=$true
    )

$GIT_FOLDER= $GitFolder.Trim()

$GovCloudID=$GovCloudID.Trim()
$CommercialID=$CommercialID.Trim()
$GovCloudTurbotParent=$GovCloudTurbotParent.Trim()
$CommercialTurbotParent=$CommercialTurbotParent.Trim()

$DryRunFlag="--nodryrun"
if ($ToDryrun) {
    $DryRunFlag=""
}

#------------------------------------------------------------------------------------
function main {
    Push-Location
    if ($Action -eq "add") {
        AddAwsCommercialAccount $CommercialID
        AddAwsGovCloudAccount $GovCloudID
    } elseif ($Action -eq "remove") {
        RemoveAwsGovCloudAccount $GovCloudID
        RemoveAwsCommercialAccount $CommercialID
    } elseif ($Action -eq "post-vpc") {
        PostVpcCreation $GovCloudID
    } else {
        Write-Host "Invalid -Action"
    }
    Pop-Location
}

#------------------------------------------------------------------------------------
function AssumeRoleGovCloudAccount() {
        Write-Host "# ------- aws-adfs assume role core-gov-internal"
        aws-adfs reset
        aws-adfs login --adfs-host=prod.adfs.federation.va.gov --no-session-cache --provider-id urn:amazon:webservices:govcloud --region us-gov-west-1 --role-arn arn:aws-us-gov:iam::348286891446:role/adfs-vaec-administrators
}

#------------------------------------------------------------------------------------
function AssumeRoleCommercialAccount() {
        Write-Host "# ------- aws-adfs assume role Commercial ecsbhighsupport"
        aws-adfs reset
        aws-adfs login --adfs-host=prod.adfs.federation.va.gov --no-session-cache --provider-id urn:amazon:webservices --region us-east-2 --role-arn arn:aws:iam::878022744496:role/adfs-c-vaec-core-admin
}

#------------------------------------------------------------------------------------
function AddAwsGovCloudAccount ($GovCloudID) {

    if ($GovCloudID -match "^\d{12}$") {
    
        AssumeRoleGovCloudAccount

        Write-Host "# ------- vaec-organizations process-accounts-in-orgs.py [ToDryrun=$ToDryrun] -Action=$Action $GovCloudID"
        cd $GIT_FOLDER\vaec-organizations
        python process-accounts-in-orgs.py --force --account-id $GovCloudID $DryRunFlag

        Write-Host "# ------- Sleep 90 seconds ... waiting for StackSets to deploy"
        Start-Sleep -Seconds 90

        if ($GovCloudTurbotParent.Length -gt 0) {
            $PayLoad = '{\"action\": \"import\", \"workspace\": \"VAEC\", \"aws_account_id\": \"' + $GovCloudID + '\", \"parent_resource_name\": \"' + $GovCloudTurbotParent + '\"}'

            Write-Host "# ------- GovCloud vaec-turbot-handler [ToDryrun=$ToDryrun] $PayLoad"
            if (-Not $ToDryrun) {
                aws sqs send-message --queue-url https://sqs.us-gov-west-1.amazonaws.com/804298029709/vaec-turbot-handler-rQueue-14M0Q0F4TQZU5 --message-body $PayLoad
            }
        }
    }
}

#------------------------------------------------------------------------------------
function AddAwsCommercialAccount ($CommercialID) {

    if ($CommercialID -match "^\d{12}$") {

        AssumeRoleCommercialAccount

        Write-Host "# ------- vaec-organizations process-commercial-orgs [ToDryrun=$ToDryrun] -Action=$Action $CommercialID"
        cd $GIT_FOLDER\vaec-organizations
        python process-commercial-orgs.py --force --account-id $CommercialID $DryRunFlag

        Write-Host "# ------- Sleep 90 seconds ... waiting for StackSets to deploy"
        Start-Sleep -Seconds 90

        Write-Host "# ------- vaec-organizations update-commercial-alt-contact [ToDryrun=$ToDryrun] $CommercialID"
        cd $GIT_FOLDER\vaec-organizations
        python update-commercial-alt-contact.py --account-id $CommercialID $DryRunFlag

        Write-Host "# ------- Process Commercial ADFS iDP [ToDryrun=$ToDryrun] $CommercialID"
        cd $GIT_FOLDER\vaec-landingzone\scripts
        python vaec_iam_idp_adfs.py --region us-east-2 --action create --account-id $CommercialID $DryRunFlag

        if ($CommercialTurbotParent.Length -gt 0) {
            $PayLoad = '{\"action\": \"import\", \"workspace\": \"VAEC\", \"aws_account_id\": \"' + $CommercialID + '\", \"parent_resource_name\": \"' + $CommercialTurbotParent + '\"}'

            Write-Host "# ------- Commercial vaec-turbot-handler [ToDryrun=$ToDryrun] $PayLoad"
            if (-Not $ToDryrun) {
                # Turbot Commercial runs in us-east-1
                aws sqs send-message --region us-east-1 --queue-url https://sqs.us-east-1.amazonaws.com/206817820325/vaec-turbot-handler-rQueue-PRgS4M09W0o4 --message-body $PayLoad
            }
        }
    }
}

#------------------------------------------------------------------------------------
function RemoveAwsGovCloudAccount ($GovCloudID) {
    if ($GovCloudID -match "^\d{12}$") {
        Write-Host "# ------- Remove GovCloud $GovCloudID [ToDryrun=$ToDryrun] -- NO ACTION"
    }
}

#------------------------------------------------------------------------------------
function RemoveAwsCommercialAccount ($CommercialID) {
    if ($CommercialID -match "^\d{12}$") {

        AssumeRoleCommercialAccount

        Write-Host "# ------- Remove Commercial ADFS iDP [ToDryrun=$ToDryrun] $CommercialID"
        cd $GIT_FOLDER\vaec-landingzone\scripts
        python vaec_iam_idp_adfs.py --region us-east-2 --action delete --account-id $CommercialID $DryRunFlag

        Write-Host "# ------- vaec-organizations process-commercial-orgs [ToDryrun=$ToDryrun] --action deactivate $CommercialID"
        cd $GIT_FOLDER\vaec-organizations
        python process-commercial-orgs.py  --action deactivate --account-id $CommercialID $DryRunFlag
    }
}

#------------------------------------------------------------------------------------
function PostVpcCreation ($GovCloudID) {
    if ($GovCloudID -match "^\d{12}$") {

        AssumeRoleGovCloudAccount

        Write-Host "# ------- vaec-ops-scripts ec2-ssm-instprofile [ToDryrun=$ToDryrun] $GovCloudID"
        cd $GIT_FOLDER\vaec-ops-scripts\aws\common\ec2-ssm-instprofile
        python vaec_ec2_ssm_instprofile.py --account-id $GovCloudID --connection-id-prefix "313,312,311" $DryRunFlag

        Write-Host "# ------- vaec-ops-scripts va-required-sg [ToDryrun=$ToDryrun] $GovCloudID"
        cd $GIT_FOLDER\vaec-ops-scripts\aws\common\va-required-sg
        python va_required_sg.py --account-id $GovCloudID --permits-action replace --connection-id-prefix "313,312,311" $DryRunFlag

    }
}

#------------------------------------------------------------------------------------
<#
        if ($GovCloudTurbotParent.Length -gt 0) {
            Write-Host "# ------- aws-adfs assume role Turbot GovCloud"
            # aws-adfs reset
            aws-adfs login --adfs-host=prod.adfs.federation.va.gov --no-session-cache --provider-id urn:amazon:webservices:govcloud --region us-gov-west-1 --role-arn arn:aws-us-gov:iam::804298029709:role/adfs-vaec-administrators

            Write-Host "# ------- GovCloud vaec-turbot-handler [ToDryrun=$ToDryrun] $GovCloudID $GovCloudTurbotParent"
            cd $GIT_FOLDER\Turbot\aws\vaec-turbot-handler
            $Env:AWS_PARTITION="aws-us-gov"
            $PayLoad = '{\"action\": \"import\", \"workspace\": \"VAEC\", \"aws_account_id\" : \"' + $GovCloudID + '\", \"parent_resource_name\": \"' + $GovCloudTurbotParent + '\"}'
            python vaec-turbot-handler_temp.py --event $PayLoad $DryRunFlag
            $Env:AWS_PARTITION=$null
        }

        if ($CommercialTurbotParent.Length -gt 0) {
            Write-Host "# ------- aws-adfs assume role Turbot Commercial"
            # aws-adfs reset
            aws-adfs login --adfs-host=prod.adfs.federation.va.gov --no-session-cache --provider-id urn:amazon:webservices --region us-east-1 --role-arn arn:aws:iam::206817820325:role/adfs-c-vaec-admin

            Write-Host "# ------- Commercial vaec-turbot-handler [ToDryrun=$ToDryrun] $CommercialID $CommercialTurbotParent"
            cd $GIT_FOLDER\Turbot\aws\vaec-turbot-handler
            $Env:AWS_PARTITION="aws"
            $PayLoad = '{\"action\": \"import\", \"workspace\": \"VAEC\", \"aws_account_id\" : \"' + $CommercialID + '\", \"parent_resource_name\": \"' + $CommercialTurbotParent + '\"}'
            python vaec-turbot-handler_temp.py --event $PayLoad $DryRunFlag
            $Env:AWS_PARTITION=$null
        }

#>


#------------------------------------------------------------------------------------
main