import boto3
import argparse
import sessionmod
import re
from botocore.config import Config

parser = argparse.ArgumentParser(description='Update AWS Commercial accounts alternate contacts')
parser.add_argument('--region', dest='region_id', choices=['us-east-2'], default='us-east-2', help='Only for AWS Commercial')
parser.add_argument('--account-id', dest='remote_account_id', required=True, help='all is invalid')
parser.add_argument('--skip-account-id', dest='skip_account_id', default='423386782741', help='Comma-separated list of account-ids to skip')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')

boto_config = Config(retries = {'max_attempts': 10, 'mode': 'adaptive'})
args = parser.parse_args()
in_acct_list = [a.strip() for a in args.remote_account_id.split(',')]
skip_account_list = [s.strip() for s in args.skip_account_id.split(',')]

#---------------------------------------------------------------------------
def main():
    try:
        if ('all' in in_acct_list):
            print("--account-id=all is disabled, provide a comma-separated list of AWS Commercial account IDs")
            return

        lorgc  = boto3.client('organizations', config=boto_config)
        lacctc = boto3.client('account', config=boto_config)

        orgs_acctlist=sessionmod.get_all_accounts_details(lorgc)
        print('Info,Status,Id,Email,Name,AlternateContact')
        for acct in orgs_acctlist:
            if acct['Id'] in in_acct_list:
                if acct['Id'] in skip_account_list:
                    print('[Skipping][DryRun=%s],%s,%s,%s,%s' % (args.to_dryrun, acct['Status'], acct['Id'], acct['Email'], acct['Name']))
                    continue

                acct_ops_email=''
                acct_email=acct['Email'].lower()
                # if acct_email.endswith("@va.gov") and not acct_email.endswith("-ops@va.gov"):
                if re.match(r'vaec-aws-gov-[0-9]{4}@va.gov', acct_email):
                    acct_ops_email=('%s-ops@va.gov' % acct_email.split("@va.gov")[0])
                    des_contact_list = [{'AlternateContactType': 'OPERATIONS', 'EmailAddress': acct_ops_email, 'Name': 'Steve Follett', 'PhoneNumber': '303-803-7812', 'Title': 'Operations Control Team Lead'},
                                        {'AlternateContactType': 'SECURITY', 'EmailAddress': acct_ops_email, 'Name': 'Steve Follett', 'PhoneNumber': '303-803-7812', 'Title': 'Operations Control Team Lead'}
                                       ]

                    for dc in des_contact_list:
                        try:
                            curr_alt_contact = lacctc.get_alternate_contact(AccountId=acct['Id'], AlternateContactType = dc['AlternateContactType'])
                        except Exception as ex1:
                            curr_alt_contact={'AlternateContact': {}}
                            # print(ex1)
                            # continue

                        print('[Existing][DryRun=%s],%s,%s,%s,%s,"%s"' %(args.to_dryrun, acct['Status'], acct['Id'], acct['Email'], acct['Name'], curr_alt_contact['AlternateContact']))

                        if dc != curr_alt_contact['AlternateContact']:
                            print('[Updating][DryRun=%s]%s,%s,%s,%s,"%s"' %(args.to_dryrun, acct['Status'], acct['Id'], acct['Email'], acct['Name'], dc))

                            if not args.to_dryrun:
                                try:
                                    lacctc.put_alternate_contact(
                                        AccountId=acct['Id'],
                                        AlternateContactType=dc['AlternateContactType'],
                                        EmailAddress=dc['EmailAddress'],
                                        Name=dc['Name'],
                                        PhoneNumber=dc['PhoneNumber'],
                                        Title=dc['Title'])
                                except Exception as ex2:
                                    print(ex2)
                else:
                    print('[Skipping][DryRun=%s],%s,%s,%s,%s - not @va.gov or valid AWS root account email' % (args.to_dryrun, acct['Status'], acct['Id'], acct['Email'], acct['Name']))

    except Exception as ex:
        raise ex

if __name__== "__main__":
  main()
