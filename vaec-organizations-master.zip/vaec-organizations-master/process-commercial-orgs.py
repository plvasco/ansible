import argparse
import re
import boto3
import logging
import csvmod
import sessionmod
import tagmod
import orgsmod
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 process-commercial-orgs.py --account-list-file acct-list-test.csv
#python3 process-commercial-orgs.py --force --nodryrun --account-id 460514156203
#python3 process-commercial-orgs.py --account-id 082551028634,606973029050,460514156203

parser = argparse.ArgumentParser(description='Iterate account list to tag commercial AWS Organizations')
parser.add_argument('--account-id', dest='remote_account_id', required=True, help='all or comma-separated list of account-id to be processed from account-list-file')
parser.add_argument('--region', dest='region_id', default='us-east-2', help='all is invalid')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
parser.add_argument('--force', dest='to_enforce', action='store_true', default=False, help='Force applying all desired Tag key-value pairs, Default is disabled')
parser.add_argument('--account-list-file', dest='input_file', default='vaec-aws-accounts.csv', help='AWS account list in csv as filename.csv')
parser.add_argument('--action', dest='action', default='process', choices=['process', 'deactivate'], help='action to be performed')

args = parser.parse_args()

AWS_PARTITION_COLUMN = {
    'aws': 'CommercialID',
    'aws-us-gov': 'GovCloudID'
}

#---------------------------------------------------------------------------
# Update AWS Organizations based on provided Account List CSV file

def main():
    try:
        orgsmod.to_dryrun = args.to_dryrun
        tagmod.to_dryrun = args.to_dryrun
        tagmod.to_enforce = args.to_enforce

        session_assumed = sessionmod.aws_session3(sessionmod.get_orgs_mgmt_account(args.region_id), args.region_id)
        lorgc = session_assumed.client('organizations')

        input_account_list= [a.strip() for a in args.remote_account_id.split(',')]

        process_account_list_file(lorgc, args.input_file, args.region_id, input_account_list, args.action)

    except ClientError as ex:
        raise ex

#---------------------------------------------------------------------------
def process_account_list_file(lorgc, input_file, region_id, input_account_list, action):
    try:
        partition=sessionmod.get_partition(region_id)
        orgs_ous = sessionmod.VA_DEFAULTS[partition]['OrgsOUs']
        acct_id_column = AWS_PARTITION_COLUMN[partition]
        # tag_key_prefix = sessionmod.VA_AWS_CONTEXT.lower() + ':'
        tag_key_prefix = 'vaec:'

        acct_id_tag_to_apply = None
        if acct_id_column == 'GovCloudID':
            acct_id_tag_to_apply = 'CommercialID'
        elif acct_id_column == 'CommercialID':
            acct_id_tag_to_apply = 'GovCloudID'

        # Get list of active accounts in AWS Organizations
        active_account_list = sessionmod.get_active_account_list(lorgc)

        if not active_account_list:
            return

        filedata = csvmod.getcsv2dict(input_file)
        for row in filedata:
            to_process=True
            acct_id=row[acct_id_column].strip()
            c_grp = row['CommercialGroup'].strip().lower()
            g_grp = row['GovCloudGroup'].strip().lower()

            if (action in ['deactivate']) and (input_account_list == ['all']):
                logger.error("action='deactivate' invalid with --account-id=all to prevent accidental update of entire Organizations membership")
                to_process=False
                return
            elif not acct_id:
                # logger.error("%s='%s' - no account id, skipping" %(acct_id_column, acct_id))
                to_process=False
            elif not re.match(r'[0-9]{12}', acct_id):
                logger.error("%s: %s invalid in %s" %(acct_id_column, acct_id, input_file))
                to_process=False
            elif (input_account_list != ['all']) and (acct_id not in input_account_list):
                # logger.error("%s: %s - skip based on input parameters" %(acct_id_column, acct_id))
                to_process=False
            elif acct_id not in active_account_list:
                logger.error("%s: %s not active in Organizations" %(acct_id_column, acct_id))
                to_process=False
            elif (action in ['process']) and (c_grp not in orgs_ous):
                logger.error("%s %s action='%s' invalid CommercialGroup='%s', allowed=%s" %(acct_id_column, acct_id, action, c_grp, orgs_ous))
                to_process=False
            elif (action in ['deactivate']) and (c_grp not in ['c-suspended']):
                logger.error("%s %s action=%s with CommercialGroup=%s is invalid, set to 'c-suspended'" %(acct_id_column, acct_id, action, c_grp))
                to_process=False

            if to_process:
                logger.info("%s: %s CommercialGroup: %s GovCloudGroup: %s -------------" %(acct_id_column, acct_id, c_grp, g_grp))
                if action in ['process']:
                    # --- Move account to specified Orgs-OU
                    orgsmod.move_account_to_org_ou(lorgc, acct_id, c_grp)

                    # --- Tag account in Organizations
                    desired_tag_list=[]
                    if row['VAECID']:
                        desired_tag_list.append({'Key':tag_key_prefix + 'VAECID', 'Value': row['VAECID'].strip()})
                    if row['ProjectShort']:
                        desired_tag_list.append({'Key':tag_key_prefix + 'ProjectShort', 'Value': row['ProjectShort'].strip()})
                    if row['ProjectName']:
                        desired_tag_list.append({'Key':tag_key_prefix + 'ProjectName', 'Value': row['ProjectName'].strip()})
                    if row['AppCode']:
                        desired_tag_list.append({'Key':tag_key_prefix + 'AppCode', 'Value': row['AppCode'].strip()})
                    if row['CKID']:
                        desired_tag_list.append({'Key':tag_key_prefix + 'CKID', 'Value': row['CKID'].strip()})
                    if row[acct_id_tag_to_apply]:
                            desired_tag_list.append({'Key':tag_key_prefix + acct_id_tag_to_apply, 'Value': row[acct_id_tag_to_apply].strip()})
                    tagmod.tag_orgs_resource(lorgc, acct_id, desired_tag_list)

                elif action in ['deactivate']:
                    orgsmod.move_account_to_org_ou(lorgc, acct_id, c_grp)
                else:
                    logger.info("%s: %s - nothing to process" %(acct_id_column, acct_id))

    except ClientError as ex:
        raise ex

#---------------------------------------------------------------------------
if __name__== "__main__":
  main()
