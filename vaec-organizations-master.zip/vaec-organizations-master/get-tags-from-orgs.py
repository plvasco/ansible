import argparse
import sys
import boto3
import sessionmod
import orgsmod
import tagmod
import json
from botocore.exceptions import ClientError

#usage example
# bash-4.2$ out=`python3 get-tags-from-orgs.py --account-id 477310831272 --tag-key vaec:ProjectShort 2>&1 > /dev/null`
# bash-4.2$ echo $out
# VAEC-GSS
# bash-4.2$ out=`python3 get-tags-from-orgs.py --account-id 477310831272 2>&1 > /dev/null`
# bash-4.2$ echo $out
# [{"Key": "AppCode", "Value": "ECS"}, {"Key": "VAECID", "Value": "AWG20170915001"}, {"Key": "ProjectName", "Value": "AWS Gov General Support Service"}, {"Key": "ProjectShort", "Value": "VAEC-GSS"}]


parser = argparse.ArgumentParser(description='Get account specific tags from AWS Organizations')
parser.add_argument('--account-id', dest='remote_account_id', required=True, help='remote account-id')
parser.add_argument('--tag-key', dest='tag_key', required=False, help='Tag Name')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all is invalid')

args = parser.parse_args()

#---------------------------------------------------------------------------
def main(argv):
    try:
        lsession_assumed = sessionmod.aws_session3(sessionmod.get_orgs_mgmt_account(args.region_id), args.region_id)
        lorgc = lsession_assumed.client('organizations')
        tags = tagmod.get_tags_from_orgs_resource(lorgc, args.remote_account_id)
        #print(tags)
        if args.tag_key:
            #print("tag name:" + args.tag_key)
            tag_value=get_tag_value(tags, args.tag_key)
            if tag_value:
                #print("tag name:" + args.tag_key + ", tag value:" +tag_value)
                return tag_value
            raise Exception("Tag can't be found:" + args.tag_key)
        else:
            return json.dumps(tags)

    except ClientError as ex:
        raise ex

def get_tag_value(tags, tag_key):
    value=None
    for tag in tags:
        if tag['Key'] == tag_key:
            value = tag['Value']
            break;
    return value

if __name__== "__main__":
  tags=main(sys.argv)
  print(tags)
  sys.exit(0)
