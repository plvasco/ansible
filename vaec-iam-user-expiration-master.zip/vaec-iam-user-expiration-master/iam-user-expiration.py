import boto3
from botocore.exceptions import ClientError
import os
import csv
import datetime
import dateutil.parser

from time import sleep

INACTIVE_GRACE_PERIOD = int(os.environ['INACTIVE_GRACE_PERIOD'])
DRYRUN = bool(os.environ['DRYRUN'].lower() != 'false')

def lambda_handler(event, context):
    
    iam_client = boto3.client('iam')

    credential_report = get_credential_report(iam_client)
    print(DRYRUN, INACTIVE_GRACE_PERIOD)

    for row in credential_report:

        if (row['password_enabled'] != "true" or # Skip IAM Users without passwords, they are service accounts
            row['user'] == "<root_account>" or   # Skip root account
            row['user'] == "Administrator"):     # Skip Administrator account
                continue

        if row['password_last_used'] == 'no_information':
            last_changed_date=dateutil.parser.parse(row['user_creation_time']).date()
        else:
            last_changed_date=dateutil.parser.parse(row['password_last_used']).date()

        if (last_changed_date + datetime.timedelta(INACTIVE_GRACE_PERIOD)) < datetime.date.today():
            print("User=%s, Deactivate = Yes, Password last activity= %s" % (row['user'], last_changed_date.strftime("%Y-%m-%d")))
            try:
                # Make Keys inactive
                response = iam_client.list_access_keys(UserName=row['user'])
                for key in response['AccessKeyMetadata'] :
                    if key['Status'] == "Active":
                        if DRYRUN == False:
                            response = iam_client.update_access_key(UserName=row['user'], AccessKeyId=key['AccessKeyId'], Status='Inactive')
                        print("User=%s removed AccessKey=%s" % (row['user'], key['AccessKeyId']))
        
                # Remove users from all Groups
                user_groups = iam_client.list_groups_for_user(UserName=row['user'])
                for g in user_groups['Groups']:
                    if DRYRUN == False:
                        response = iam_client.remove_user_from_group(GroupName=g['GroupName'], UserName=row['user'])
                    print("User=%s removed from Group=%s" % (row['user'], g['GroupName']))
                
                # Remove user MFA Device
                user_mfa_devices = iam_client.list_mfa_devices(UserName=row['user'])
                for d in user_mfa_devices['MFADevices']:
                    if DRYRUN == False:
                        response = iam_client.deactivate_mfa_device(SerialNumber=d['SerialNumber'], UserName=row['user'])
                    print("User=%s deactivated MFA=%s" % (row['user'], d['SerialNumber']))
                    if DRYRUN == False:
                        response = iam_client.delete_virtual_mfa_device(SerialNumber=d['SerialNumber'])
                    print("Removed MFA=%s" % (d['SerialNumber']))
                
                # Remove user inline policies
                user_inline_policies = iam_client.list_user_policies(UserName=row['user'])
                for i_policy in range(len(user_inline_policies['PolicyNames'])):
                    print("User=%s removed inline policies=%s" % (row['user'], user_inline_policies['PolicyNames'][i_policy]))
                    if DRYRUN == False:
                        response = iam_client.delete_user_policy(UserName=row['user'],PolicyName=user_inline_policies['PolicyNames'][i_policy])

                # Remove user managed policies
                user_managed_policies = iam_client.list_attached_user_policies(UserName=row['user'])
                for m_policy in user_managed_policies['AttachedPolicies']:
                    print("arn:", m_policy['PolicyArn'])
                    if DRYRUN == False:
                        response = iam_client.detach_user_policy(UserName=row['user'],PolicyArn=m_policy['PolicyArn'])
                    print("User=%s removed managed policy=%s" % (row['user'], m_policy['PolicyArn']))
                    
                # Deactivate Console Access
                if DRYRUN == False:
                    response = iam_client.get_login_profile(UserName=row['user'])
                    if response['LoginProfile']['UserName']:
                        response = iam_client.delete_login_profile(UserName=row['user'])
                        print("User:%s login profile deleted" % (row['user']))
                    else:
                        print("User:%s login profile does not exist" % (row['user']))

            except ClientError as e:
                raise
    return

# Request the credential report, download and parse the CSV.
def get_credential_report(iam_client):
    resp1 = iam_client.generate_credential_report()
    if resp1['State'] == 'COMPLETE' :
        try: 
            response = iam_client.get_credential_report()
            credential_report_csv = response['Content'].decode('utf8')
            reader = csv.DictReader(credential_report_csv.splitlines())
            # print(reader.fieldnames)
            credential_report = []
            for row in reader:
                credential_report.append(row)
            return(credential_report)
        except ClientError as e:
            raise
    else:
        sleep(2)
        return get_credential_report(iam_client)
