# vaec-iam-user-expiration
Expire IAM users that are inactive for more than specified days


This script contains a CloudFormation template with Lambda function and Python script. The Lambda function gets triggered periodically (default=weekly) and performs the following:

- Pulls Credential Report from IAM and iterates through all the users

- Ignore users with _password_enabled_ = FALSE since these could be service accounts, or previously deactivated users

- Ignore _<root_account>_ and _Administrator_ - these are needed for GovCloud administration

- Iterate through the remaining users. If the _password_last_used_ date is older than _INACTIVE_GRACE_PERIOD_ (default = 60) days, then perform the following:
  - Deactivate Console access by deleting user login profile
  - Remove user from all IAM Groups
  - Make user's access keys Inactive
  - Deactivate user MFA devices
  - Remove user virtual MFA devices
  - Remove user inline policies
  - Remove user direct attached IAM Managed Policies
  
- Set _DRYRUN_ = True (Default=False) for a dry run of changes that would be otherwise executed.


### Note
7-24-2019 - Default _INACTIVE_GRACE_PERIOD_ changed to 60 days (previously 90 days) 

~~~
From: US Department of Veterans Affairs 
Sent: Monday, July 08, 2019 11:29 AM
To: VAAllEXOMailboxes <VAAllEXOMailboxes@va.gov>
Subject: FOR ALL-VA DISTRO: VA Updates Password Policies

  
 
VA updates password policies

To strengthen the Department of Veterans Affairs (VA) cybersecurity posture, the Office of Information and Technology (OIT) is updating password requirements in accordance with VA Handbook 6500 to better protect VA systems and Veteran data from malicious attacks and external threats. Effective July 9, 2019, employees and contractors who are Personal Identity Verification (PIV)-exempt and log in to Microsoft Windows using a username and password will experience the following changes:
•	Password length will increase from eight characters (or 12 for those with elevated privilege accounts) to a minimum of 14 characters
•	Change will occur upon expiration of current password 
•	Password expiration will occur every 60 days vice 90 days (or will follow current policy for Service Accounts)
•	Reduced failed login attempts before account lockout changed from five attempts to three

Please note: Those using a PIV card to login do not need to take any action at this time.








~~~
