**EC2 Imager Builder Components scripts**
