**EC2 Image Builder Component Scripts**
