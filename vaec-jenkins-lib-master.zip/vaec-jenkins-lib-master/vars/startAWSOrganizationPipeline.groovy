def Initiate() {
    node {
        // Execute different stages depending on the job
        if(env.JOB_NAME.contains("deploy")){
            deploy()
        } else if(env.JOB_NAME.contains("test")) {
            stage('delete __pycache__ directory from workspace') {
                  sh 'sudo rm -rf ./__pycache__/*'
            }
            validateAndTestOrganizationPipeline.validateAndTest()
        }
    }
}

def deploy(){
  node {
      stage('delete __pycache__ directory from workspace') {
            sh 'sudo rm -rf ./__pycache__/*'
      }

      stage('Checkout') {
        checkout scm
      }
      commonVaecOrganization.executeAnsiblePlaybook()
  }
}
