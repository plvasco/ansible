
def validateAndTest(){

       initializeParameters()
       //commonVaecVPC.ignoreFirstBuild()

        stage('Checkout') {
            checkout scm
        }

        //commonVaecLZ.validateCFNTemplates()
        commonVaecLZ.executeAnsiblePlaybook()
        //commonVaecLZ.executeSpecTests()


}

def initializeParameters()
{
    String sectionHeaderStyle = '''
      color: black;
      background: #7FAB9B;
      font-family: Roboto, sans-serif !important;
      font-weight: bold;
      padding: 5px;
      text-align: center;
    '''

    String separatorStyle = '''
      border: 0;
      border-bottom: 1px dashed #ccc;
      background: #999;
    '''

  properties([[$class: 'RebuildSettings', autoRebuild: false, rebuildDisabled: false],
  parameters([
            [
                     $class: 'ParameterSeparatorDefinition',
                     name: 'HEADER',
                     sectionHeader: 'Mandatory parameters for all type of tasks',
                     separatorStyle: separatorStyle,
                     sectionHeaderStyle: sectionHeaderStyle
            ],
           string(defaultValue: '', description: 'Comma separated AWS Account IDs. Can specify \'all\' if ANSIBLE_TAGS is load_ssm_params', name: 'ACCOUNTID', trim: true),
           string(defaultValue: 'assume', description: 'assume, account_init (policies, authorizer_role, load_ssm_params, idp_adfs_create, landingzone, project_admin), account_controls (delete_Default_ct, ssm_explorer_enable), delete_cfn_stack\n\n [Include ANSIBLE_TAGS=\'assume\' for ACCOUNTID= single/multiple accounts, do not include \'assume\' if ACCOUNTID=all]\n\nExample1: Single account (us-gov-west-1): assume, account_init, account_controls\nExample2: Multi account (us-gov-west-1): assume, project_admin\nExample3: Multi account, \'all\' accounts, all regions (AWS_REGION ignored): load_ssm_params\n', name: 'ANSIBLE_TAGS', trim: true),
           string(defaultValue: '', description: 'delete_cfn_stack: AWS CloudFormation stack name to be deleted', name: 'CFN_STACK_TO_BE_DELETED', trim: true),
           [
                    $class: 'ParameterSeparatorDefinition',
                    name: 'HEADER',
                    sectionHeader: 'Miscellaneous parameters with default values which seldom change',
                    separatorStyle: separatorStyle,
                    sectionHeaderStyle: sectionHeaderStyle
           ],
           string(defaultValue: 'us-gov-west-1', description: 'AWS Region', name: 'AWS_REGION', trim: true),
           string(defaultValue: 'vaec/vaec-authorizer', description: 'AWS Role Name', name: 'ROLENAME', trim: true),
		   string(defaultValue: 'ab06fe02-6ecd-4868-bd92-526b7fcd4028', description: 'External Id', name: 'EXTERNALID', trim: true),
           string(defaultValue: 'vaec-automation-348286891446-us-gov-west-1', description: 'Shared S3 bucket name for storing vaec-automation stacks and code', name: 'AUTOMATION_BUCKET',trim: true),
           string(defaultValue: 'https://prod.adfs.federation.va.gov/federationmetadata/2007-06/federationmetadata.xml', description: 'XML metadata document to use when trusting the Identity Provider', name: 'pMetadataDocument', trim: true),
           string(defaultValue: 'vaec-automation', description: 'init: S3 bucket name for storing vaec-automation stacks and code', name: 'pBucketNamePrefix',trim: true),
           string(defaultValue: '-v', description: 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode', name: 'VERBOSITY')
           ])])
}
