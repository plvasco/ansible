def Initiate() {
    node {
        // Execute different stages depending on the job

         println("JOB_NAME:" + env.JOB_NAME)

        if(env.JOB_NAME.contains("vpc-tgw-pipeline")){
          if(env.JOB_NAME.contains("deploy")){
              deployVaecVPC.deploy(env.JOB_NAME)
          } else if(env.JOB_NAME.contains("test")) {
              validateAndTestVaecVPCTGW.validateAndTest()
          }
        }
        /*
        else if(env.JOB_NAME.contains("vpc-vgw-pipeline")){
          if(env.JOB_NAME.contains("deploy")){
              deployVaecVPC.deploy(env.JOB_NAME)
          } else if(env.JOB_NAME.contains("test")) {
              validateAndTestVaecVPCVGW.validateAndTest()
          }
        } else if(env.JOB_NAME.contains("vaec-vpc-pipeline")){
          if(env.JOB_NAME.contains("deploy")){
              deployVaecVPC.deploy(env.JOB_NAME)
          } else if(env.JOB_NAME.contains("test")) {
              validateAndTestVaecVPC.validateAndTest()
          }
        }
        */
    }
}
