
def validateAndTest(){

       initializeParameters()
        stage('Checkout') {
            checkout scm
        }
        commonVaecOrganization.executeAnsiblePlaybook()
}

def initializeParameters()
{
    String sectionHeaderStyle = '''
      color: black;
      background: #7FAB9B;
      font-family: Roboto, sans-serif !important;
      font-weight: bold;
      padding: 5px;
      text-align: center;
    '''

    String separatorStyle = '''
      border: 0;
      border-bottom: 1px dashed #ccc;
      background: #999;
    '''

  properties([[$class: 'RebuildSettings', autoRebuild: false, rebuildDisabled: false],
  parameters([
            [
                     $class: 'ParameterSeparatorDefinition',
                     name: 'HEADER',
                     sectionHeader: 'Mandatory parameters for all type of tasks',
                     separatorStyle: separatorStyle,
                     sectionHeaderStyle: sectionHeaderStyle
            ],
           string(defaultValue: '', description: 'Comma separated AWS Account IDs. Specify \'all\' if ANSIBLE_TAGS is orgs_process_member', name: 'ACCOUNTID', trim: true),
           string(defaultValue: '',
                  description: 'orgs_process_member, python_execute',
                  name: 'ANSIBLE_TAGS',
                  trim: true),
          //string(defaultValue: '',
          //       description: 'Tag key for organization member. This is requred if orgs_get_account_tags specified in ANISBLE_TAGS,\nExample: vaec:ProjectShort, vaec:AppCode, vaec:VAECID, vaec:CommercialID, vaec:ProjectName',
          //       name: 'TAG_KEY',
          //       trim: true),
        //   [
        //            $class: 'ParameterSeparatorDefinition',
        //            name: 'HEADER',
        //            sectionHeader: 'Required if ANSIBLE_TAGS contains \'orgs_process_member\'',
        //            separatorStyle: separatorStyle,
        //            sectionHeaderStyle: sectionHeaderStyle
        //   ],

        //   file(name:'pVaecAwsAccountsFile', description: 'VAEC-AWS-Accounts.xlsx: Download to desktop from https://dvagov.sharepoint.com/sites/OITECSOApplication/Environments/AWS/VAEC-AWS-Accounts.xlsx. Worksheet must be \"VAEC-AWS-Accounts\"'),
		// string(defaultValue: 'vaec-authorizer-role', description: 'AWS Role Name', name: 'ROLENAME', trim: true),
           [
                    $class: 'ParameterSeparatorDefinition',
                    name: 'HEADER',
                    sectionHeader: 'Miscellaneous parameters with default values which seldom change',
                    separatorStyle: separatorStyle,
                    sectionHeaderStyle: sectionHeaderStyle
           ],
           string(defaultValue: 'us-gov-west-1', description: 'AWS Region', name: 'AWS_REGION', trim: true),
           string(defaultValue: '-v', description: 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode', name: 'VERBOSITY'),

           [
                    $class: 'ParameterSeparatorDefinition',
                    name: 'HEADER2',
                    sectionHeader: 'Command for executing python, from root of repo https://github.ec.va.gov/AWS/vaec-organizations',
                    separatorStyle: separatorStyle,
                    sectionHeaderStyle: sectionHeaderStyle
           ],

           string(defaultValue: '',
                  description: 'Specify python_execute tag value in ANSIBLE_TAGS parameter to execute python command from inventory folder. \nexample format:\n1. inventory/vaec_inventory_ec2inst.py --account-id 477194928391 --region all\n2. get-tags-from-orgs.py --account-id 477310831272\n3. get-accountids-from-orgs.py\n4. inventory/vaec_accountids_with_vpcs.py --region us-gov-east-1\n5. inventory/decode_auth_msg.py --account-id <acctid> --region <region> --encoded-message "<encoded-message>"',
                  name: 'EXEC_PARAMS')


           ])])

}
