def deploy(String jobName){
  node {

      stage('delete __pycache__ directory from workspace') {
            sh 'sudo rm -rf ./python/*'
            sh 'sudo rm -rf ./flowlog/*'
      }

      stage('Checkout') {
          checkout scm
      }
      if(jobName.contains("vpc-tgw-pipeline")){
        //commonVaecVPC.validateCFNTemplates()
        commonVaecVPC.executeAnsiblePlaybookForTGW()
        //commonVaecVPC.executeSpecTests()
      } 
      /*
      else if(jobName.contains("vpc-vgw-pipeline")){
        //commonVaecVPC.validateCFNTemplates()
        commonVaecVPC.executeAnsiblePlaybookForVGW()
        //commonVaecVPC.executeSpecTests()
      }
      */
  }
}

/*
def deploy(){
  node {

      stage('Checkout') {
          checkout scm
      }
      //commonVaecVPC.validateCFNTemplates()
      commonVaecVPC.executeAnsiblePlaybook()
      //commonVaecVPC.executeSpecTests()
  }
}
*/
