runParallel = true
buildStages
//pVaecAwsAccountsFile=''

def executeAnsiblePlaybook() {
  runParallel = true
  echo params.aws_account_list
  env.getEnvironment().each { name, value -> println "$name = $value" }
  
  //pVaecAwsAccountsFile = getFileParamFromWorkspace('pVaecAwsAccountsFile')
  //echo pVaecAwsAccountsFile

  //if (params.ANSIBLE_TAGS.trim().contains('organizations') || params.ANSIBLE_TAGS.trim().contains('account_init'))
  //{
  //  if(pVaecAwsAccountsFile.equals(''))
  //  {
  //    currentBuild.result = 'ABORTED'
  //    error('AWS account list file is not specified.')
  //  }
  //}

  stage('Validate Parameters')
  {
    validateParameters()
  }
  initBuild()

  stage("Initialize parallel build for Ansible tags:${params.ANSIBLE_TAGS}") {
    // Set up List<Map<String,Closure>> describing the builds
    buildStages = prepareBuildStages()
    println("Initialized pipeline.")
  }

  for (builds in buildStages) {
      parallel(builds)
    }


  stage('Finish') {
      println('Build complete.')
  }

}
// Create List of build stages to suit
def prepareBuildStages() {
  def buildList = []
  def List<String> awsAccountIDs = params.ACCOUNTID.split(',')
  def count = awsAccountIDs.size()
  def index = 0
  def maxCount = 8
  def buildStages = [:]
  def account8 = 0
  for (String awsAccountID : awsAccountIDs) {

      awsAccountID=awsAccountID.trim()
      if(index < maxCount)
      {
        buildStages.put(awsAccountID, prepareOneBuildStage(awsAccountID))
        //We can add a test stage in future as below example
        //buildStages.put(awsAccountID+"Test Stage", prepareTestStage(awsAccountID+"Test Stage"))
      }
      else
      {
        println("account8: " + account8)
        account8++
        buildList.add(buildStages)
        index = 0
        buildStages = [:]
        buildStages.put(awsAccountID, prepareOneBuildStage(awsAccountID))

      }
      index++
  }
  buildList.add(buildStages)
  println("buildList.size():" + buildList.size())
  return buildList
}

def prepareOneBuildStage(String awsAccountID) {
  return {
    stage("AWS Account: " +awsAccountID) {
      println("Building ${params.ANSIBLE_TAGS} - " + awsAccountID)
      //pVaecAwsAccountsFilePath=env.WORKSPACE+"/"+pVaecAwsAccountsFile
      script {sh '''
          export AWS_DEFAULT_REGION=${AWS_REGION}
          echo $AWS_DEFAULT_REGION
          pwd
          cd ansible && ansible-playbook main.yml \
          -e STACK_DESCRIPTION="${STACK_DESCRIPTION}" \
          -e ROLENAME=${ROLENAME} \
		  -e EXTERNALID=${EXTERNALID} \
          -e ACCOUNTID='''+awsAccountID+''' \
          -e pJenkinsBuildNo=${BUILD_NUMBER} \
          -e AWS_REGION=${AWS_REGION} \
          -e pMetadataDocument=${pMetadataDocument} \
          -e pStackToBeDeleted=${CFN_STACK_TO_BE_DELETED} \
          -e pBucketNamePrefix=${pBucketNamePrefix} \
		  -e AUTOMATION_BUCKET=${AUTOMATION_BUCKET} \
		  -e JOB_NAME=${JOB_NAME} \
          --tags "${ANSIBLE_TAGS}" ${VERBOSITY} \
          -e ansible_python_interpreter=/usr/bin/python3
            '''}
    }
  }
}
        // -e pProjectName="${pProjectName}" \
        // -e pProjectShort="${pProjectShort}" \
        // -e pVAECId=${pVAECId} \
        // -e pAppCode=${pAppCode} \
        // -e TAG_KEY="${TAG_KEY}" \
        // -e TAG_VALUE="${TAG_VALUE}" \
        // -e pEnvironmentTag=${pEnvironmentTag} \
        // -e AMI_IDs=${AMI_IDs} \

def initBuild() {
    stage("Performing yum installs and git clone") {
      script {sh '''
          export AWS_DEFAULT_REGION=${AWS_REGION}
          echo $AWS_DEFAULT_REGION
          pwd
          cd ansible && ansible-playbook init.yml \
          -e pJenkinsBuildNo=${BUILD_NUMBER} \
          -e AWS_REGION=${AWS_REGION} \
		  -e AUTOMATION_BUCKET=${AUTOMATION_BUCKET} \
		  -e JOB_NAME=${JOB_NAME} \
          --tags "${ANSIBLE_TAGS}" ${VERBOSITY}
            '''}
    }


  //  if (params.ANSIBLE_TAGS.trim().contains('org'))
  //  {
  //    stage("Upload AWS account list file") {
  //        def inputFile = input message: 'Upload AWS account list file', parameters: [file(name: 'pVaecAwsAccountsFile', description: 'VAEC Account list excel file from local desktop')]
  //        println('pVaecAwsAccountsFile:'+inputFile.getName())
  //        new hudson.FilePath(new File("$workspace/aws_account_list.xslx")).copyFrom(inputFile)
  //        inputFile.delete()
  //    }
  //  }
}

def executeSpecTests() {

  if (params.TAGS.contains('vpc')) {
    stage("Execute awspec tests")
    {
        //def ansibleTags = ${TAGS}
          echo "Testing AWS resources"
          script {sh '''
          export ACCOUNTID=${ACCOUNTID}
          export ROLENAME=${ROLENAME}                                                                                    e
          export EXTERNALID=${EXTERNALID}
		  export AWS_REGION=${AWS_REGION}
          export STACKNAME=${STACK_NAME}
          export PROJECTSHORT="${pProjectShort}"
          export PATH=$PATH:/usr/local/rvm/rubies/ruby-2.5.3/bin
          cd spec-tests && bundle && rake spec
          '''}
        }
    }
  else
      echo "Skipping awspec tests"

}

def prepareTestStage(stageName) {
    return {
     stage("Build stage:${stageName}") {
       println("Building ${stageName}")
       sh(script:'sleep 5', returnStatus:true)
     }
    }
}

def validateCFNTemplates() {

  stage("Validating CFN templates using cfn-nag") {
    echo "Validating CFN templates using cfn-nag"
  }
}

def validateParameters()
{

  if(params.ACCOUNTID.trim().equals(''))
  {
      currentBuild.result = 'ABORTED'
      error('ACCOUNTID can not be blank')
  }
  else if(params.ANSIBLE_TAGS.trim().equals('') || params.ANSIBLE_TAGS.trim().equals('assume'))
  {
    currentBuild.result = 'ABORTED'
    error('Appropriate ANSIBLE_TAGS are not specified. Terminating landingzone deployment pipeline')
  }
  else if(params.ACCOUNTID.trim().equals('all') || params.ACCOUNTID.trim().equals('All') || params.ACCOUNTID.trim().equals('ALL'))
  {
    if(!params.ANSIBLE_TAGS.trim().contains('awsconfig_recorder_check') \
        // && !params.ANSIBLE_TAGS.trim().contains('ami_share') \
        && !params.ANSIBLE_TAGS.trim().contains('load_ssm_params') \
        // && !params.ANSIBLE_TAGS.trim().contains('organization') \
        && !params.ANSIBLE_TAGS.trim().contains('ssm_explorer_enable') \
        && !params.ANSIBLE_TAGS.trim().contains('ebs_encryption_enable') \
        // && !params.ANSIBLE_TAGS.trim().contains('ecs_account_default') \
        && !params.ANSIBLE_TAGS.trim().contains('guardduty_enable'))

    {
      currentBuild.result = 'ABORTED'
      error('You can specify \"all\" for ACCOUNTID, ONLY if load_ssm_params, awsconfig_recorder_check, ssm_explorer_enable,ebs_encryption_enable, ecs_account_default is specified in ANSIBLE_TAGS')
    }
    else if(params.ANSIBLE_TAGS.trim().contains('assume'))
    {
      currentBuild.result = 'ABORTED'
      error('You can not specify assume if you are using any of load_ssm_params, awsconfig_recorder_check')
    }
  }
  //else if (params.ANSIBLE_TAGS.trim().contains('init') || params.ANSIBLE_TAGS.trim().contains('load_ssm_params'))
  //{
  //  if(params.pVAECId.trim().equals('') || params.pAppCode.trim().equals(''))
  //  {
  //    currentBuild.result = 'ABORTED'
  //    error('pVAECId and pAppCode can not be blank when init or load_ssm_params is specified in ANSIBLE_TAGS')
//    }
//  }
  else if (params.ANSIBLE_TAGS.trim().contains('delete_cfn_stack'))
  {
    if(params.CFN_STACK_TO_BE_DELETED.trim().equals(''))
    {
      currentBuild.result = 'ABORTED'
      error('CFN_STACK_TO_BE_DELETED can not be blank when delete_cfn_stack is specified in ANSIBLE_TAGS')
    }
  }
  //else if (params.ANSIBLE_TAGS.trim().contains('load_ssm_params'))
  //{
  //  if(params.pVAECId.trim().equals(''))
  //  {
  //    currentBuild.result = 'ABORTED'
  //    error('pVAECId can not be blank when load_ssm_params is specified in ANSIBLE_TAGS')
//  }
//  }
}

def ignoreFirstBuild() {

  stage("parameterizing") {
      script {
          if ("${env.BUILD_NUMBER}" == "1") {
              currentBuild.result = 'ABORTED'
              error('DRY RUN COMPLETED. JOB PARAMETERIZED.')
          }
      }
  }
}
def createFilePath(path) {
    if (env['NODE_NAME'] == null) {
        error "envvar NODE_NAME is not set, probably not inside an node {} or running an older version of Jenkins!";
    } else if (env['NODE_NAME'].equals("master")) {
        return new hudson.FilePath(null, path)
    } else {
        return new hudson.FilePath(jenkins.model.Jenkins.instance.getComputer(env['NODE_NAME']).getChannel(), path)
    }
}
// def getFileParamFromWorkspace(fileParamName) {
//     def paramsAction = currentBuild.rawBuild.getAction(ParametersAction.class);
//     if (paramsAction != null) {
//         for (param in paramsAction.getParameters()) {
//             if (param instanceof FileParameterValue) {
//                 def fileParameterValue = (FileParameterValue)param
//                if (fileParamName.equals(fileParameterValue.getName())) {
//                    def fileItem = fileParameterValue.getFile()
//                    println('getFileParamFromWorkspace fileItem.getName(): '+fileItem.getName())
//                    if(fileItem.getName().equals(''))
//                        return ''
//                    if (fileItem instanceof org.apache.commons.fileupload.disk.DiskFileItem) {
//                        def diskFileItem = (org.apache.commons.fileupload.disk.DiskFileItem)fileParameterValue.getFile()
//                        //def filePath = createFilePath(env.WORKSPACE + '/' + fileItem.getName())
//                        def filePath = createFilePath('/var/lib/jenkins/vaec-organizations/' + fileItem.getName())
//
//                        def destFolder = filePath.getParent()
//                        destFolder.mkdirs()
//                        filePath.copyFrom(diskFileItem)
//                        //return fileItem.getName()
//                        println('getFileParamFromWorkspace filePath.getName(): '+filePath.getName())
//                        println('getFileParamFromWorkspace filePath.getParent(): '+filePath.getParent())
//                         return filePath.getName()
//                     }
//                 }
//             }
//         }
//     }
//     return ''
// }
