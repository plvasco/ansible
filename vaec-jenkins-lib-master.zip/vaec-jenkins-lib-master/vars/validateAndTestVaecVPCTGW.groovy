
import jenkins.plugins.parameter_separator.ParameterSeparatorDefinition

def validateAndTest(){

       initializeParameters()
       commonVaecVPC.ignoreFirstBuild()

        stage('Checkout') {
            checkout scm
        }
        //stage('Validate Templates') {
          //  echo "Validate Templates "
        //    echo "${params.ROLENAME} in Validate Templates"
        //}
        //commonVaecVPC.validateCFNTemplates()
        commonVaecVPC.executeAnsiblePlaybookForTGW()
        //commonVaecVPC.executeSpecTests()
}

def initializeParameters()
{
  String sectionHeaderStyle = '''
    color: black;
    background: #ffdab3;
    font-family: Roboto, sans-serif !important;
    font-weight: bold;
    padding: 5px;
    text-align: center;
  '''

  String separatorStyle = '''
    border: 0;
    border-bottom: 1px dashed #ccc;
    background: #999;
  '''

  properties([

      [$class: 'RebuildSettings', autoRebuild: false, rebuildDisabled: false],
      parameters([
      [
               $class: 'ParameterSeparatorDefinition',
               name: 'HEADER',
               sectionHeader: 'Mandatory parameters for VPC pipeline',
               separatorStyle: separatorStyle,
               sectionHeaderStyle: sectionHeaderStyle
      ],
      string(defaultValue: '', description: 'AWS Region us-gov-west-1 or us-gov-east-1', name: 'AWS_REGION'),
      string(defaultValue: '', description: 'AWS Account ID', name: 'ACCOUNTID'),
      string(defaultValue: 'assume', description: 'assume, vpc_tgw, post_vpc_creation (tag_default_sg_nacl_rtb, delete_default_sg_ingress_egress, msg_tgwa_handler, create_vpc_flowlog)\n example1: assume, vpc_tgw, post_vpc_creation', name: 'ANSIBLE_TAGS'),

      [
               $class: 'ParameterSeparatorDefinition',
               name: 'HEADER',
               sectionHeader: 'Mandatory parameters for VPC creation',
               separatorStyle: separatorStyle,
               sectionHeaderStyle: sectionHeaderStyle
      ],
      string(defaultValue: '', description: 'VPC environment tag. Example values: Development, Stage, Production, Mgmt', name: 'pEnvTag'),
      string(defaultValue: '', description: 'ConnectionId. Format: 31X-XXX', name: 'pConnectionId'),
      string(defaultValue: '', description: ' Comma-delimited list of VPC IPv4 CIDRs', name: 'pVpcCidrs'),
      string(defaultValue: '', description: 'Comma-delimited list of subnet IPv4 CIDRs', name: 'pVpcSubnetCidrs'),
      // string(defaultValue: '192.168.82.0/24', description: 'Comma Delimited list of VPC Secondary CIDRs', name: 'pVpcSecondaryCidrs'),
      string(defaultValue: '../cfn-tgw/vpc-1-az-2-subnet-4.yml', description: 'VPC CloudFormation template from https://github.ec.va.gov/AWS/vaec-vpc/tree/master/cfn-tgw (vaec-vpc Git repo).\nInclude ../cfn-tgw/, but do not include .j2 extension.', name: 'pVpcCfnPath'),
      string(defaultValue: '', description: 'Subnet Tier Variables\nExample1:App,Data\nExample2:App1,App2,Data1,Data2', name: 'pTierVar'),
      [
               $class: 'ParameterSeparatorDefinition',
               name: 'HEADER',
               sectionHeader: 'Common pipeline parameters with default values',
               separatorStyle: separatorStyle,
               sectionHeaderStyle: sectionHeaderStyle
      ],
      string(defaultValue: 'vaec/vaec-authorizer', description: 'AWS cross account Assume Role Name', name: 'ROLENAME'),
	  string(defaultValue: 'ab06fe02-6ecd-4868-bd92-526b7fcd4028', description: 'External Id', name: 'EXTERNALID', trim: true),
      // string(defaultValue: 'vaec-automation', description: 'Bucket name for storing script files related to VPC pipeline. Default value is vaec-automation', name: 'pBucketNamePrefix'),
      string(defaultValue: 'Name', description: 'Tag key', name: 'TAG_KEY'),
      string(defaultValue: '"DEFAULT - DO NOT USE"', description: 'Tag value', name: 'TAG_VALUE'),
      string(defaultValue: '-v', description: 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode', name: 'VERBOSITY')
      ])])
}
