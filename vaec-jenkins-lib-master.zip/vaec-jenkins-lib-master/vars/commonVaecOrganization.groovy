buildStages
//pVaecAwsAccountsFile=''

def executeAnsiblePlaybook() {
  runParallel = true
  echo params.aws_account_list

  //if (params.ANSIBLE_TAGS.trim().contains('orgs_process_member'))
  //{
//    if(pVaecAwsAccountsFile.equals(''))
//    {
//      currentBuild.result = 'ABORTED'
//      error('AWS account list file is not specified.')
//    }
//  }

  stage('Validate Parameters')
  {
    validateParameters()
  }
  if(params.ANSIBLE_TAGS.trim().equals('python_execute'))
  {
      validatePythonCommand()
      executePythonCommand()
  }
  else
    startBuild()


  stage('Finish') {
      println('Build complete.')
  }

}

def executePythonCommand()
{
    stage('Executing python command') {

        script {sh '''
          export PYTHONPATH=$VAECLIBPATH:$PYTHONPATH
          python3 ${EXEC_PARAMS}
        '''}
    }
}

def validatePythonCommand()
{
  stage('Validating python command') {
    if(params.EXEC_PARAMS.startsWith("python"))
    {
        currentBuild.result = 'ABORTED'
        error('No need to prefix command with python')
    }

  }
}
def startBuild() {
    //pVaecAwsAccountsFile = getFileParamFromWorkspace('pVaecAwsAccountsFile')
    //echo pVaecAwsAccountsFile

    stage("Executing:" + params.ANSIBLE_TAGS) {
      script {sh '''
          export AWS_DEFAULT_REGION=${AWS_REGION}
          echo $AWS_DEFAULT_REGION
          pwd
          cd ansible && ansible-playbook main.yml \
          -e pJenkinsBuildNo=${BUILD_NUMBER} \
          -e ACCOUNTID=${ACCOUNTID} \
          -e AWS_REGION=${AWS_REGION} \
          -e EXEC_PARAMS="${EXEC_PARAMS}" \
          --tags "${ANSIBLE_TAGS}" ${VERBOSITY}
            '''}
    }

}
//-e ROLENAME=${ROLENAME} \
def validateParameters()
{


  if(params.ANSIBLE_TAGS.trim().equals(''))
  {
    currentBuild.result = 'ABORTED'
    error('Appropriate ANSIBLE_TAGS are not specified. Terminating organization deployment pipeline')
  }
  if(!params.ANSIBLE_TAGS.trim().contains('orgs_process_member') \
      && !params.ANSIBLE_TAGS.trim().contains('python_execute') \
      && !params.ANSIBLE_TAGS.trim().contains('script_execute'))
  {
    currentBuild.result = 'ABORTED'
    error('Invalid ANSIBLE_TAGS. Valid tags are, orgs_process_member and python_execute. Terminating organization deployment pipeline')
  }
  else if(params.ANSIBLE_TAGS.trim().contains('orgs_remove_member'))
  {
      if(!params.ACCOUNTID.trim().equals('all'))
      {
        currentBuild.result = 'ABORTED'
        error('ACCOUNTID can not be all for orgs_remove_member tag')
      }
  }

}

def ignoreFirstBuild() {

  stage("parameterizing") {
      script {
          if ("${env.BUILD_NUMBER}" == "1") {
              currentBuild.result = 'ABORTED'
              error('DRY RUN COMPLETED. JOB PARAMETERIZED.')
          }
      }
  }
}
def createFilePath(path) {
    if (env['NODE_NAME'] == null) {
        error "envvar NODE_NAME is not set, probably not inside an node {} or running an older version of Jenkins!";
    } else if (env['NODE_NAME'].equals("master")) {
        return new hudson.FilePath(null, path)
    } else {
        return new hudson.FilePath(jenkins.model.Jenkins.instance.getComputer(env['NODE_NAME']).getChannel(), path)
    }
}
def getFileParamFromWorkspace(fileParamName) {
    def paramsAction = currentBuild.rawBuild.getAction(ParametersAction.class);
    if (paramsAction != null) {
        for (param in paramsAction.getParameters()) {
            if (param instanceof FileParameterValue) {
                def fileParameterValue = (FileParameterValue)param
                if (fileParamName.equals(fileParameterValue.getName())) {
                    def fileItem = fileParameterValue.getFile()
                    println('getFileParamFromWorkspace fileItem.getName(): '+fileItem.getName())
                    if(fileItem.getName().equals(''))
                        return ''
                    if (fileItem instanceof org.apache.commons.fileupload.disk.DiskFileItem) {
                        def diskFileItem = (org.apache.commons.fileupload.disk.DiskFileItem)fileParameterValue.getFile()
                        def filePath = createFilePath(env.WORKSPACE + '/' + fileItem.getName())
                        def destFolder = filePath.getParent()
                        destFolder.mkdirs()
                        filePath.copyFrom(diskFileItem)
                        //return fileItem.getName()
                        println('getFileParamFromWorkspace filePath.getName(): '+filePath.getName())
                        println('getFileParamFromWorkspace filePath.getParent(): '+filePath.getParent())
                        return filePath.getName()
                    }
                }
            }
        }
    }
    return ''
}
