def executeAnsiblePlaybookForTGW() {
    stage("Deploy using  tags: ${params.ANSIBLE_TAGS}") {
        validateParameters()
        def List<String> awsAccountIDs = params.ACCOUNTID.split(',')
        for (String awsAccountID : awsAccountIDs) {
            awsAccountID=awsAccountID.trim()
            System.out.println(awsAccountID)
            echo "Deploying to Account ID :" + awsAccountID
            //vpc_stack_name = params.pProjectShort+"-VPC-"+ params.pEnvTag
            //cfn_stack_description = params.pProjectShort+" VPC "+ params.pEnvTag

            script {sh '''
                export AWS_DEFAULT_REGION=${AWS_REGION}
                echo $AWS_DEFAULT_REGION
                pwd
                cd ansible && ansible-playbook main.yml \
                -e ROLENAME=${ROLENAME} \
				-e EXTERNALID=${EXTERNALID} \
                -e ACCOUNTID='''+awsAccountID+''' \
                -e pVpcCidrs=${pVpcCidrs} \
                -e pJenkinsBuildNo=${BUILD_NUMBER} \
                -e pVpcSubnetCidrs=${pVpcSubnetCidrs} \
                -e AWS_REGION=${AWS_REGION} \
                -e pConnectionId=${pConnectionId} \
                -e cf_dest_path=${pVpcCfnPath} \
                -e pTierVar=${pTierVar} \
                -e pEnvTag=${pEnvTag} \
          	    -e TAG_VALUE="${TAG_VALUE}" \
                -e TAG_KEY="${TAG_KEY}" \
                --tags "${ANSIBLE_TAGS}" ${VERBOSITY} \
                -e ansible_python_interpreter=/usr/bin/python3

                  '''}
        }
                // -e pBucketNamePrefix=${pBucketNamePrefix} 
    }
}

/*
def executeAnsiblePlaybook() {
    stage("Deploy using  tags: ${params.ANSIBLE_TAGS}") {
        validateParameters()
        def List<String> awsAccountIDs = params.ACCOUNTID.split(',')
        for (String awsAccountID : awsAccountIDs) {
            System.out.println(awsAccountID)
            echo "Deploying to Account ID :" + awsAccountID
            //vpc_stack_name = params.pProjectShort+"-VPC-"+ params.pEnvTag
            //cfn_stack_description = params.pProjectShort+" VPC "+ params.pEnvTag

            script {sh '''
                export AWS_DEFAULT_REGION=${AWS_REGION}
                echo $AWS_DEFAULT_REGION
                pwd
                cd ansible && ansible-playbook main.yml \
                -e ROLENAME=${ROLENAME} \
				-e EXTERNALID=${EXTERNALID} \
                -e ACCOUNTID='''+awsAccountID+''' \
                -e pVpcCidr=${pVpcCidr} \
                -e pVpcSecondaryCidrs=${pVpcSecondaryCidrs} \
                -e pJenkinsBuildNo=${BUILD_NUMBER} \
                -e pVpcSubnetCidrs=${pVpcSubnetCidrs} \
                -e AWS_REGION=${AWS_REGION} \
                -e pVPNDxTransitive=${pVPNDxTransitive} \
                -e pConnectionId=${pConnectionId} \
                -e pTgwId=${pTgwId} \
                -e pAZVar=${pAZVar} \
                -e cf_dest_path=${pVpcCfnPath} \
                -e pEnvTag=${pEnvTag} \
                -e pVPN01TunnelInsideCidr=${pVPN01TunnelInsideCidr} \
                -e pVPN02TunnelInsideCidr=${pVPN02TunnelInsideCidr} \
          	    -e pVPCSpokeNum=${pVPCSpokeNum} \
          	    -e TAG_VALUE="${TAG_VALUE}" \
                -e TAG_KEY="${TAG_KEY}" \
                -e pBucketNamePrefix=${pBucketNamePrefix} --tags "${ANSIBLE_TAGS}" ${VERBOSITY}

                  '''}
        }

    }
}

def executeAnsiblePlaybookForVGW() {
    stage("Deploy using  tags: ${params.ANSIBLE_TAGS}") {
        validateParameters()
        def List<String> awsAccountIDs = params.ACCOUNTID.split(',')
        for (String awsAccountID : awsAccountIDs) {
            System.out.println(awsAccountID)
            echo "Deploying to Account ID :" + awsAccountID
            //vpc_stack_name = params.pProjectShort+"-VPC-"+ params.pEnvTag
            //cfn_stack_description = params.pProjectShort+" VPC "+ params.pEnvTag

            script {sh '''
                export AWS_DEFAULT_REGION=${AWS_REGION}
                echo $AWS_DEFAULT_REGION
                pwd
                cd ansible && ansible-playbook main.yml \
                -e ROLENAME=${ROLENAME} \
				-e EXTERNALID=${EXTERNALID} \
                -e ACCOUNTID='''+awsAccountID+''' \
                -e pVpcCidr=${pVpcCidr} \
                -e pVpcSecondaryCidrs=${pVpcSecondaryCidrs} \
                -e pJenkinsBuildNo=${BUILD_NUMBER} \
                -e pVpcSubnetCidrs=${pVpcSubnetCidrs} \
                -e AWS_REGION=${AWS_REGION} \
                -e pVPNDxTransitive=${pVPNDxTransitive} \
                -e pAZVar=${pAZVar} \
                -e cf_dest_path=${pVpcCfnPath} \
                -e pEnvTag=${pEnvTag} \
                -e pVPN01TunnelInsideCidr=${pVPN01TunnelInsideCidr} \
                -e pVPN02TunnelInsideCidr=${pVPN02TunnelInsideCidr} \
          	    -e pVPCSpokeNum=${pVPCSpokeNum} \
          	    -e TAG_VALUE="${TAG_VALUE}" \
                -e TAG_KEY="${TAG_KEY}" \
                -e pBucketNamePrefix=${pBucketNamePrefix} --tags "${ANSIBLE_TAGS}" ${VERBOSITY}

                  '''}
        }

    }
}
*/

def validateParameters()
{
  if(params.ANSIBLE_TAGS.trim().equals('')|| params.ANSIBLE_TAGS.trim().equals('assume'))
  {
    currentBuild.result = 'ABORTED'
    error('Appropriate ANSIBLE_TAGS are not specified. Terminating VPC deployment pipeline')
  }
  else if(params.ANSIBLE_TAGS.trim().contains('vpc,') && params.ANSIBLE_TAGS.trim().contains('vpc-tgw'))
  {
    currentBuild.result = 'ABORTED'
    error('Both vpc and vpc-tgw can not be specified while creating a VPC')
  }
  else if(params.ACCOUNTID.trim().equals(''))
  {
    currentBuild.result = 'ABORTED'
    error('ACCOUNTID and can not be blank')
  }
  else if(params.pConnectionId.trim().equals('') && params.ANSIBLE_TAGS.trim().contains('vpc-tgw'))
  {
    currentBuild.result = 'ABORTED'
    error('pConnectionId can not be blank while creating VPC with transit gateway')
  }
  //else if(params.pConnectionId.trim().contains('vpc') || params.ANSIBLE_TAGS.trim().contains('vpc-tgw'))
  //{
  //  if(params.pProjectShort.trim().equals(''))
  //  {
  //    currentBuild.result = 'ABORTED'
  //    error('pProjectShort can not be blank while creating VPC with transit gateway')
  //  }
  //}
  //else if (params.ANSIBLE_TAGS.trim().contains('delete_cfn_stack'))
  //{
  //  if(params.CFN_STACK_TO_BE_DELETED.trim().equals(''))
  //  {
  //    currentBuild.result = 'ABORTED'
  //    error('CFN_STACK_TO_BE_DELETED can not be blank when delete_cfn_stack is specified in ANSIBLE_TAGS')
  //  }
  //}
}
def executeSpecTests() {

  if (params.TAGS.contains('vpc')) {
    stage("Execute awspec tests")
    {
        //def ansibleTags = ${TAGS}
          echo "Testing AWS resources"
          script {sh '''
          export ACCOUNTID=${ACCOUNTID}
          export ROLENAME=${ROLENAME}                                                                                    e
          export ROLENAME=${ROLENAME}  
		  export AWS_REGION=${AWS_REGION}
          export STACKNAME=${STACK_NAME}
          export PROJECTSHORT="${pProjectShort}"
          export PATH=$PATH:/usr/local/rvm/rubies/ruby-2.5.3/bin
          cd spec-tests && bundle && rake spec
          '''}
        }
    }
  else
      echo "Skipping awspec tests"

}

def validateCFNTemplates() {

  stage("Validating CFN templates using cfn-nag") {
    echo "Validating CFN templates using cfn-nag"
  }
}


def ignoreFirstBuild() {

  stage("parameterizing") {
      script {
          if ("${env.BUILD_NUMBER}" == "1") {
              currentBuild.result = 'ABORTED'
              error('DRY RUN COMPLETED. JOB PARAMETERIZED.')
          }
      }
  }
}
