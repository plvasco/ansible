
def validateAndTest(){

       initializeParameters()
       

        stage('Checkout') {
            checkout scm
        }

        
        commonVaecPeering.executeBoto3Python()
        


}

def initializeParameters()
{
    String sectionHeaderStyle = '''
      color: black;
      background: #7FAB9B;
      font-family: Roboto, sans-serif !important;
      font-weight: bold;
      padding: 5px;
      text-align: center;
    '''

    String separatorStyle = '''
      border: 0;
      border-bottom: 1px dashed #ccc;
      background: #999;
    '''

  properties([[$class: 'RebuildSettings', autoRebuild: false, rebuildDisabled: false],
  parameters([
            [
                     $class: 'ParameterSeparatorDefinition',
                     name: 'HEADER',
                     sectionHeader: 'Mandatory parameters for VPC peering pipeline',
                     separatorStyle: separatorStyle,
                     sectionHeaderStyle: sectionHeaderStyle
            ],

           // string(name: 'action', defaultValue:'pcx-create', description: 'pcx-create or pcx-delete', trim: true),
           choice(name: 'action', choices: ["pcx-create", "pcx-delete"].join("\n"), description: 'pcx-create or pcx-delete'),
           
		   string(name: 'pcx_id', defaultValue:'pcx-xxxxx', description: 'Required: (pcx-delete only)', trim: true),
           string(name: 'requester_owner_id', defaultValue: '', description: 'AWS account number, Required: (pcx-create or pcx-delete)', trim: true),

           // string(name: 'requester_region', defaultValue:'us-gov-rrrr-1', description: 'AWS Region, Required: (pcx-create or pcx-delete)', trim: true),
           choice(name: 'requester_region', choices: ["us-gov-west-1", "us-gov-east-1"].join("\n"), description: 'AWS Region, Required: (pcx-create or pcx-delete)'),

           string(name: 'requester_vpc_id', defaultValue:'vpc-rrrr',description: 'vpc id, Required: (pcx-create or pcx-delete)', trim: true),
		   string(name: 'accepter_owner_id', defaultValue:'',description: 'AWS account number, Required: (pcx-create)', trim: true),

		   // string(name: 'accepter_region', defaultValue:'us-gov-aaaa-1', description: 'AWS Region, Required: (pcx-create)', trim: true),
           choice(name: 'accepter_region', choices: ["us-gov-west-1", "us-gov-east-1"].join("\n"), description: 'AWS Region, Required: (pcx-create)'),

		   string(name: 'accepter_vpc_id', defaultValue:'vpc-aaaa',description: 'vpc id, Required: (pcx-create)', trim: true),
           
           [
                    $class: 'ParameterSeparatorDefinition',
                    name: 'HEADER',
                    sectionHeader: 'VPC peering override parameters',
                    separatorStyle: separatorStyle,
                    sectionHeaderStyle: sectionHeaderStyle
           ],
		   string(name: 'verify_connection_id', defaultValue:'True', description:'By default, peering connections in the same tier (Development-313, Stage-312 or Production-311) will be skipped since peering is not necessary. To override put "False"', trim: true),
           string(name: 'pcx_name_tag', defaultValue:'', description:'By default, the peering connection tag Name = "requester_vpc_Name-peering-accepter_vpc_Name". To override, provide alternate name', trim: true),
           ])])

}
