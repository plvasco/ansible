def Initiate() {
    node {
        // Execute different stages depending on the job
        if(env.JOB_NAME.contains("startShare")){

            stage('Checkout') {
                checkout scm
            }
            executeBoto3Python()

        } else if(env.JOB_NAME.contains("test")) {
            initParamsForMultiBranchPipeline()
            stage('Checkout') {
                checkout scm
            }			
            executeBoto3Python()
        }
    }
}

def initParamsForMultiBranchPipeline()
{
      String sectionHeaderStyle = '''
        color: black;
        background: #7FAB9B;
        font-family: Roboto, sans-serif !important;
        font-weight: bold;
        padding: 5px;
        text-align: center;
      '''

      String separatorStyle = '''
        border: 0;
        border-bottom: 1px dashed #ccc;
        background: #999;
      '''

      properties([[$class: 'RebuildSettings', autoRebuild: false, rebuildDisabled: false],
      parameters([
        [
                 $class: 'ParameterSeparatorDefinition',
                 name: 'HEADER',
                 sectionHeader: 'Common required parameters',
                 separatorStyle: separatorStyle,
                 sectionHeaderStyle: sectionHeaderStyle
        ],
        choice(choices: ["us-gov-west-1", "us-gov-east-1"].join("\n"),
              description: 'AWS Region where AMI copy is being performed',
              name: 'AWS_REGION'),


        string(defaultValue: '',
              description: 'Comma separated AWS Account IDs. Specify \'all\' for copying AMI to all member accounts in AWS organization',
              name: 'AWS_ACCOUNT_IDs',
              trim: true),

        string(defaultValue: '',
              description: 'Region specific comma separated AMI IDs from core-gov-internal. Get the latest from: https://github.ec.va.gov/AWS/vaec-ami',
              name: 'AMI_IDs',
              trim: true),

       choice(choices: ["True", "False"].join("\n"),
             description: 'Require destination account/region to have atleast one valid VPC with ConnectionID in order to share AMI',
             name: 'REQUIRE_VALID_VPC'),

       //string(defaultValue: 'vaec-authorizer-role',
       //      description: 'AWS Remote Assume Role Name',
       //      name: 'ROLENAME',
       //      trim: true),
       [
                $class: 'ParameterSeparatorDefinition',
                name: 'HEADER',
                sectionHeader: 'Optional parameters for copying AMI from us-gov-west-1 to us-gov-east-1 within core-gov-internal account',
                separatorStyle: separatorStyle,
                sectionHeaderStyle: sectionHeaderStyle
       ],

       choice(choices: ["no", "yes"].join("\n"),
             description: 'Select yes for copying AMI From us-gov-west-1 to us-gov-east-1 in core-gov-internal account',
             name: 'CROSS_REGION_COPY'),

       choice(choices: ["us-gov-east-1", "us-gov-west-1"].join("\n"),
             description: 'Destination AWS Region. This is required only if CROSS_REGION_COPY is selected yes and parameter is ignored if no',
             name: 'DEST_AWS_REGION'),

       string(defaultValue: '',
             description: 'Destination region Customer master key (CMK) arn to use when copying ami across different region within the same AWS account. This parameter required only if CROSS_REGION_COPY is selected to yes and is ignored if CROSS_REGION_COPY is set to no',
             name: 'DEST_REGION_CMK_ARN',
             trim: true),
       ])])
	   

}


def executeBoto3Python() {

      stage("Sharing AMI: " + params.AMI_IDS)
      {
          String ami_id_list
          String aws_account_id_list

          if(params.AMI_IDs.trim().equals('') || params.AWS_ACCOUNT_IDs.trim().equals(''))
          {
            currentBuild.result = 'ABORTED'
            error('No AMI IDs and AWS_ACCOUNT_ID are not specified. Terminating AMI Share job')
          }
          else
          {
                aws_account_id_list = params.AWS_ACCOUNT_IDs
                ami_id_list= params.AMI_IDs
                child_cmk_alias= params.CHILD_ACCOUNT_CMK_ALIAS
                CROSS_REGION_COPY = params.CROSS_REGION_COPY
                DEST_AWS_REGION = params.DEST_AWS_REGION
                DEST_REGION_CMK_ARN = params.DEST_REGION_CMK_ARN
                //CHILD_ACCOUNT_ROLENAME = params.CHILD_ACCOUNT_ROLENAME
                if(params.CROSS_REGION_COPY.equals('no'))
                {
                  script {
                  sh '''
                          export PYTHONPATH=$VAECLIBPATH:$PYTHONPATH
                          python3 ./share/vaec_ami_share.py \
                                        --account-id '''+aws_account_id_list+''' \
                                        --source-region $AWS_REGION \
                                        --source-ami-ids $AMI_IDs \
                                        --require-valid-vpc $REQUIRE_VALID_VPC \
                                        --nodryrun
                  '''}

                }
                //end of params.CROSS_REGION_COPY.equals('no')
                else
                //Perform cross region copy within the same AWS Account
                {
                    if(params.DEST_REGION_CMK_ARN.trim().equals(''))
                    {
                      currentBuild.result = 'ABORTED'
                      error('DEST_REGION_CMK_ARN parameter is not specified. DEST_REGION_CMK_ARN is a required parameter for cross region copy. Terminating AMI Share job')
                    }
                    script {
                    sh '''

                              aws lambda invoke \
                                    --function-name vaec-ami-share \
                                    --log-type Tail \
                                    --payload '{"action": "cross_region_ami_copy","dest_account_ids": "'''+aws_account_id_list+'''","destination_region": "'''+DEST_AWS_REGION+'''","source_ami_ids": "'''+ami_id_list+'''", "destination_region_cmk_arn": "'''+DEST_REGION_CMK_ARN+'''" }' \
                                    outputfile.txt \
                                    --region $AWS_REGION \
                                    --query LogResult --output text | base64 --decode
                              echo $?
                              cat outputfile.txt
                              if grep -q "errorMessage" outputfile.txt
                              then
                                  exit 1
                              else
                                  exit 0
                              fi

                    '''}
                } //end of else
          }
      }
}
