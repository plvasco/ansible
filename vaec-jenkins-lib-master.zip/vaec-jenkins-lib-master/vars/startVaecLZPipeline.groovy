def Initiate() {
    node {
        // Execute different stages depending on the job
        if(env.JOB_NAME.contains("deploy")){
            deploy()
        } else if(env.JOB_NAME.contains("test")) {
            stage('delete __pycache__ directory from workspace') {
                  sh 'sudo rm -rf ./parameters/*'
                  sh 'sudo rm -rf ./scripts/__pycache__/*'
            }
            validateAndTestLZPipeline.validateAndTest()
        }
    }
}

def deploy(){
  node {
      stage('delete __pycache__ directory from workspace') {
            sh 'sudo rm -rf ./parameters/*'
            sh 'sudo rm -rf ./scripts/__pycache__/*'
      }

      stage('Checkout') {
        checkout scm
      }
      commonVaecLZ.executeAnsiblePlaybook()
      //commonVaecLZ.executeSpecTests()
  }
}
