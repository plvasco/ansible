def executeBoto3Python() {
  runParallel = false
  def queue_url = "https://sqs.us-gov-west-1.amazonaws.com/348286891446/vaec-vpc-pcx-handler-rQueue-12ZTKQ1YCTCI2"
//  def msg_body = """{"action": "'''+action+'''", "requester_owner_id": "'''+requester_owner_id+'''", "requester_region": "'''+requester_region+'''","requester_vpc_id": "'''+Requester_vpc_id+'''","accepter_owner_id": "'''+Accepter_owner_id+'''","accepter_region": "'''+Accepter_region+'''","""
  
 //def msg_body = """{​​​​​"action":""" +'"'+ params.action +'"'+',"requester_owner_id":' +'"'+ params.requester_owner_id +'"'+',"requester_region":' +'"'+ params.requester_region +'"'+',"requester_vpc_id":' +'"'+ params.requester_vpc_id +'"'+',"accepter_owner_id":' +'"'+ params.accepter_owner_id +'"'+',"accepter_region":' +'"'+ params.accepter_region +'"'+',"accepter_vpc_id":' +'"'+ params.accepter_vpc_id +'"'
 
  def msg_body =""
  msg_body = msg_body + """{"action":""" +'"'+ params.action +'"'
  msg_body = msg_body + ',"requester_owner_id":' +'"'+ params.requester_owner_id +'"'
  msg_body = msg_body + ',"requester_region":' +'"'+ params.requester_region +'"'
  msg_body = msg_body +',"requester_vpc_id":' +'"'+ params.requester_vpc_id +'"'
  msg_body_crt = msg_body +',"accepter_owner_id":' +'"'+ params.accepter_owner_id +'"'
  msg_body_crt = msg_body_crt +',"accepter_region":' +'"'+ params.accepter_region +'"'
  msg_body_crt = msg_body_crt +',"accepter_vpc_id":' +'"'+ params.accepter_vpc_id +'"'

  stage('Validate Parameters')
  {
    validateParameters()
  }
  stage("Creation of VPC peering connection between ${params.Requester_vpc_id} and ${params.Accepter_vpc_id} started.}")
  {
		if(params.action.trim().equals('pcx-create')){
			if(params.verify_connection_id.trim().equals('False')){
				msg_body_crt = msg_body_crt +',"verify_connection_id":' +'"'+ params.verify_connection_id +'"'
			}
			if(params.pcx_name_tag.trim() != ('')){
				msg_body_crt = msg_body_crt +',"pcx_name_tag":' +'"'+ params.pcx_name_tag +'"'
			}
		    msg_body = msg_body_crt + '}'
		}
		else if(params.action.trim().equals('pcx-delete')){
			msg_body = msg_body +',"pcx_id":' +'"'+ params.pcx_id +'"}'
		}
	println msg_body
	script {
		sh """
		 aws sqs send-message \
		--queue-url '''${queue_url}''' \
		--message-body '''${msg_body}'''  \
		--region $requester_region \
		--output text
		"""}

  }
  stage('Finish') {
      println('Build complete.')
  }

}


def validateParameters()
{

  if(params.action.trim().equals(''))
  {
      currentBuild.result = 'ABORTED'
      error('Action can not be blank')
  }
  else if(params.requester_owner_id.trim().equals(''))
  {
    currentBuild.result = 'ABORTED'
	error('Requester_owner_id can not be blank')
  }
  else if(params.requester_vpc_id.trim().equals(''))
  {
    currentBuild.result = 'ABORTED'
	error('Requester_vpc_id can not be blank')
  }
  else if(params.accepter_owner_id.trim().equals(''))
  {
    currentBuild.result = 'ABORTED'
	error('Accepter_owner_id can not be blank')
  }
  else if(params.accepter_region.trim().equals(''))
  {
    currentBuild.result = 'ABORTED'
	error('Accepter_region can not be blank')
  }
  else if(params.accepter_vpc_id.trim().equals(''))
  {
    currentBuild.result = 'ABORTED'
	error('Accepter_vpc_id can not be blank')
  }  
}