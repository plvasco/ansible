def initiate(){
    node {
        stage('Checkout') {
            checkout scm
        }


        // Execute different stages depending on the job
        if(env.JOB_NAME.contains("deploy")){
            deployVaecSharedLib()
            test()
        } else if(env.JOB_NAME.contains("test")) {
            test()
        }
    }
}

def deployVaecSharedLib(){
    stage('Deploy vaec python library') {
        script {sh '''
          if [ -d "$VAECLIBPATH" ]; then sudo rm -Rf $VAECLIBPATH; fi
          echo "Creating $VAECLIBPATH"
          sudo mkdir -p $VAECLIBPATH
          sudo cp -f $WORKSPACE/vaeclib/*.py $VAECLIBPATH
        '''}
    }
    stage('Deploy vaecbin') {
        script {sh '''
          if [ -d "$VAECBINPATH" ]; then sudo rm -Rf $VAECBINPATH; fi
          echo "Creating $VAECBINPATH"
          sudo mkdir -p $VAECBINPATH
          sudo cp -f $WORKSPACE/vaecbin/* $VAECBINPATH
          sudo chmod +x $VAECBINPATH/*
        '''}
    }
}

def test(){
    stage("Backend tests"){
    //sh "pip install -r $WORKSPACE/python/requirements.txt"
    script {sh '''
      #pip install -r $WORKSPACE/python/requirements.txt
      #477194928391- This is devtest's AWS account ID
      #cd $WORKSPACE/python/
      export PYTHONPATH=$WORKSPACE/vaeclib:$PYTHONPATH
      python3 $WORKSPACE/tests/test.py --account-id 477194928391 --region all
      echo $?
    '''}
    }
}
