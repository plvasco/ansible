
import jenkins.plugins.parameter_separator.ParameterSeparatorDefinition

def validateAndTest(){

       initializeParameters()
       commonVaecVPC.ignoreFirstBuild()

        stage('Checkout') {
            checkout scm
        }
        //stage('Validate Templates') {
          //  echo "Validate Templates "
        //    echo "${params.ROLENAME} in Validate Templates"
        //}
        //commonVaecVPC.validateCFNTemplates()
        commonVaecVPC.executeAnsiblePlaybook()
        //commonVaecVPC.executeSpecTests()


}

def initializeParameters()
{
  String sectionHeaderStyle = '''
    color: black;
    background: #ffdab3;
    font-family: Roboto, sans-serif !important;
    font-weight: bold;
    padding: 5px;
    text-align: center;
  '''

  String separatorStyle = '''
    border: 0;
    border-bottom: 1px dashed #ccc;
    background: #999;
  '''

  properties([

      [$class: 'RebuildSettings', autoRebuild: false, rebuildDisabled: false],
      parameters([
      [
               $class: 'ParameterSeparatorDefinition',
               name: 'HEADER',
               sectionHeader: 'Mandatory parameters for VPC pipeline',
               separatorStyle: separatorStyle,
               sectionHeaderStyle: sectionHeaderStyle
      ],
      string(defaultValue: 'us-gov-west-1', description: 'AWS Region', name: 'AWS_REGION'),
      string(defaultValue: '', description: 'Single AWS Account where we intend to deploy any of VPC related tasks with an exception of vpn-all task, where you can specify comma separated AWS account IDs', name: 'ACCOUNTID'),
      string(defaultValue: 'assume', description: 'Tags for Ansible to run VPC specific tasks. Possible values: assume, vpc_tgw, vpc_tgw_secondary_cidr, vpc, vpc_secondary_cidr, post_vpc_creation, vpn_all', name: 'ANSIBLE_TAGS'),

      [
               $class: 'ParameterSeparatorDefinition',
               name: 'HEADER',
               sectionHeader: 'Mandatory parameters for VPC creation',
               separatorStyle: separatorStyle,
               sectionHeaderStyle: sectionHeaderStyle
      ],
      string(defaultValue: '', description: 'VPC environment tag. This parameter will be used in VPC name. Example values are, Development,Stage,Production,CORE,SECURITY,SECURITYLOGS,DevOps,Sandbox,LIGHTHOUSE-POC,PreProd,Stage-Ops', name: 'pEnvTag'),
      string(defaultValue: '192.168.82.0/2', description: 'VPC CIDR', name: 'pVpcCidr'),
      string(defaultValue: '192.168.82.0/26,192.168.82.64/26,192.168.82.128/26,192.168.82.192/26', description: 'VPC subnet CIDRs', name: 'pVpcSubnetCidrs'),
      string(defaultValue: '192.168.82.0/24', description: 'Comma Delimited list of VPC Secondary CIDRs', name: 'pVpcSecondaryCidrs'),
      string(defaultValue: '../cfn-tgw/vpc-1-az-2-subnet-4.yml', description: 'VPC CloudFormation path. This must be specified when vpc or vpc-tgw is specified in ANSIBLE_TAGS field. Please check git repo https://github.ec.va.gov/AWS/vaec-vpc to pick appropriate CFN template and while specifying no need to specify .j2 extension. VPC CFN templates can be found either in cfn-templates or cfn-tgw folder', name: 'pVpcCfnPath'),
      [
               $class: 'ParameterSeparatorDefinition',
               name: 'HEADER',
               sectionHeader: 'Mandatory Parameters if VPC is using Transit Gateway',
               separatorStyle: separatorStyle,
               sectionHeaderStyle: sectionHeaderStyle
      ],
      string(defaultValue: 'tgw-089990091647676d2', description: 'Transit Gateway Id. Specify this parameter if you are using Transit Gateway and pass vpc-tgw in ANSIBLE_TAGS instead of vpc', name: 'pTgwId'),
      string(defaultValue: '', description: 'ConnectionId must be specified when transit gateway is used with VPC', name: 'pConnectionId'),


      [
               $class: 'ParameterSeparatorDefinition',
               name: 'HEADER',
               sectionHeader: 'Mandatory Parameters if VPC is using Virtual Private Gateway, CSR and VPC peering',
               separatorStyle: separatorStyle,
               sectionHeaderStyle: sectionHeaderStyle
      ],
      string(defaultValue: 'DevDx', description: 'pVPNDxTransitive. pVPNDxTransitive. Example values are, DevDx, StageDx,ProdDx', name: 'pVPNDxTransitive'),
    	string(defaultValue: '', description: 'VPC Spoke number must be specified when virtual private gateway is used with VPC', name: 'pVPCSpokeNum'),
      string(defaultValue: '169.254.115.136/30,169.254.115.140/30', description: 'pVPN01TunnelInsideCidr', name: 'pVPN01TunnelInsideCidr'),
      string(defaultValue: '169.254.125.136/30,169.254.125.140/30', description: 'pVPN02TunnelInsideCidr', name: 'pVPN02TunnelInsideCidr'),

      [
               $class: 'ParameterSeparatorDefinition',
               name: 'HEADER',
               sectionHeader: 'Common pipeline parameters with default values',
               separatorStyle: separatorStyle,
               sectionHeaderStyle: sectionHeaderStyle
      ],
      string(defaultValue: 'vaec-authorizer-role', description: 'AWS cross account Assume Role Name', name: 'ROLENAME'),
      string(defaultValue: 'vaec-automation', description: 'Bucket name for storing script files related to VPC pipeline. Default value is vaec-automation', name: 'pBucketNamePrefix'),
      string(defaultValue: 'Name', description: 'Tag key', name: 'TAG_KEY'),
      string(defaultValue: '"DEFAULT - DO NOT USE"', description: 'Tag value', name: 'TAG_VALUE'),
      string(defaultValue: 'AZ1,AZ2,AZ3', description: 'Comma separated Availability zone-this field is used in populating AWS tags', name: 'pAZVar'),
      string(defaultValue: '', description: 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode', name: 'VERBOSITY')
      ])])
}
