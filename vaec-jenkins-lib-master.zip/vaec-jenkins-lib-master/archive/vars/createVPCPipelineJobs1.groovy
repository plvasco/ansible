package vpc

class createVPCPipelineJobs
{

  static void createTGWVPCDeploymentJob(jobName, repoUrl) {
  def sectionHeaderStyleCss = 'color: black; background: #ffdab3; font-family: Roboto, sans-serif !important; font-weight: bold; padding: 5px; text-align: center; '

  def separatorStyleCss = 'border: 0; border-bottom: 1px dashed #ccc; background: #999; '

  // Deployment job always runs against master branch
      pipelineJob(jobName) {
          description "VAEC VPC pipeline job. This pipeline can be used only with one AWS account at a time with an exception for vpn-all task"
          parameters {
            parameterSeparatorDefinition {
               name('Mandatory parameters')
               separatorStyle(separatorStyleCss)
               sectionHeader('Mandatory parameters for VPC pipeline')
               sectionHeaderStyle(sectionHeaderStyleCss)
            }
            stringParam('AWS_REGION', 'us-gov-west-1', 'AWS Region')
            stringParam('ACCOUNTID', '', 'Single AWS Account where we intend to deploy any of VPC related tasks with an exception of vpn-all task, where you can specify comma separated AWS account IDs')
            stringParam('ANSIBLE_TAGS', 'default,assume', 'Tags for Ansible to run VPC specific tasks. Possible values default,assume,vpc-tgw,vpc-tgw-secondary-cidr,vpc,vpc-secondary-cidr,post-creation,vpn,vpn-all,delete_cfn_stack')

            parameterSeparatorDefinition {
               name('VPC Parameters')
               separatorStyle(separatorStyleCss)
               sectionHeader('Mandatory parameters for VPC creation')
               sectionHeaderStyle(sectionHeaderStyleCss)
            }
             stringParam('pProjectShort', 'ProjShort', 'Project Short Tag used in VPC name and stack description')
             stringParam('pEnvTag', '', 'VPC environment tag. This parameter will be used in VPC name. Example values are, Development,Stage,Production,CORE,SECURITY,SECURITYLOGS,DevOps,Sandbox,LIGHTHOUSE-POC,PreProd,Stage-Ops')
             stringParam('pVpcCidr', '192.168.82.0/24', 'VPC CIDR')
             stringParam('pVpcSubnetCidrs', '192.168.82.0/26,192.168.82.64/26,192.168.82.128/26,192.168.82.192/26', 'Comma separated VPC subnet CIDRs')
             stringParam('pVpcSecondaryCidrs', '192.168.82.0/26', 'Comma delimited list of VPC Secondary CIDRs. Make sure no spaces between each CIDRs')
             stringParam('cf_dest_path', '../cfn-tgw/vpc-1-az-2-subnet-4.yml', 'VPC CloudFormation path. This must be specified when vpc or vpc-tgw is specified in ANSIBLE_TAGS field. Please check git repo https://github.ec.va.gov/AWS/vaec-vpc to pick appropriate CFN template and while specifying no need to specify .j2 extension. VPC CFN templates can be found either in cfn-templates or cfn-tgw folder')

            parameterSeparatorDefinition {
               name('VPC Parameters')
               separatorStyle(separatorStyleCss)
               sectionHeader('Mandatory Parameters if VPC is using Transit Gateway')
               sectionHeaderStyle(sectionHeaderStyleCss)
            }

            stringParam('pTgwId', 'tgw-089990091647676d2', 'Transit Gateway Id. Specify this parameter if you are using Transit Gateway, pass vpc-tgw in ANSIBLE_TAGS instead of vpc')
            stringParam('pConnectionId', '', 'ConnectionId must be specified when transit gateway is used with VPC')

            parameterSeparatorDefinition {
               name('Common pipeline parameters with default values')
               separatorStyle(separatorStyleCss)
               sectionHeader('Common pipeline parameters with default values')
               sectionHeaderStyle(sectionHeaderStyleCss)
            }
             stringParam('pBucketNamePrefix', 'vaec-automation', 'Bucket name for storing script files related to VPC pipeline. Default value is vaec-automation')
             choiceParam('INIT_USE_PREVIOUS_VALUE', ['true', 'false'], 'INIT_USE_PREVIOUS_VALUE')
             stringParam('ROLENAME', 'vaec-authorizer-role', 'AWS cross account Role to use for create a VPC')
             stringParam('TAG_KEY', 'Name', 'Tag Key for post creation tagging')
             stringParam('TAG_VALUE', '"DEFAULT - DO NOT USE"', 'Tag value for tag name')
             stringParam('pAZVar', 'AZ1,AZ2,AZ3', 'Comma separated AWS availability zones. This field is used in populating AWS tags')
             stringParam('CFN_STACK_TO_BE_DELETED', '', 'AWS CloudFormation stack name to be deleted')
             stringParam('VERBOSITY', '', 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode')
          }
          definition {
              cpsScm {
                  scm {
                      git {
                          remote {
                              url(repoUrl)
                              credentials(vaGitCred)
                          }

                          branches("master")
                          extensions {
                              cleanBeforeCheckout()
                          }
                      }
                  }
                  scriptPath("jenkins/Jenkinsfile")
              }
          }
      }
  }

  static void createVGWVPCDeploymentJob(jobName, repoUrl) {
  def sectionHeaderStyleCss = 'color: black; background: #ffdab3; font-family: Roboto, sans-serif !important; font-weight: bold; padding: 5px; text-align: center; '

  def separatorStyleCss = 'border: 0; border-bottom: 1px dashed #ccc; background: #999; '

  // Deployment job always runs against master branch
      pipelineJob(jobName) {
          description "VAEC VPC pipeline job. This pipeline can be used only with one AWS account at a time with an exception for vpn-all task"
          parameters {
            parameterSeparatorDefinition {
               name('Mandatory parameters')
               separatorStyle(separatorStyleCss)
               sectionHeader('Mandatory parameters for VPC pipeline')
               sectionHeaderStyle(sectionHeaderStyleCss)
            }
            stringParam('AWS_REGION', 'us-gov-west-1', 'AWS Region')
            stringParam('ACCOUNTID', '', 'Single AWS Account where we intend to deploy any of VPC related tasks with an exception of vpn-all task, where you can specify comma separated AWS account IDs')
            stringParam('ANSIBLE_TAGS', 'default,assume', 'Tags for Ansible to run VPC specific tasks. Possible values default,assume,vpc-tgw,vpc-tgw-secondary-cidr,vpc,vpc-secondary-cidr,post-creation,vpn,vpn-all,delete_cfn_stack')

            parameterSeparatorDefinition {
               name('VPC Parameters')
               separatorStyle(separatorStyleCss)
               sectionHeader('Mandatory parameters for VPC creation')
               sectionHeaderStyle(sectionHeaderStyleCss)
            }
             stringParam('pProjectShort', 'ProjShort', 'Project Short Tag used in VPC name and stack description')
             stringParam('pEnvTag', '', 'VPC environment tag. This parameter will be used in VPC name. Example values are, Development,Stage,Production,CORE,SECURITY,SECURITYLOGS,DevOps,Sandbox,LIGHTHOUSE-POC,PreProd,Stage-Ops')
             stringParam('pVpcCidr', '192.168.82.0/24', 'VPC CIDR')
             stringParam('pVpcSubnetCidrs', '192.168.82.0/26,192.168.82.64/26,192.168.82.128/26,192.168.82.192/26', 'Comma separated VPC subnet CIDRs')
             stringParam('pVpcSecondaryCidrs', '192.168.82.0/26', 'Comma delimited list of VPC Secondary CIDRs. Make sure no spaces between each CIDRs')
             stringParam('cf_dest_path', '../cfn-tgw/vpc-1-az-2-subnet-4.yml', 'VPC CloudFormation path. This must be specified when vpc or vpc-tgw is specified in ANSIBLE_TAGS field. Please check git repo https://github.ec.va.gov/AWS/vaec-vpc to pick appropriate CFN template and while specifying no need to specify .j2 extension. VPC CFN templates can be found either in cfn-templates or cfn-tgw folder')


            parameterSeparatorDefinition {
               name('VPC Parameters')
               separatorStyle(separatorStyleCss)
               sectionHeader('Mandatory Parameters if VPC is using Virtual Private Gateway, CSR and VPC peering')
               sectionHeaderStyle(sectionHeaderStyleCss)
            }
            stringParam('pVPNDxTransitive', 'DevDx', 'pVPNDxTransitive. Example values are, DevDx, StageDx,ProdDx')
            stringParam('pVPN01TunnelInsideCidr', '169.254.115.136/30,169.254.115.140/30', 'pVPN01TunnelInsideCidr')
            stringParam('pVPN02TunnelInsideCidr', '169.254.125.136/30,169.254.125.140/30', 'pVPN02TunnelInsideCidr')
            stringParam('pVPCSpokeNum', '', 'VPC Spoke number must be used when virtual private gateway is used with VPC')

            parameterSeparatorDefinition {
               name('Common pipeline parameters with default values')
               separatorStyle(separatorStyleCss)
               sectionHeader('Common pipeline parameters with default values')
               sectionHeaderStyle(sectionHeaderStyleCss)
            }
             stringParam('pBucketNamePrefix', 'vaec-automation', 'Bucket name for storing script files related to VPC pipeline. Default value is vaec-automation')
             choiceParam('INIT_USE_PREVIOUS_VALUE', ['true', 'false'], 'INIT_USE_PREVIOUS_VALUE')
             stringParam('ROLENAME', 'vaec-authorizer-role', 'AWS cross account Role to use for create a VPC')
             stringParam('TAG_KEY', 'Name', 'Tag Key for post creation tagging')
             stringParam('TAG_VALUE', '"DEFAULT - DO NOT USE"', 'Tag value for tag name')
             stringParam('pAZVar', 'AZ1,AZ2,AZ3', 'Comma separated AWS availability zones. This field is used in populating AWS tags')
             stringParam('CFN_STACK_TO_BE_DELETED', '', 'AWS CloudFormation stack name to be deleted')
             stringParam('VERBOSITY', '', 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode')
          }
          definition {
              cpsScm {
                  scm {
                      git {
                          remote {
                              url(repoUrl)
                              credentials(vaGitCred)
                          }

                          branches("master")
                          extensions {
                              cleanBeforeCheckout()
                          }
                      }
                  }
                  scriptPath("jenkins/Jenkinsfile")
              }
          }
      }
  }


  static void createTestJob(jobName, repoUrl) {
      multibranchPipelineJob(jobName) {
          branchSources {
              git {
                  remote(repoUrl)
                  credentialsId(vaGitCred)
                  includes('*')
              }

          }
          //triggers {
            //   cron("H/5 * * * *")
        //  }
          factory {
            workflowBranchProjectFactory {
                scriptPath("jenkins/Jenkinsfile")
            }
          }

      }
  }

}
