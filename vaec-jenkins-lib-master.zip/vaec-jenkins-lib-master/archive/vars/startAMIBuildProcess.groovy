
def buildAMI() {
    node {
        // Execute different stages depending on the job
        buildAMI.build()

    }
}
