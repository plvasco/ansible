def executeAnsiblePlaybook() {


    stage("Deploy using  tags: ${params.TAGS}") {
        if(params.TAGS.trim().equals('') || params.TAGS.trim().equals('default,assume'))
        {
          currentBuild.result = 'ABORTED'
          error('Ansible playbook TAGS are not specified. Terminating landingzone deployment job')
        }
        else
        {
          def List<String> awsAccountIDs = params.ACCOUNTID.split(',')
          for (String awsAccountID : awsAccountIDs) {
              System.out.println(awsAccountID)
              echo "Deploying to Account ID :" + awsAccountID
              vpc_stack_name = params.pProjectShort+"-VPC-"+ params.pEnvTag
              cfn_stack_description = params.pProjectShort+" VPC "+ params.pEnvTag

              script {sh '''
                  export AWS_DEFAULT_REGION=${AWS_REGION}
                  echo $AWS_DEFAULT_REGION
                  pwd
                  cd ansible && ansible-playbook main.yml \
                  -e STACK_DESCRIPTION="'''+cfn_stack_description+'''" \
                  -e ROLENAME=${ROLENAME} \
                  -e ACCOUNTID='''+awsAccountID+''' \
                  -e pVpcCidr=${pVpcCidr} \
                  -e pVpcSecondaryCidrs=${pVpcSecondaryCidrs} \
                  -e pJenkinsBuildNo=${BUILD_NUMBER} \
                  -e pVpcSubnetCidrs=${pVpcSubnetCidrs} \
                  -e AWS_REGION=${AWS_REGION} \
                  -e pVPNDxTransitive=${pVPNDxTransitive} \
                  -e pConnectionId=${pConnectionId} \
                  -e pTgwId=${pTgwId} \
                  -e pAZVar=${pAZVar} \
                  -e stack_name='''+vpc_stack_name+''' \
                  -e cf_dest_path=${cf_dest_path} \
                  -e pEnvTag=${pEnvTag} \
                  -e pVPN01TunnelInsideCidr=${pVPN01TunnelInsideCidr} \
                  -e pVPN02TunnelInsideCidr=${pVPN02TunnelInsideCidr} \
                  -e pProjectShort="${pProjectShort}" \
            	    -e pVPCSpokeNum=${pVPCSpokeNum} \
            	    -e TAG_VALUE="${TAG_VALUE}" \
                  -e INIT_USE_PREVIOUS_VALUE=${INIT_USE_PREVIOUS_VALUE} \
                  -e pBucketNamePrefix=${pBucketNamePrefix} --tags "${TAGS}" -vvv
                    '''}
          }
       }
    }
}

def executeSpecTests() {

  if (params.TAGS.contains('vpc')) {
    stage("Execute awspec tests")
    {
        //def ansibleTags = ${TAGS}
          echo "Testing AWS resources"
          script {sh '''
          export ACCOUNTID=${ACCOUNTID}
          export ROLENAME=${ROLENAME}                                                                                    e
          export AWS_REGION=${AWS_REGION}
          export STACKNAME=${STACK_NAME}
          export PROJECTSHORT="${pProjectShort}"
          export PATH=$PATH:/usr/local/rvm/rubies/ruby-2.5.3/bin
          cd spec-tests && bundle && rake spec
          '''}
        }
    }
  else
      echo "Skipping awspec tests"

}

def validateCFNTemplates() {

  stage("Validating CFN templates using cfn-nag") {
    echo "Validating CFN templates using cfn-nag"
  }
}


def ignoreFirstBuild() {

  stage("parameterizing") {
      script {
          if ("${env.BUILD_NUMBER}" == "1") {
              currentBuild.result = 'ABORTED'
              error('DRY RUN COMPLETED. JOB PARAMETERIZED.')
          }
      }
  }
}
