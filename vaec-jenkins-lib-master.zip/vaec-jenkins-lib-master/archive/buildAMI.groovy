def build(){
  node {

      stage('Checkout') {
          checkout scm
      }
      stage('Build AMI') {
        buildAMI()
      }
      stage('Test AMI') {

      }
  }
}

def buildAMI()
{
      echo "Testing AWS resources"
      script {sh '''
      cd vaec-win-auto && /var/lib/jenkins/packer build ${packer_build_json}
      '''}
}
