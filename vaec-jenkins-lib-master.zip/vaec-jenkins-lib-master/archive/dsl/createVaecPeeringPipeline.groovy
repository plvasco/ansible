
//import vpc.createVPCPipelineJobs

sectionHeaderStyleCss = 'color: black; background: #7FAB9B; font-family: Roboto, sans-serif !important; font-weight: bold; padding: 5px; text-align: center; '

separatorStyleCss = 'border: 0; border-bottom: 1px dashed #ccc; background: #999; '

def createDeploymentJob(jobName, repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC pipeline job to deploy for vpc peering"
        parameters {
          parameterSeparatorDefinition {
             name('Mandatory parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for VPC peering pipeline')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
          stringParam('action', 'pcx-create', 'pcx-create or pcx-delete')
          stringParam('pcx_id', 'pcx-xxxxx', 'pcx-id, Required: (pcx-delete only)')
          stringParam('requester_owner_id', '', 'AWS account number, Required: (pcx-create or pcx-delete)')
          stringParam('requester_region', 'us-gov-rrrr-1', 'AWS Region, Required: (pcx-create or pcx-delete)')
          stringParam('requester_vpc_id', 'vpc-rrrr','vpc id, Required: (pcx-create or pcx-delete)')
		  stringParam('accepter_owner_id', '','AWS account number, Required: (pcx-create)')
		  stringParam('accepter_region', 'us-gov-aaaa-1', 'AWS Region, Required: (pcx-create)')
		  stringParam('accepter_vpc_id', 'vpc-aaaa','vpc id, Required: (pcx-create)')


          parameterSeparatorDefinition {
             name('VPC peering override parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Override parameters for VPC peering connection')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
           stringParam('verify_connection_id', '', 'By default, peering connections in the same tier (Development-313, Stage-312 or Production-311) will be skipped since peering is not necessary. To override put "False"')
           stringParam('pcx_name_tag', '', 'By default, the peering connection tag Name = "requester_vpc_Name-peering-accepter_vpc_Name". To override, provide alternate name')
        }		
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}

def createTestJob(jobName, repoUrl) {
    multibranchPipelineJob(jobName) {
        branchSources {
            git {
                id('123456789')
                remote(repoUrl)
                credentialsId(vaGitCred)
                includes('*')
            }

        }
        //triggers {
          //   cron("H/5 * * * *")
      //  }
        factory {
          workflowBranchProjectFactory {
              scriptPath("jenkins/Jenkinsfile")
          }
        }

    }
}

def buildPipelineJobs() {
    def rootFolder = "vaec-pipelines"
    pipelineFolder = rootFolder + "/"+ jobName + "-pipeline"

    def deployName = pipelineFolder+"/deploy"
    def multiTestName = pipelineFolder + "/test"
    def folderName =
    folder(pipelineFolder) {
      description('Folder containing deploy and test jobs')
    }  
    createDeploymentJob(deployName, gitRepo)
    createTestJob(multiTestName, gitRepo)

}

buildPipelineJobs()
