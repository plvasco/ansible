
//import vpc.createVPCPipelineJobs

sectionHeaderStyleCss = 'color: black; background: #7FAB9B; font-family: Roboto, sans-serif !important; font-weight: bold; padding: 5px; text-align: center; '

separatorStyleCss = 'border: 0; border-bottom: 1px dashed #ccc; background: #999; '

def createDeploymentJob(jobName, repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC pipeline job to deploy https://github.ec.va.gov/AWS/vaec-shared-lib"
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}

def createTestJob(jobName, repoUrl) {
    multibranchPipelineJob(jobName) {
        branchSources {
            git {
                id('123456789')
                remote(repoUrl)
                credentialsId(vaGitCred)
                includes('*')
            }

        }
        //triggers {
          //   cron("H/5 * * * *")
      //  }
        factory {
          workflowBranchProjectFactory {
              scriptPath("jenkins/Jenkinsfile")
          }
        }

    }
}

def buildPipelineJobs() {
    def rootFolder = "vaec-pipelines"
    pipelineFolder = rootFolder + "/"+ jobName + "-pipeline"

    def deployName = pipelineFolder+"/deploy"
    def multiTestName = pipelineFolder + "/test"
    def folderName =
    folder(pipelineFolder) {
      description('Folder containing deploy and test jobs')
    }  
    createDeploymentJob(deployName, gitRepo)
    createTestJob(multiTestName, gitRepo)

}

buildPipelineJobs()
