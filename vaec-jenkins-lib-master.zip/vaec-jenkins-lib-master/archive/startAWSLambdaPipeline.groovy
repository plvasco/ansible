def Initiate() {
    node {
        // Execute different stages depending on the job
        if(env.JOB_NAME.contains("invokeLamda")){

            stage('Checkout') {
                checkout scm
            }
            executeAWSLambda()

        } else if(env.JOB_NAME.contains("test")) {
            //validateAndTestVaecVPC.validateAndTest()
        }
    }
}




def executeAWSLambda() {

      stage("Sharing AMI: ${params.AMI_IDS}")
      {
          String ami_id_list
          String aws_account_id_list

          if(params.AMI_IDs.trim().equals(''))
          {
            currentBuild.result = 'ABORTED'
            error('No AMI IDs are specified. Terminating Lambda executing job')
          }
          else
          {
                aws_account_id_list = params.AWS_ACCOUNT_IDs
                ami_id_list= params.AMI_IDs
                child_cmk_alias= params.CHILD_ACCOUNT_CMK_ALIAS
                CROSS_REGION_COPY = params.CROSS_REGION_COPY
                DEST_AWS_REGION = params.DEST_AWS_REGION
                DEST_REGION_CMK_ARN = params.DEST_REGION_CMK_ARN
                CHILD_ACCOUNT_ROLENAME = params.CHILD_ACCOUNT_ROLENAME
                if(params.CROSS_REGION_COPY.equals('no'))
                {
                  script {
                  sh '''
                            aws lambda invoke \
                                  --function-name vaec-ami-share \
                                  --log-type Tail \
                                  --payload '{"dest_account_ids": "'''+aws_account_id_list+'''","dest_kms_key_alias": "'''+child_cmk_alias+'''","source_ami_ids": "'''+ami_id_list+'''", "destination_account_rolename": "'''+CHILD_ACCOUNT_ROLENAME+'''" }' \
                                  outputfile.txt \
                                  --region $AWS_REGION \
                                  --query LogResult --output text | base64 --decode
                            echo $?
                            cat outputfile.txt
                            if grep -q "errorMessage" outputfile.txt
                            then
                                exit 1
                            else
                                exit 0
                            fi

                  '''}

                }
                //end of params.CROSS_REGION_COPY.equals('no')
                else //Perform cross region copy within the same AWS Account
                {
                script {
                sh '''

                          aws lambda invoke \
                                --function-name vaec-ami-share \
                                --log-type Tail \
                                --payload '{"action": "cross_region_ami_copy","dest_account_ids": "'''+aws_account_id_list+'''","destination_region": "'''+DEST_AWS_REGION+'''","source_ami_ids": "'''+ami_id_list+'''", "destination_region_cmk_arn": "'''+DEST_REGION_CMK_ARN+'''" }' \
                                outputfile.txt \
                                --region $AWS_REGION \
                                --query LogResult --output text | base64 --decode
                          echo $?
                          cat outputfile.txt
                          if grep -q "errorMessage" outputfile.txt
                          then
                              exit 1
                          else
                              exit 0
                          fi

                '''}
                }
          }
      }
}
