def createDeploymentJob(jobName, repoUrl) {
// Deployment job always runs against master brnach
    pipelineJob(jobName) {
        description "VAEC VPC pipeline job"
        parameters {
           stringParam('pProjectName', '"Project Name"', 'Project Name Tag')
           stringParam('pProjectShort', 'ProjShort', 'Project Short Tag')
           stringParam('pVAECId', 'AWG20190103001', 'pVAECId')
           stringParam('pMetadataDocument', 'https://prod.adfs.federation.va.gov/federationmetadata/2007-06/federationmetadata.xml', 'The XML metadata document to use when trusting the Identity Provider')
           stringParam('pBucketNamePrefix', 'vaec-automation', 'Bucket name to hold landingzone templates. Default value is vaec-automation')
           choiceParam('pEnvironmentTag', ['Development', 'Stage', 'Production','CORE','SECURITY', 'SECURITYLOGS', 'DevOps','Sandbox', 'LIGHTHOUSE-POC','PreProd'], 'AWS Account specific environment Tag')
           stringParam('pVpcCidr', '192.168.82.0/24', 'VPC CIDR')
           stringParam('pVpcSecondaryCidrs', '192.168.82.0/26', 'Comma delimited list of VPC Secondary CIDRs')
	   stringParam('pEnvTag', '', 'VPC environment tag. This parameter will be used in VPC name. Example values are, Development,Stage,Production,CORE,SECURITY,SECURITYLOGS,DevOps,Sandbox,LIGHTHOUSE-POC,PreProd,Stage-Ops')
           stringParam('pVpcSubnetCidrs', '192.168.82.0/26,192.168.82.64/26,192.168.82.128/26,192.168.82.192/26', 'VPC subnet CIDRs')
           stringParam('pVPNDxTransitive', 'DevDx', 'pVPNDxTransitive')
           stringParam('pVPN01TunnelInsideCidr', '169.254.115.136/30,169.254.115.140/30', 'pVPN01TunnelInsideCidr')
           stringParam('pVPN02TunnelInsideCidr', '169.254.125.136/30,169.254.125.140/30', 'pVPN02TunnelInsideCidr')
           stringParam('pVPCSpokeNum', '', 'VPC Spoke number must be used when virtual private gateway is used with VPC')
            stringParam('pTgwId', '', 'Transit Gateway Id. Specify this parameter if you are using Transit Gateway, pass vpc-tgw in TAGS instead of vpc')
           stringParam('pConnectionId', '', 'ConnectionId must be specified when transit gateway is used with VPC')
           stringParam('pAZVar', 'AZ1,AZ2,AZ3', 'Comma separated Availability zone-this field is used in populating AWS tags')
           stringParam('cf_dest_path', '../cfn-templates/ProjShort-VPC-Env-v1.yml', 'VPC CloudFormation path. This must be specified when vpc or vpc-tgw is specified in TAGS field')
           choiceParam('INIT_USE_PREVIOUS_VALUE', ['true', 'false'], 'INIT_USE_PREVIOUS_VALUE')
           stringParam('AWS_REGION', 'us-gov-west-1', 'AWS Region')
           stringParam('ACCOUNTID', '477310831272', 'Comma separated AWS account Id')
           stringParam('ROLENAME', 'vaec-authorizer-role', 'AWS cross account Role that jenkins assumes to execute tasks specified in TAGS')
           stringParam('STACK_DESCRIPTION', '"<ProjShort> <Environment> VPC"', 'Should be wrapped around quotes')
           stringParam('STACK_NAME', '<ProjShort>-VPC-<pEnvTag>', 'Name of Cloudformation stack to be deployed')
	   stringParam('TAG_KEY', 'Name', 'Tag Key for post creation tagging')
	   stringParam('TAG_VALUE', '"DEFAULT - DO NOT USE"', 'Tag value for tag name')
	   stringParam('TAGS', 'default,assume', 'Tags for Ansible to run specific tasks. Possible values are default,assume,init,landing,project-admin,vaec-tag,vpc,vpc-tgw,vpc-secondary-cidr,post-creation,vpn,vaec-snapshot,delete-default-vpc')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}
def createLZDeploymentJob(jobName, repoUrl) {
// Deployment job always runs against master brnach
  String sectionHeaderStyleCss = 'color: black; background: #ffdab3; font-family: Roboto, sans-serif !important; padding: 5px; text-align: center; '

  String separatorStyleCss = 'border: 0; border-bottom: 1px dashed #ccc; background: #999; '

    pipelineJob(jobName) {
        description "VAEC Seed Job"
        //choiceParam('pEnvironmentTag', ['Development', 'Stage', 'Production','CORE','SECURITY', 'SECURITYLOGS', 'DevOps','Sandbox', 'LIGHTHOUSE-POC','PreProd'], 'AWS Specific Environment')

        parameters {
          parameterSeparatorDefinition {
             name('Mandatory parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for all type of tasks')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }

          stringParam('AWS_REGION', 'us-gov-west-1', 'AWS Region')
          stringParam('ACCOUNTID', '', 'Command separated AWS Account ID where tasks specified in ANSIBLE_TAGS are executed')

          parameterSeparatorDefinition {
             name('Below Parameters are used in vaec-init while provisioning a new AWS account')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters if vaec-init is specified in ANSIBLE_TAGS ')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
           stringParam('pProjectName', '"Project Name"', 'Project Name Tag. It must be enclosed within double quotes')
           stringParam('pProjectShort', 'vaec-short', 'Project Short Tag')
           stringParam('pVAECId', 'AWG20190103001', 'pVAECId')

           parameterSeparatorDefinition {
              name('Ansilbe playbook tags. Values can vary depending on the intended tasks to be executed in above AWS Account IDs')
              separatorStyle(separatorStyleCss)
              sectionHeader('Ansilbe playbook tags. Values can vary depending on the intended tasks to be executed in above AWS Account IDs')
              sectionHeaderStyle(sectionHeaderStyleCss)
           }
           stringParam('ANSIBLE_TAGS', 'default,assume', 'Tags for Ansible to run specific tasks. Possible values are default,assume,init,landing,project-admin,vaec-tag,vpc,tgw-vpc,vpc-secondary-cidr,post-creation,vpn,vaec-snapshot,delete-default-vpc')

           parameterSeparatorDefinition {
              name('Miscellaneous parameters with default values which seldom change')
              separatorStyle(separatorStyleCss)
              sectionHeader('Miscellaneous parameters with default values which seldom change')
              sectionHeaderStyle(sectionHeaderStyleCss)
           }
           stringParam('ROLENAME', 'vaec-authorizer-role', 'AWS Remote Assume Role Name')
           stringParam('TAG_KEY', 'Name', 'Tag Key for post creation tagging')
      	   stringParam('TAG_VALUE', '"DEFAULT - DO NOT USE"', 'Tag value for tag name')
          stringParam('pMetadataDocument', 'https://prod.adfs.federation.va.gov/federationmetadata/2007-06/federationmetadata.xml', 'The XML metadata document to use when trusting the Identity Provider')
           stringParam('pBucketNamePrefix', 'vaec-automation', 'Bucket name for storing landingzone CFN templates used while deploying CFN stacks')
           choiceParam('INIT_USE_PREVIOUS_VALUE', ['true', 'false'], 'INIT_USE_PREVIOUS_VALUE')

        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}

def createAWSLambdaJob(jobName, repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC AWS Lambda Execution Job"
        parameters {
           choiceParam('CROSS_REGION_COPY', ['no', 'yes'], 'Cross Region Copy within the same AWS region?')
           choiceParam('AWS_REGION', ['us-gov-west-1', 'us-gov-east-1'], 'AWS Region where lambda function is deployed')
           choiceParam('DEST_AWS_REGION', ['us-gov-east-1', 'us-gov-west-1'], 'Destination AWS Region where we intend to make a AMI copy. This is required only if CROSS_REGION_COPY is selected yes and parameter is ignored if no')
           stringParam('DEST_REGION_CMK_ARN', '', 'Destination region Customer master key (CMK) arn to use when copying ami across different region within the same AWS account. This is required only if CROSS_REGION_COPY is selected yes and parameter is ignored if no')
           stringParam('AWS_ACCOUNT_IDs', '', 'Comma separated AWS child Account IDs where we intend to share encrypted AMI')
           stringParam('AMI_IDs', '', 'Comma separated AMI ID to share with above AWS Accounts')
           stringParam('CHILD_ACCOUNT_CMK_ALIAS', '', 'Child account customer master key (CMK) to use when creating the encrypted AMI in child account. This option can be used only with one account in AWS_ACCOUNT_IDs field')
           stringParam('CHILD_ACCOUNT_ROLENAME', 'vaec-authorizer-role', 'Child account role name that lambda function assumes for performing AMI copy operation. This option can be used only with one account in AWS_ACCOUNT_IDs field')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}

def createAMIPipelineJob(jobName, repoUrl) {
// Deployment job always runs against master brnach
    pipelineJob(jobName) {
        description "VAEC AMI pipeline Job"
        parameters {
           choiceParam('AMI Type', ['RedHat', 'Windows 2012', 'Windows 2016'], 'AMI Type')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}

def createTestJob(jobName, repoUrl) {
    multibranchPipelineJob(jobName) {
        branchSources {
            git {
                remote(repoUrl)
                credentialsId(vaGitCred)
                includes('*')
            }

        }
        //triggers {
          //   cron("H/5 * * * *")
      //  }
        factory {
          workflowBranchProjectFactory {
              scriptPath("jenkins/Jenkinsfile")
          }
        }

    }
}

def buildPipelineJobs() {
    def rootFolder = "vaec-pipelines"
    pipelineFolder = rootFolder + "/"+ jobName + "-pipeline"

    def deployName = pipelineFolder+"/deploy"
    def multiTestName = pipelineFolder + "/test"
    def folderName =
    folder(pipelineFolder) {
      description('Folder containing deploy and test jobs')
    }

    if(jobName.equals('vaec-ami'))
    {
      deployName = pipelineFolder+"/buildAMI"
      createAMIPipelineJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)

    }
    if(jobName.contains('vpc'))
    {
      createDeploymentJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
    if(jobName.contains('landingzone'))
    {
      createLZDeploymentJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
    if(jobName.contains('vaec-ami-share'))
    {
      deployName = pipelineFolder+"/invokeLamda"
      createAWSLambdaJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
}

buildPipelineJobs()
