
//import vpc.createVPCPipelineJobs

sectionHeaderStyleCss = 'color: black; background: #7FAB9B; font-family: Roboto, sans-serif !important; font-weight: bold; padding: 5px; text-align: center; '

separatorStyleCss = 'border: 0; border-bottom: 1px dashed #ccc; background: #999; '

/*
def createDeploymentJob(jobName, repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC VPC pipeline job. This pipeline can be used only with one AWS account at a time with an exception for vpn-all task"
        parameters {
          parameterSeparatorDefinition {
             name('Mandatory parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for VPC pipeline')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
          stringParam('AWS_REGION', 'us-gov-west-1', 'AWS Region')
          stringParam('ACCOUNTID', '', 'Single AWS Account where we intend to deploy any of VPC related tasks with an exception of vpn-all task, where you can specify comma separated AWS account IDs')
          stringParam('ANSIBLE_TAGS', 'assume', 'Tags for Ansible to run VPC specific tasks. Possible values: assume, vpc_tgw, vpc_tgw_secondary_cidr, vpc, vpc_secondary_cidr, post_vpc_creation, vpn_all')

          parameterSeparatorDefinition {
             name('VPC Parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for VPC creation')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
           stringParam('pEnvTag', '', 'VPC environment tag. This parameter will be used in VPC name. Example values are, Development,Stage,Production,CORE,SECURITY,SECURITYLOGS,DevOps,Sandbox,LIGHTHOUSE-POC,PreProd,Stage-Ops')
           stringParam('pVpcCidr', '', 'VPC CIDR')
           stringParam('pVpcSubnetCidrs', '', 'Comma separated VPC subnet CIDRs')
           stringParam('pVpcSecondaryCidrs', '', 'Comma delimited list of VPC Secondary CIDRs. Make sure no spaces between each CIDRs')
           stringParam('pVpcCfnPath', '../cfn-tgw/vpc-1-az-2-subnet-4.yml', 'VPC CloudFormation path. This must be specified when vpc or vpc-tgw is specified in ANSIBLE_TAGS field. Please check git repo https://github.ec.va.gov/AWS/vaec-vpc to pick appropriate CFN template and while specifying no need to specify .j2 extension. VPC CFN templates can be found either in cfn-templates or cfn-tgw folder')

          parameterSeparatorDefinition {
             name('VPC Parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory Parameters if VPC is using Transit Gateway')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }

          stringParam('pTgwId', 'tgw-089990091647676d2', 'Transit Gateway Id. Specify this parameter if you are using Transit Gateway, pass vpc-tgw in ANSIBLE_TAGS instead of vpc')
          stringParam('pConnectionId', '', 'ConnectionId must be specified when transit gateway is used with VPC')

          parameterSeparatorDefinition {
             name('VPC Parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory Parameters if VPC is using Virtual Private Gateway, CSR and VPC peering')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
          stringParam('pVPNDxTransitive', 'DevDx', 'pVPNDxTransitive. Example values are, DevDx, StageDx,ProdDx')
          stringParam('pVPN01TunnelInsideCidr', '169.254.115.136/30,169.254.115.140/30', 'pVPN01TunnelInsideCidr')
          stringParam('pVPN02TunnelInsideCidr', '169.254.125.136/30,169.254.125.140/30', 'pVPN02TunnelInsideCidr')
          stringParam('pVPCSpokeNum', '', 'VPC Spoke number must be used when virtual private gateway is used with VPC')

          parameterSeparatorDefinition {
             name('Common pipeline parameters with default values')
             separatorStyle(separatorStyleCss)
             sectionHeader('Common pipeline parameters with default values')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
           stringParam('pBucketNamePrefix', 'vaec-automation', 'Bucket name for storing script files related to VPC pipeline. Default value is vaec-automation')
           choiceParam('INIT_USE_PREVIOUS_VALUE', ['true', 'false'], 'INIT_USE_PREVIOUS_VALUE')
           stringParam('ROLENAME', 'vaec-authorizer-role', 'AWS cross account Role to use for create a VPC')
           stringParam('TAG_KEY', 'Name', 'Tag Key for post creation tagging')
           stringParam('TAG_VALUE', '"DEFAULT - DO NOT USE"', 'Tag value for tag name')
           stringParam('pAZVar', 'AZ1,AZ2,AZ3', 'Comma separated AWS availability zones. This field is used in populating AWS tags')
           stringParam('CFN_STACK_TO_BE_DELETED', '', 'AWS CloudFormation stack name to be deleted')
           stringParam('VERBOSITY', '', 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}
*/

def createLZDeploymentJob(jobName, repoUrl) {
// Deployment job always runs against master branch

    pipelineJob(jobName) {
        description "VAEC Landingzone pipeline"
        //choiceParam('pEnvironmentTag', ['Development', 'Stage', 'Production','CORE','SECURITY', 'SECURITYLOGS', 'DevOps','Sandbox', 'LIGHTHOUSE-POC','PreProd'], 'AWS Specific Environment')

        parameters {
          parameterSeparatorDefinition {
             name('Mandatory parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for all type of tasks')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }

          stringParam{
            name('ACCOUNTID')
            defaultValue('')
            description('Comma separated AWS Account IDs. Can specify \'all\' only if ANSIBLE_TAGS is load_ssm_params')
            trim(true)
          }
          stringParam{
            name('ANSIBLE_TAGS')
            defaultValue('assume')
            description('assume, account_init (policies, authorizer_role, load_ssm_params, idp_adfs_create, landingzone, project_admin), account_controls (delete_Default_ct, ssm_explorer_enable), delete_cfn_stack\n\n [Include ANSIBLE_TAGS=\'assume\' for ACCOUNTID= single/multiple accounts, do not include \'assume\' if ACCOUNTID=all]\n\nExample1: Single account (us-gov-west-1): assume, account_init, account_controls\nExample2: Multi account (us-gov-west-1): assume, project_admin\nExample3: Multi account, \'all\' accounts, all regions (AWS_REGION ignored): load_ssm_params\n')
            trim(true)
          }
          stringParam{
            name('CFN_STACK_TO_BE_DELETED')
            defaultValue('')
            description('delete_cfn_stack: AWS CloudFormation stack name to be deleted')
            trim(true)
          }

//          parameterSeparatorDefinition {
//             name('pVaecAwsAccountsFilSep')
//             separatorStyle(separatorStyleCss)
//             sectionHeader('Required if ANSIBLE_TAGS contains \'organizations\' or \'organizations_all\' or \'config_account\'')
//             sectionHeaderStyle(sectionHeaderStyleCss)
//          }
//           fileParam('pVaecAwsAccountsFile', 'VAEC-AWS-Accounts.xlsx: Download to desktop from https://dvagov.sharepoint.com/sites/OITECSOApplication/Environments/AWS/VAEC-AWS-Accounts.xlsx. Worksheet must be \"VAEC-AWS-Accounts\"')

           parameterSeparatorDefinition {
              name('Common pipeline parameters with default values')
              separatorStyle(separatorStyleCss)
              sectionHeader('Common pipeline parameters with default values')
              sectionHeaderStyle(sectionHeaderStyleCss)
           }
           stringParam {
             name('AWS_REGION')
             defaultValue('us-gov-west-1')
             description('AWS Region')
             trim(true)
           }
           stringParam('ROLENAME', 'vaec/vaec-authorizer', 'AWS Remote Assume Role Name')
		   stringParam('EXTERNALID', 'ab06fe02-6ecd-4868-bd92-526b7fcd4028', 'External Id')
           stringParam('AUTOMATION_BUCKET', 'vaec-automation-348286891446-us-gov-west-1', 'Shared S3 bucket name for storing vaec-automation stacks and code')
           stringParam('pMetadataDocument', 'https://prod.adfs.federation.va.gov/federationmetadata/2007-06/federationmetadata.xml', 'XML metadata document to use when trusting the Identity Provider')
           stringParam('pBucketNamePrefix', 'vaec-automation', 'init: S3 bucket name for storing vaec-automation stacks and code')
           stringParam('VERBOSITY', '-v', 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode')


        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}

def createOrganizationsJob(jobName, repoUrl) {
// Deployment job always runs against master branch

    pipelineJob(jobName) {
        description "VAEC AWS Organization pipeline"


        parameters {
          parameterSeparatorDefinition {
             name('Mandatory parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for all type of tasks')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }

          stringParam{
            name('ACCOUNTID')
            defaultValue('')
            description('Comma separated AWS Account IDs. Specify \'all\' if ANSIBLE_TAGS is orgs_add_member')
            trim(false)
          }
          stringParam{
            name('ANSIBLE_TAGS')
            defaultValue('')
            description('orgs_process_member, python_execute')
            trim(false)
          }

      //    stringParam{
    //        name('TAG_KEY')
    //        defaultValue('')
    //        description('Tag key for organization member. This is requred if orgs_get_account_tags specified in ANISBLE_TAGS,\nExample: vaec:ProjectShort, vaec:AppCode, vaec:VAECID, vaec:CommercialID, vaec:ProjectName')
    //        trim(false)
      //    }

    //      parameterSeparatorDefinition {
    //         name('pVaecAwsAccountsFilSep')
  //           separatorStyle(separatorStyleCss)
  //           sectionHeader('Required if ANSIBLE_TAGS contains \'orgs_process_member\'')
  //           sectionHeaderStyle(sectionHeaderStyleCss)
  //        }
  //         fileParam('pVaecAwsAccountsFile', 'VAEC-AWS-Accounts.xlsx: Download to desktop from https://dvagov.sharepoint.com/sites/OITECSOApplication/Environments/AWS/VAEC-AWS-Accounts.xlsx. Worksheet must be \"VAEC-AWS-Accounts\"')

           parameterSeparatorDefinition {
              name('Common pipeline parameters with default values')
              separatorStyle(separatorStyleCss)
              sectionHeader('Common pipeline parameters with default values')
              sectionHeaderStyle(sectionHeaderStyleCss)
           }

           //stringParam('ROLENAME', 'vaec-authorizer-role', 'AWS Remote Assume Role Name')
           stringParam {
             name('AWS_REGION')
             defaultValue('us-gov-west-1')
             description('AWS Region')
             trim(true)
           }

           stringParam('VERBOSITY', '-v', 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode')

           parameterSeparatorDefinition {
              name('inventory_script')
              separatorStyle(separatorStyleCss)
              sectionHeader('Command for executing python, from root of repo https://github.ec.va.gov/AWS/vaec-organizations')
              sectionHeaderStyle(sectionHeaderStyleCss)
           }
           stringParam{
             name('EXEC_PARAMS')
             defaultValue('')
             description('Specify execute_inventory_script tag value in ANSIBLE_TAGS parameter to execute python command from inventory folder. Specify python_execute tag value in ANSIBLE_TAGS parameter to execute python command from inventory folder. \nexample format:\n1. inventory/vaec_inventory_ec2inst.py --account-id 477194928391 --region all\n2. get-tags-from-orgs.py --account-id 477310831272\n3. get-accountids-from-orgs.py\n4. inventory/vaec_accountids_with_vpcs.py --region us-gov-east-1\n5. inventory/decode_auth_msg.py --account-id <acctid> --region <region> --encoded-message "<encoded-message>"')
             trim(false)
           }

        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
        triggers {
            // H/5 * * * * % ANSIBLE_TAGS=script_execute; EXEC_PARAMS="cd ../ && ls -al"; VERBOSITY=-vvv
            // "At 06:00 on Monday and Wednesday."
			// 0 6 * * 1,3 % ANSIBLE_TAGS= script_execute; EXEC_PARAMS="cd ../inventory && bash ./ec2_ssm_inventory.sh"
            parameterizedTimerTrigger {
                parameterizedSpecification('''
				H 12 * * 1-5 % ANSIBLE_TAGS= script_execute; EXEC_PARAMS="python3  ../inventory/vaec_trustedadvisor_refresh.py --nodryrun"
                ''')
            }
        }
    }
}


// def createAWSLambdaJob(jobName, repoUrl) {
// Deployment job always runs against master branch
//    pipelineJob(jobName) {
//        description "VAEC AWS Lambda Execution Job"
//        parameters {
//           choiceParam('CROSS_REGION_COPY', ['no', 'yes'], 'Cross Region Copy within the same AWS region?')
//           choiceParam('AWS_REGION', ['us-gov-west-1', 'us-gov-east-1'], 'AWS Region where lambda function is deployed')
//           choiceParam('DEST_AWS_REGION', ['us-gov-east-1', 'us-gov-west-1'], 'Destination AWS Region where we intend to make a AMI copy. This is required only if CROSS_REGION_COPY is selected yes and parameter is ignored if no')
//           stringParam('DEST_REGION_CMK_ARN', '', 'Destination region Customer master key (CMK) arn to use when copying ami across different region within the same AWS account. This is required only if CROSS_REGION_COPY is selected yes and parameter is ignored if no')
//           stringParam('AWS_ACCOUNT_IDs', '', 'Comma separated AWS child Account IDs where we intend to share encrypted AMI')
//           stringParam('AMI_IDs', '', 'Comma separated AMI ID to share with above AWS Accounts')
//           stringParam('CHILD_ACCOUNT_CMK_ALIAS', '', 'Child account customer master key (CMK) to use when creating the encrypted AMI in child account. This option can be used only with one account in AWS_ACCOUNT_IDs field')
//           stringParam('CHILD_ACCOUNT_ROLENAME', 'vaec-authorizer-role', 'Child account role name that lambda function assumes for performing AMI copy operation. This option can be used only with one account in AWS_ACCOUNT_IDs field')
//        }
//        definition {
//            cpsScm {
//                scm {
//                    git {
//                        remote {
//                            url(repoUrl)
//                            credentials(vaGitCred)
//                        }
//
//                        branches("master")
//                        extensions {
//                            cleanBeforeCheckout()
//                        }
//                    }
//                }
//                scriptPath("jenkins/Jenkinsfile")
//           }
//        }
//    }
//}

def createVaecAMIShareJob(jobName, repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC AWS AMI Sharing Job"
        parameters {
          parameterSeparatorDefinition {
             name('Common required parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Common required parameters')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }

           choiceParam('AWS_REGION', ['us-gov-west-1', 'us-gov-east-1'], 'AWS Region where AMI copy is being performed')
           stringParam('AWS_ACCOUNT_IDs', '', 'Comma separated AWS Account IDs. Specify \'all\' for copying AMI to all member accounts in AWS organization ')
           stringParam('AMI_IDs', '', 'Region specific comma separated AMI IDs from core-gov-internal. Get the latest from: https://github.ec.va.gov/AWS/vaec-ami')
           //stringParam('ROLENAME', 'vaec-authorizer-role', 'AWS Remote Assume Role Name')
           choiceParam('REQUIRE_VALID_VPC', ['True', 'False'], 'Require destination account/region to have atleast one valid VPC with ConnectionID in order to share AMI')

           parameterSeparatorDefinition {
              name('Optional parameters for copying AMI from us-gov-west-1 to us-gov-east-1 within core-gov-internal account')
              separatorStyle(separatorStyleCss)
              sectionHeader('Optional parameters for copying AMI from us-gov-west-1 to us-gov-east-1 within core-gov-internal account')
              sectionHeaderStyle(sectionHeaderStyleCss)
           }

           choiceParam('CROSS_REGION_COPY', ['no', 'yes'], 'Select yes for copying AMI From us-gov-west-1 to us-gov-east-1 in core-gov-internal account')
           choiceParam('DEST_AWS_REGION', ['us-gov-east-1', 'us-gov-west-1'], 'Destination AWS Region. This is required only if CROSS_REGION_COPY is selected yes and parameter is ignored if no')
           stringParam('DEST_REGION_CMK_ARN', '', 'Destination region Customer master key (CMK) arn to use when copying ami across different region within the same AWS account. This parameter required only if CROSS_REGION_COPY is selected to yes and is ignored if CROSS_REGION_COPY is set to no')
           //stringParam('SHARING_ACCOUNT_CMK_ALIAS', '', 'customer master key (CMK) to use when creating the encrypted AMI in shared account. This option can be used only with one account in AWS_ACCOUNT_IDs field')

        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}


// def createAMIPipelineJob(jobName, repoUrl) {
// // Deployment job always runs against master brnach
//     pipelineJob(jobName) {
//         description "VAEC AMI pipeline Job"
//         parameters {
//            choiceParam('AMI Type', ['RedHat', 'Windows 2012', 'Windows 2016'], 'AMI Type')
//            stringParam('packer_build_json', '', 'Packer build json file relative path')
//         }
//         definition {
//             cpsScm {
//                 scm {
//                     git {
//                         remote {
//                             url(repoUrl)
//                             credentials(vaGitCred)
//                         }
//
//                         branches("master")
//                         extensions {
//                             cleanBeforeCheckout()
//                         }
//                     }
//                 }
//                 scriptPath("jenkins/Jenkinsfile")
//             }
//         }
//     }
// }

def createTestJob(jobName, repoUrl) {
    multibranchPipelineJob(jobName) {
        branchSources {
            git {
                id('123456789')
                remote(repoUrl)
                credentialsId(vaGitCred)
                includes('*')
            }
        }
        configure {
          strategy {
              defaultBranchPropertyStrategy {
                props {
                   noTriggerBranchProperty()
                }
              }
          }
        }
        orphanedItemStrategy {
            discardOldItems {
                numToKeep(0)
            }
        }

        //triggers {
          //   cron("H/5 * * * *")
      //  }
        factory {
          workflowBranchProjectFactory {
              scriptPath("jenkins/Jenkinsfile")
          }
        }

    }
}
def createTGWVPCDeploymentJob(String jobName, String repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC VPC TGW pipeline job. This pipeline can be used only with one AWS account at a time with an exception for vpn-all task"
        parameters {
          parameterSeparatorDefinition {
             name('Mandatory parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for VPC pipeline')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }

          choiceParam('AWS_REGION', ['', 'us-gov-west-1', 'us-gov-east-1'], 'AWS Region')
          // stringParam('AWS_REGION', 'us-gov-west-1', 'AWS Region')
          stringParam('ACCOUNTID', '', 'AWS Account ID')
          stringParam('ANSIBLE_TAGS', 'assume', 'assume, vpc_tgw, post_vpc_creation (tag_default_sg_nacl_rtb, delete_default_sg_ingress_egress, msg_tgwa_handler, create_vpc_flowlog)\n Example1: assume, vpc_tgw, post_vpc_creation')

          parameterSeparatorDefinition {
             name('VPC Parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for VPC creation')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }

           stringParam('pEnvTag', '', 'VPC environment tag. Example values: Development, Stage, Production, Mgmt')
           stringParam('pConnectionId', '', 'ConnectionId. Format: 31X-XXX')
           stringParam('pVpcCidrs', '', ' Comma-delimited list of VPC IPv4 CIDRs')
           stringParam('pVpcSubnetCidrs', '', 'Comma-delimited list of subnet IPv4 CIDRs')
           // stringParam('pVpcSecondaryCidrs', '', 'Comma delimited list of VPC Secondary CIDRs. Make sure no spaces between each CIDRs')
           stringParam('pVpcCfnPath', '../cfn-tgw/vpc-1-az-2-subnet-4.yml', 'VPC CloudFormation template from https://github.ec.va.gov/AWS/vaec-vpc/tree/master/cfn-tgw (vaec-vpc Git repo).\nInclude ../cfn-tgw/, but do not include .j2 extension.')
           stringParam('pTierVar', 'App,Data', 'Subnet Tier Variables\nExample1: App,Data\nExample2: App1,App2,Data1,Data2')

          parameterSeparatorDefinition {
             name('Common pipeline parameters with default values')
             separatorStyle(separatorStyleCss)
             sectionHeader('Common pipeline parameters with default values')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
           // stringParam('pBucketNamePrefix', 'vaec-automation', 'Bucket name for storing script files related to VPC pipeline. Default value is vaec-automation')
           //choiceParam('INIT_USE_PREVIOUS_VALUE', ['true', 'false'], 'INIT_USE_PREVIOUS_VALUE')
           stringParam('ROLENAME', 'vaec/vaec-authorizer', 'AWS cross account Role to use for creating a VPC')
		   stringParam('EXTERNALID', 'ab06fe02-6ecd-4868-bd92-526b7fcd4028', 'External Id')
           stringParam('TAG_KEY', 'Name', 'Tag Key for post creation tagging')
           stringParam('TAG_VALUE', '"DEFAULT - DO NOT USE"', 'Tag value for tag name')
           stringParam('VERBOSITY', '-v', 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}
/*
def createVGWVPCDeploymentJob(jobName, repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC VPC VGW pipeline job. This pipeline can be used only with one AWS account at a time with an exception for vpn-all task"
        parameters {
          parameterSeparatorDefinition {
             name('Mandatory parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for VPC pipeline')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
          stringParam('AWS_REGION', 'us-gov-west-1', 'AWS Region')
          stringParam('ACCOUNTID', '', 'Single AWS Account where we intend to deploy any of VPC related tasks with an exception of vpn-all task, where you can specify comma separated AWS account IDs')
          stringParam('ANSIBLE_TAGS', 'assume', 'Tags for Ansible to run VPC specific tasks. Possible values: assume, vpc, vpc_secondary_cidr, post_vpc_creation, vpn-all')

          parameterSeparatorDefinition {
             name('VPC Parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for VPC creation')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
           stringParam('pEnvTag', '', 'VPC environment tag. This parameter will be used in VPC name. Example values are, Development,Stage,Production,CORE,SECURITY,SECURITYLOGS,DevOps,Sandbox,LIGHTHOUSE-POC,PreProd,Stage-Ops')
           stringParam('pVpcCidr', '192.168.82.0/24', 'VPC CIDR')
           stringParam('pVpcSubnetCidrs', '192.168.82.0/26,192.168.82.64/26,192.168.82.128/26,192.168.82.192/26', 'Comma separated VPC subnet CIDRs')
           stringParam('pVpcSecondaryCidrs', '192.168.82.0/26', 'Comma delimited list of VPC Secondary CIDRs. Make sure no spaces between each CIDRs')
           stringParam('pVpcCfnPath', '../cfn-tgw/vpc-1-az-2-subnet-4.yml', 'VPC CloudFormation path. This must be specified when vpc or vpc-tgw is specified in ANSIBLE_TAGS field. Please check git repo https://github.ec.va.gov/AWS/vaec-vpc to pick appropriate CFN template and while specifying no need to specify .j2 extension. VPC CFN templates can be found either in cfn-templates or cfn-tgw folder')


          parameterSeparatorDefinition {
             name('VPC Parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory Parameters if VPC is using Virtual Private Gateway, CSR and VPC peering')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
          stringParam('pVPNDxTransitive', 'DevDx', 'pVPNDxTransitive. Example values are, DevDx, StageDx,ProdDx')
          stringParam('pVPN01TunnelInsideCidr', '169.254.115.136/30,169.254.115.140/30', 'pVPN01TunnelInsideCidr')
          stringParam('pVPN02TunnelInsideCidr', '169.254.125.136/30,169.254.125.140/30', 'pVPN02TunnelInsideCidr')
          stringParam('pVPCSpokeNum', '', 'VPC Spoke number must be used when virtual private gateway is used with VPC')

          parameterSeparatorDefinition {
             name('Common pipeline parameters with default values')
             separatorStyle(separatorStyleCss)
             sectionHeader('Common pipeline parameters with default values')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }

           stringParam('pBucketNamePrefix', 'vaec-automation', 'Bucket name for storing script files related to VPC pipeline. Default value is vaec-automation')
           stringParam('ROLENAME', 'vaec-authorizer-role', 'AWS cross account Role to use for create a VPC')
           stringParam('TAG_KEY', 'Name', 'Tag Key for post creation tagging')
           stringParam('TAG_VALUE', '"DEFAULT - DO NOT USE"', 'Tag value for tag name')
           stringParam('pAZVar', 'AZ1,AZ2,AZ3', 'Comma separated AWS availability zones. This field is used in populating AWS tags')
           stringParam('VERBOSITY', '', 'Ansible playbook verbosity option. Example values are any of -v, -vv, -vvv. If it is blank, playbook is executed in normal mode')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}
*/

def createVPCPeeringJob(jobName, repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC pipeline job to deploy for vpc peering"
        parameters {
          parameterSeparatorDefinition {
             name('Mandatory parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Mandatory parameters for VPC peering pipeline')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
          // stringParam('action', 'pcx-create', 'pcx-create or pcx-delete')
          choiceParam('action', ['pcx-create', 'pcx-delete'], 'pcx-create or pcx-delete')
          stringParam('pcx_id', 'pcx-xxxxx', 'pcx-id, Required: (pcx-delete only)')
          stringParam('requester_owner_id', '', 'AWS account number, Required: (pcx-create or pcx-delete)')
          // stringParam('requester_region', 'us-gov-rrrr-1', 'AWS Region, Required: (pcx-create or pcx-delete)')
          choiceParam('requester_region', ['us-gov-west-1', 'us-gov-east-1'], 'AWS Region, Required: (pcx-create or pcx-delete)')
          stringParam('requester_vpc_id', 'vpc-rrrr','vpc id, Required: (pcx-create or pcx-delete)')
		  stringParam('accepter_owner_id', '','AWS account number, Required: (pcx-create)')
		  // stringParam('accepter_region', 'us-gov-aaaa-1', 'AWS Region, Required: (pcx-create)')
          choiceParam('accepter_region', ['us-gov-west-1', 'us-gov-east-1'], 'AWS Region, Required: (pcx-create)')
		  stringParam('accepter_vpc_id', 'vpc-aaaa','vpc id, Required: (pcx-create)')


          parameterSeparatorDefinition {
             name('VPC peering override parameters')
             separatorStyle(separatorStyleCss)
             sectionHeader('Override parameters for VPC peering connection')
             sectionHeaderStyle(sectionHeaderStyleCss)
          }
           stringParam('verify_connection_id', '', 'By default, peering connections in the same tier (Development-313, Stage-312 or Production-311) will be skipped since peering is not necessary. To override put "False"')
           stringParam('pcx_name_tag', '', 'By default, the peering connection tag Name = "requester_vpc_Name-peering-accepter_vpc_Name". To override, provide alternate name')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}

def createLibDeploymentJob(jobName, repoUrl) {
// Deployment job always runs against master branch
    pipelineJob(jobName) {
        description "VAEC pipeline job to deploy https://github.ec.va.gov/AWS/vaec-shared-lib"
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(repoUrl)
                            credentials(vaGitCred)
                        }

                        branches("master")
                        extensions {
                            cleanBeforeCheckout()
                        }
                    }
                }
                scriptPath("jenkins/Jenkinsfile")
            }
        }
    }
}

def buildPipelineJobs() {
    def rootFolder = "vaec-pipelines"
    pipelineFolder = rootFolder + "/"+ jobName + "-pipeline"

    def deployName = pipelineFolder+"/deploy"
    def multiTestName = pipelineFolder + "/test"
    def folderName =
    folder(pipelineFolder) {
      description('Folder containing deploy and test jobs')
    }

//    if(jobName.equals('vaec-ami'))
//    {
//      deployName = pipelineFolder+"/buildAMI"
//      createAMIPipelineJob(deployName, gitRepo)
//      createTestJob(multiTestName, gitRepo)
//    }
//    if(jobName.equals('vaec-vpc'))
//    {
//      createDeploymentJob(deployName, gitRepo)
//      createTestJob(multiTestName, gitRepo)
//    }
    if(jobName.contains('vpc-tgw'))
    {
      //def createVPCPipelineJobs = load "dsl/createVPCPipelineJobs.groovy"
      //def createVPCPipelineJobs = new createVPCPipelineJobs()
      createTGWVPCDeploymentJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
//    if(jobName.contains('vpc-vgw'))
//    {
//      //def createVPCPipelineJobs = load "dsl/createVPCPipelineJobs.groovy"
//      //def createVPCPipelineJobs = new createVPCPipelineJobs()
//      createVGWVPCDeploymentJob(deployName, gitRepo)
//      createTestJob(multiTestName, gitRepo)
//    }
    if(jobName.contains('landingzone'))
    {
      createLZDeploymentJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
    if(jobName.contains('vaec-ami-share'))
    {
      deployName = pipelineFolder+"/startShare"
      createVaecAMIShareJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
    if(jobName.contains('vaec-shared-lib'))
    {
      createLibDeploymentJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
    if(jobName.contains('vaec-organizations'))
    {
      createOrganizationsJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
    if(jobName.contains('vaec-vpc-peering'))
    {
      createVPCPeeringJob(deployName, gitRepo)
      createTestJob(multiTestName, gitRepo)
    }
}

buildPipelineJobs()
