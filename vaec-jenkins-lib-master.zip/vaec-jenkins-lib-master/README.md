# vaec-jenkins-lib
Jenkins shared library to create vaec jenkins pipeline jobs

## High level design

By following some of best practices for Jenkins, we will be using following Jenkins features to create pipeline jobs which are based on groovy programming language. This type of pipeline is called Scripted Pipeline
 -	Pipeline jobs are created using groovy based Jenkins Domain Specific Language (DSL) job called as seed job. Seed job is the only job you will manually configure as a freestyle project type. Seed jobs are very light weight and has very minimum steps to configure. DSL seed jobs are used in creating pipeline jobs.
 - Seed job will create two types of pipeline jobs:
      - _Single branch pipeline_ job which always runs against master branch-This will be used to deploy to a production environment.
      - _Multi-branch pipeline_ enables developers to execute and test respective branches while they are being developed.
- Every pipeline is scripted in Groovy and exposed as Global Jenkins shared library. Pipeline is triggered from a Jenkinsfile located in jenkins folder of respective project Git repository. The main reason we are using Jenkins shared library concept is we can abstract out various common pipeline steps and these steps are reusable across multiple different pipelines. Libraries are referred in Jenkinsfile via the @Library annotation.

## Global Library Folder stucture

    vaec-jenkins-lib
    │   README.md
    │
    ├───dsl
    │       	createPipelineJobs.groovy
    │     
    │
    └───vars
            	commonVaecVPCTGW.groovy
            	commonVaecLZ.groovy
            	startVaecVPCPipeline.groovy
            	validateAndTestVaecVPC.groovy
              validateAndTestLZPipeline.groovy
              .... etc

  dsl diretory contains job DSL script file that layouts the creation of various vaec pipelines using a seed job.
  The vars directory hosts script files that are exposed as a variable in Pipelines. The name of the file is the name of the variable in the Pipeline. The basename of each .groovy file should be a Groovy (~ Java) identifier, conventionally camelCased.

## File naming conventions and it's purpose in vars directory.

  - common*.groovy:  This contains actual pipeline execution steps and it is common to both deploy (Simple master branch pipiline) and multi branch pipeline.
  - startVaec*.groovy: This contains the trigger function that is referred in jenkins\Jenkinsfile of respective Git repo.
  - validateAndTest*.groovy: This contains parameter definitions for a multibranch pipeline. Parameters definitions are similar to the one defined in createPipelineJobs.groovy.

    Note: When you modify any parameter definition in createPipelineJobs, same changes should be reflected on appropriate validateAndTest*.groovy.

## PD-Jenkins credentials for github.ec.va.gov

SSH based communication is used in integrating Jenkins wiht VA GHE.
Credential Name: va-github-ssh-cred
Credential ID: va-github-ssh-cred

## Seed job vaec-create-pipeline-jobs
When you login to Jenkins, at the root folder, DSL seed job vaec-create-pipeline-jobs is displayed.
vaec-create-pipeline-jobs is used in creating other actual pipeline jobs. Currently following pipeline job creation is supported.

    - Landingzone
    - VPC using Transit Gateway
    - VAEC Python Libraries
    - VAEC AMI Share
    - VAEC Organization
    - VAEC VPC Peering Connection

When using vaec-create-pipeline-jobs, based on the pipeline you are creating, please use following appropriate parameter values


Description | Job Name(jobName) | VA Gitbub Credential ID (vaGitCred) | Git Repository URL(gitRepo)
--- | --- | --- | ---
Landingzone | vaec-landingzone | jenkins | git@github.ec.va.gov:AWS/vaec-landingzone.git
VPC using Transit Gateway | vaec-vpc-tgw | jenkins | git@github.ec.va.gov:AWS/vaec-vpc.git
VAEC Python Libraries | vaec-shared-lib | jenkins | git@github.ec.va.gov:AWS/vaec-shared-lib.git
VAEC AMI Share | vaec-ami-share | jenkins | git@github.ec.va.gov:AWS/vaec-ami-share.git
VAEC Organization | vaec-organizations | jenkins | git@github.ec.va.gov:AWS/vaec-organizations.git
VAEC VPC Peering Connection | vaec-vpc-peering | jenkins | git@github.ec.va.gov:AWS/vaec-vpc-peering.git
