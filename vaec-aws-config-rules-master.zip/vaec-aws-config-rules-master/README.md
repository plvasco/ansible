# vaec-aws-config-rules
CloudFormation and Lambda for VAEC AWS Config Rules
