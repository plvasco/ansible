# Account-specific permissions

## 878022744496 (ecsb-high-support)
- [iam-adfs-c-vaec-core-admin](iam-adfs-c-vaec-core-admin.yml)

## 423386782741 (Master Payer 1)
- [iam-c-vaec-authorizer](iam-c-vaec-authorizer.yml) -- custom template for this account, different from StackSets
- [iam-adfs-c-vaec-readonly](../iam-adfs-c-vaec-readonly.yml) -- same as StackSets
- [iam-adfs-c-vaec-billing](../iam-adfs-c-vaec-billing.yml)  -- same as StackSets
