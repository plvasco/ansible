# VA AWS Commercial Labs (CLAB)

VA AWS Commercial Labs (_CLAB_) are managed separately under Payer3 (VA Cloud 3) and not part of this configuration:

- Payer3: https://787095307480.signin.aws.amazon.com/console

## Key accounts and regions

|                                | Commercial
---                              | ---
Primary Region                   | Ohio us-east-2
Organizations Management Account | _Payer3_ (787095307480)
Organizations ID                 | o-wpjjyymrev

## Deploying new CLAB accounts:
- `vaec-aws-gov-####@va.gov` email is required for all new CLAB accounts
- [ControlTower Payer3 Accounts Deployment.docx](https://dvagov.sharepoint.com/sites/OITECSOApplication/Environments/AWS/ContorlTower%20Payer3%20Accounts%20Deployment.docx?d=waf9d9ab0e86c4ab7b3f17950cec77821)
