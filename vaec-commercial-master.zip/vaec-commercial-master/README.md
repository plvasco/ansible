# VA AWS Commercial

The management, provisioning, IAM permissions and roles in VA AWS Commercial is different from GovCloud:
- AWS Commercial Organizations is independent of AWS GovCloud Organizations.
- AWS GovCloud has fewer capabilites than available in Commercial.
- VA AWS Commercial accounts mainly serve as GovCloud billing accounts. With a few exceptions, most accounts don't have resources and are not accessed.
- Commercial accounts under _VA Enterprise Payer_ (_vaec-payer1_) have a different purpose, requirements, use-case, usage pattern from GovCloud or CLAB AWS accounts.
- Incorporate improvements and lessons learned from GovCloud automation
- AWS Commercial is not connected to VA network (as of March 2021)
- SSO may not be enabled for all AWS Commercial accounts


## Key accounts and regions

|                                | Commercial                         | GovCloud |
---                              | ---                                | ---
Primary Region                   | Ohio us-east-2                     | us-gov-west-1
Primary Automation Account       | _ecsb-high-support_ (878022744496) | _core-gov-internal_ (348286891446)
Organizations Management Account | _vaec-payer1_ (423386782741)       | _core-gov-internal_ (348286891446)
Organizations ID                 | o-a70eigc0bw                       | o-fgsg4ev0lb


Note:
- All [global](/global) and [regional](/regional) capabilities are first deployed to Primary Region.


## AWS Commercial Organizations structure

| OU        | ID               | Description
---         | ---              | ---
Root        | r-65jz           | Organizations root
c-readonly  | ou-65jz-2ef7q2b6 | Readonly accounts - most GovCloud commercial accounts
c-us        | ou-65jz-g0foyzyy | Active US accounts - such as Turbot, CARE2, ecsb-high-support
c-suspended | ou-65jz-1bhum0e6 | Placeholder for accounts that are inactive, closed, suspended pending termination


### Service Control Policies
The following AWS Organizations OU-specific policies are deployed in VA AWS Commercial:
| SCP | OU deployed to | Description
 --- | --- | ---
[EFS Encryption](global/SCP_EFS_encryption.json) | c-readonly, c-us | Deny non-encrypted filesystem
[Lock Down Regions](global/SCP_Lock_Down_Regions.json) | c-readonly, c-us | Deny non-US regions


### IAM Roles
IAM Roles and Policies are deployed using CloudFormation StackSets:

| StackSet | OU deployed to | Description 
 --- | --- | ---
[iam-adfs-c-project-readonly](global/iam-adfs-c-project-readonly.yml) | c-us, c-readonly | Readonly access
[iam-adfs-c-vaec-billing](global/iam-adfs-c-vaec-billing.yml)         | c-us, c-readonly | Billing read access
[iam-c-vaec-authorizer](global/iam-c-vaec-authorizer.yml)             | c-us, c-readonly | VAEC automation authorizer role
[iam-adfs-c-vaec-admin](global/iam-adfs-c-vaec-admin.yml)             | c-us             | VAEC limited administrator access
[iam-c-project-admin](global/iam-c-project-admin.yml)       | c-us             | Project Admin and Readonly roles
[iam-c-vaec-turbot](global/iam-c-vaec-turbot.yml)                     | c-us, c-readonly | Turbot service role


> StackSets does not deploy stack instances to the organization's management account, even if the management account is in your organization or in an OU in your organization.

- CloudFormation stacks managed separately in _vaec-payer1_ account are listed [here](global/core-mp1).

- Where required and approved by ECSO, access to billing requires user to be added to account specific _AWSC-{Account:ID}-adfs-c-vaec-billing_ AD Security Group, _*-admin_ and _*-readonly_ roles deny billing access.
- Since June 2021, VA has generally discontinued granting access to Cost Explorer and billing in AWS commercial, replaced by [Apptio](https://va-ecso.apptio.com/)

## Process accounts in Commercial Organizations
Commercial accounts which are paired with existing GovCloud Accounts are processed using scripts in the [vaec-organizations](https://github.ec.va.gov/AWS/vaec-organizations#process-accounts-in-commercial-organizations) repository

## Enabling VA SSO
Unlike GovCloud, SSO is not enabled for all AWS Commercial accounts by default since most are not accessed. For the ones that do need access, the steps to enable VA SSO are:

1. In _vaec-payer1_, move the Commercial account to appropriate OU: `c-readonly` or `c-us`. This will automatically deploy the permissions StackSets.
2. The _CommercialStatus_ in the appropriate row in [vaec-aws-accounts.csv](https://github.ec.va.gov/AWS/vaec-organizations/blob/master/vaec-aws-accounts.csv) must reflect the correct OU.
   -  _vaec-payer1_ has _CommercialStatus_ = _c-readonly_ to allow VA SSO to be configured. This account is Organizations management account, and technically not part of any Organizations OU.
3. Create IDP in the target Commercial account using the same [script](https://github.ec.va.gov/AWS/vaec-landingzone/blob/master/scripts/vaec_iam_idp_adfs.py) used for GovCloud.
4. Create OU and/or Security Groups in VA AD. Reference [Manage OUs and Groups in VA AD for AWS](https://github.ec.va.gov/AWS/vaec-aws-adfs-sso/tree/master/va-ent-ad) for configuration of VA SSO for GovCloud and Commercial accounts.

## Managing AWS Accounts Alternate Contacts
https://docs.aws.amazon.com/accounts/latest/reference/using-orgs.html

Execute the following in _vaec-payer1_ (one-time):
1. Enable trusted access with AWS Organizations for AWS Account Management:
~~~
aws organizations enable-aws-service-access --service-principal account.amazonaws.com
~~~

2. Register _ecsb-high-support_ as a delegated admin account for the Account Management service:
~~~
aws organizations register-delegated-administrator --account-id 878022744496 --service-principal account.amazonaws.com
~~~

This capability is required following script [vaec-organizations/update-commercial-alt-contact.py](https://github.ec.va.gov/AWS/vaec-organizations/blob/master/update-commercial-alt-contact.py)

## AWS Commercial Labs (CLABS)
- **VA AWS Commercial Labs (_CLAB_) are managed separately under Payer3 and not part of this configuration.**
- Reference [VA AWS Commercial Labs](payer3-clab/)


## Reference

- [AWS Organizations in GovCloud](https://aws.amazon.com/blogs/security/aws-organizations-available-govcloud-regions-central-governance-management-accounts/)


