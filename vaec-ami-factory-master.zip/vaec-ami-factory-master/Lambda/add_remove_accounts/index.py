import boto3
import json
import os
import time
from botocore.exceptions import ClientError

EC2_CLIENT = boto3.client('ec2')
DYNAMODB = boto3.resource('dynamodb')
ACCOUNT_LIST_TABLE = os.environ['account_list_table']


def lambda_handler(event, context):
    print(json.dumps(event))
    account_list = get_account_list(DYNAMODB, ACCOUNT_LIST_TABLE)
    print(account_list)
    if event['type'] == 'add':
        accounts_to_add = event['accounts']
        for new_account in accounts_to_add:
            if new_account not in account_list:
                account_list.append(new_account)
    elif event['type'] == 'remove':
        accounts_to_remove = event['accounts']
        for depreciated_account in accounts_to_remove:
            if depreciated_account in account_list:
                account_list.remove(depreciated_account)
        delete_accounts_from_list(DYNAMODB, ACCOUNT_LIST_TABLE)
        time.sleep(5)
    update_account_list(DYNAMODB, ACCOUNT_LIST_TABLE, account_list)


def get_account_list(dynamodb, account_table_name):
    account_table = dynamodb.Table(account_table_name)
    account_list = []
    try:
        response = account_table.get_item(
            TableName=account_table_name,
            Key={
                'Accounts': 'RHEL_Internal'
            }
        )
        account_list = response['Item']['AccountIds']
        print(response)
    except (ClientError, KeyError) as err:
        print(err)
    return account_list


def update_account_list(dynamodb, account_table_name, account_list):
    account_table = dynamodb.Table(account_table_name)
    try:
        account_table.update_item(
            Key={
                'Accounts': 'RHEL_Internal'
            },
            UpdateExpression="SET AccountIds = :accts",
            ExpressionAttributeValues={':accts': account_list},
            ReturnValues="UPDATED_NEW"
        )
    except ClientError as err:
        print(err)


def delete_accounts_from_list(dynamodb, account_table_name):
    account_table = dynamodb.Table(account_table_name)
    try:
        account_table.update_item(
            Key={
                'Accounts': 'RHEL_Internal'
            },
            UpdateExpression="REMOVE AccountIds",
            ReturnValues="UPDATED_NEW"
        )
    except ClientError as err:
        print(err)
