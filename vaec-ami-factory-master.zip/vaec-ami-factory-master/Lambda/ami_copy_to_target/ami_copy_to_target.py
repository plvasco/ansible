import json
import boto3
import time
import sys
import os
from botocore.exceptions import ClientError

ec2_client = boto3.client('ec2')
sts_client = boto3.client('sts')
ssm_client = boto3.client('ssm')
kms_client = boto3.client('kms')
dynamodb_resource = boto3.resource('dynamodb')

account_list_table = os.environ['account_list_table']
client_kms_key_alias_list = os.environ['cross_account_kms_alias_list']
shared_kms_key_id = os.environ['shared_kms_key_id']

def lambda_handler(event, context):
	partition = context.invoked_function_arn.split(':')[1]
	source_region = context.invoked_function_arn.split(':')[3]
	execution_id = get_execution_id_from_event(event)
	ami_id = get_ami_id(execution_id)
	account_list = get_account_list(dynamodb_resource, account_list_table)
	create_grants_from_kms_key(kms_client, account_list, shared_kms_key_id)
	share_ami_cross_account(ec2_client, ami_id, account_list)
	snapshot_id = get_snapshot_to_share(ec2_client, ami_id)
	share_snapshot_cross_account(ec2_client, snapshot_id, account_list)
	new_ami_id = copy_ami_with_target_account_key(account_list, partition, client_kms_key_alias_list, ami_id, source_region, kms_client)
    
def get_execution_id_from_event(event):
	print('Event is %s: ' %(event))
	execution_id = event['detail']['ExecutionId']
	return execution_id

def get_ami_id(execution_id):
	print('ExecutionId is: %s' %(execution_id))
	response = ssm_client.describe_automation_executions(
		Filters=[
			{
				'Key': 'ExecutionId',
				'Values': [execution_id]
			}
		]
	)
	
	for automation_execution_metadata_list in response['AutomationExecutionMetadataList']:
	    ami_id = automation_execution_metadata_list['Outputs']['CreateImage.ImageId'][0]
	    return ami_id
	    
def get_account_list(dynamodb_resource, account_table_name):
    account_table = dynamodb_resource.Table(account_table_name)
    account_list = []
    try:
        response = account_table.get_item(
            TableName=account_table_name,
            Key={
                'Accounts': 'RHEL_Internal'
            }
        )
        account_list = response['Item']['AccountIds']
        print(account_list)
    except ClientError as err:
        print(err)
    return account_list

def share_ami_cross_account(ec2_client, ami_id, account_list):
    try:
        for account in account_list:
            response = ec2_client.modify_image_attribute(
                Attribute='createVolumePermission',
                LaunchPermission={
                	'Add' : [
    	            	{
    	            		'UserId': account
    	            	}
                	]
                },
                OperationType='add',
                ImageId = ami_id,
                UserIds=[account]
            )
            print('%s has been shared successfully to account %s.' % (ami_id, account))
        return True
    except ClientError as err:
        print(err)
        
def get_snapshot_to_share(ec2_client, ami_id):
    try:
        response = ec2_client.describe_images(
            ImageIds = [ami_id]
        )

        snapshot_id = response['Images'][0]['BlockDeviceMappings'][0]['Ebs']['SnapshotId']
        for images in response['Images']:
            for block_device_mappings in images['BlockDeviceMappings']:
                snapshot_id = block_device_mappings['Ebs']['SnapshotId']
        print("Snapshot to be shared is %s." %snapshot_id)
        return snapshot_id

    except ClientError as err:
        print(err)
        
def share_snapshot_cross_account(ec2_client, snapshot_id, account_list):
    try:
        response = ec2_client.modify_snapshot_attribute(
            Attribute='createVolumePermission',
            OperationType='add',
            SnapshotId = snapshot_id,
            UserIds = account_list
        )
        print('%s has been shared successfully to accounts %s.' %(snapshot_id, account_list))
        return True
    except ClientError as err:
        print(err)

def assume_role_in_target_account(account_number, partition, role_name):
    assume_role_arn = 'arn:' + partition + ':iam::' + \
        account_number + ':role/' + role_name

    try:
        sts_response = sts_client.assume_role(
            RoleArn = assume_role_arn,
            RoleSessionName = 'RoleAssumedFromSourceAmiAccount'
        )
        
        session = boto3.Session(
            aws_access_key_id=sts_response['Credentials']['AccessKeyId'],
            aws_secret_access_key=sts_response['Credentials']['SecretAccessKey'],
            aws_session_token=sts_response['Credentials']['SessionToken']
        )
        
        return session

    except ClientError as err:
        print(err)

def create_grants_from_kms_key(kms_client, account_list, shared_kms_key_id):
    try:
        for account in account_list:
            grant_response =  kms_client.create_grant(
            KeyId = shared_kms_key_id,
            GranteePrincipal = account,
            Operations = ['Decrypt', 'Encrypt', 'GenerateDataKey', 'GenerateDataKeyWithoutPlaintext', 'ReEncryptFrom', 'ReEncryptTo', 'CreateGrant', 'RetireGrant', 'DescribeKey']
       )

    except ClientError as err:
        print(err)
        
def copy_ami_with_target_account_key(account_list, partition, client_kms_key_alias_list, ami_id, source_region, kms_client):
    try:
        for account in account_list:
            session = assume_role_in_target_account(account, partition, 'vaec-SnapshotCopyRole')
            ec2_target_client = session.client('ec2',region_name = source_region)
            ec2_target_resource = session.resource('ec2',region_name = source_region)
            
            if client_kms_key_alias_list != 'None':
                split_alias_list = client_kms_key_alias_list.split(',')
                for split_alias in split_alias_list:
                    stripped_alias = split_alias.strip()
                    alias = 'arn:' + partition + ':kms:' + source_region + \
                        ':' + account + ':alias/' + stripped_alias
                    response = check_alias_exists(kms_client, alias)
                    if (response != None):
                        alias_name = response
                        print("Using %s to encrypt the AMI." %(alias_name))
                        break
                    else:
                        continue    
                        
                        
                copy_response = ec2_target_client.copy_image(
                    Encrypted=True,
                    KmsKeyId=alias_name,
                    Name = "copied-ami from " + ami_id,
                    SourceImageId = ami_id,
                    SourceRegion = source_region
                )
            else:
                copy_response = ec2_target_client.copy_image(
                    Encrypted=True,
                    Name = "copied-ami from " + ami_id,
                    SourceImageId = ami_id,
                    SourceRegion = source_region
                )
            
            image_id = copy_response['ImageId']
            #wait_for_available_image(ec2_target_client, image_id)
            
        print("AMI created is: " + image_id)
        return image_id

    except ClientError as err:
        print(err)
        
def check_alias_exists(kms_client, alias):
    try:
        response = kms_client.describe_key(KeyId = alias)
        return alias
    except:
        print('Alias %s did not exist.' %(alias))
        return None
        
def wait_for_available_image(ec2_target_client, image_id):
    while True:
        try:
            response = ec2_target_client.describe_images(
                ImageIds = [image_id]
            )
            
            state = response['Images'][0]['State']
            print("Waiting for AMI %s to be available... (state: %s)" % (image_id,state))
        except ClientError as err:
            print(err)

        time.sleep(10)
        if state == 'available':
            break