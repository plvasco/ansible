import boto3
import os
from botocore.exceptions import ClientError

ssm_client = boto3.client('ssm')
ec2_client = boto3.client('ec2')

iam_instance_profile_name = os.environ['iam_instance_profile_name']
automation_assume_role = os.environ['automation_assume_role']
document_name = os.environ['document_name']
subnet_id = os.environ['subnet_id']
security_group_id = os.environ['security_group_id']

def lambda_handler(event, context):
    ami_with_key_dict = get_ami_list_to_share(ec2_client)
    if ami_with_key_dict:
        print('Ami list to be shared is: %s' %(ami_with_key_dict))
        sysprepped_ami_id = run_ssm_document(ssm_client, ami_with_key_dict, document_name, iam_instance_profile_name, automation_assume_role, subnet_id)
        update_ami_tag(ec2_client,ami_with_key_dict)
    else:
        print('There are no AMIs to share at this time.')
    

def get_ami_list_to_share(ec2_client):
    ami_id = ""
    ami_list = []
    ami_with_key = {}
    try:
        tag_response = ec2_client.describe_tags(
            Filters=[
                {
                    'Name': 'resource-type',
                    'Values': ['image']
                }
            ]
        )
        
        if tag_response['Tags']:
            for tags in tag_response['Tags']:
                if (tags['Key'].upper() == 'APPROVAL_STATUS' and tags['Value'].upper() == 'WINDOWS_APPROVED'):  
                    ami_id = tags['ResourceId']
                    key_to_update = tags['Key']
                    ami_with_key = {ami_id : key_to_update}
        else:
            ami_with_key = None

    except ClientError as err:
        print(err)
    return ami_with_key

def run_ssm_document(ssm_client, ami_with_key_dict, document_name, iam_instance_profile_name, automation_assume_role,subnet_id):
    try:
        response_list = []
        for ami_id in ami_with_key_dict:
            response = ssm_client.start_automation_execution(
                 DocumentName= document_name,
                 Parameters = {
                     'SourceAmiId' : [ami_id],
                     'IamInstanceProfileName' : [iam_instance_profile_name],
                     'AutomationAssumeRole': [automation_assume_role] ,
                     'SubnetId' : [subnet_id],
                     'SecurityGroupIds' : [security_group_id]
                 }
            )
            
            response_list.append(response)
            
        return response_list
        
    except ClientError as err:
        print(err)

def update_ami_tag(ec2_client, ami_with_key_dict):
    create_tags_response_list = []
    try:
        for key,value in ami_with_key_dict.items():
            response = ec2_client.create_tags(
                Resources = [
                    key
                ],
                Tags = [
                    {
                       'Key': value,
                       'Value': 'copied'
                    }
                ]
            )
            
            create_tags_response_list.append(response)
            
        return create_tags_response_list
        
    except ClientError as err:
        print(err)
    