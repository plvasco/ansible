import boto3
import json
import os
import datetime
from botocore.exceptions import ClientError

EC2_CLIENT = boto3.client('ec2')
DYNAMODB = boto3.resource('dynamodb')
ACCOUNT_LIST_TABLE = os.environ['account_list_table']
CLIENT_KMS_KEY_ALIAS_LIST = os.environ['cross_account_kms_alias_list']

# def lambda_handler_DELETE(event, context):
    # partition = context.invoked_function_arn.split(':')[1]
    # region = context.invoked_function_arn.split(':')[3]
    # snapshot = get_snapshot_to_share(EC2_CLIENT)
    # account_list = get_account_list(DYNAMODB, ACCOUNT_LIST_TABLE)
    # for account in account_list:
        # session = assume_role(account, partition, 'vaec-SnapshotCopyRole')
        # key_alias=get_client_key_alias(session, region, CLIENT_KMS_KEY_ALIAS_LIST)
        # print(key_alias)

def lambda_handler(event, context):
    partition = context.invoked_function_arn.split(':')[1]
    region = context.invoked_function_arn.split(':')[3]
    snapshot = get_snapshot_to_share(EC2_CLIENT)
    if snapshot:
        snapshot_info = get_snapshot_info(snapshot)
        if can_share_snapshot(snapshot_info):
            account_list = get_account_list(DYNAMODB, ACCOUNT_LIST_TABLE)
            add_snapshot_account_permissions(
                EC2_CLIENT, snapshot, account_list)
            copy_snapshots_to_accounts(
                account_list, snapshot, partition, region, snapshot_info, CLIENT_KMS_KEY_ALIAS_LIST)
            tag_snapshot_for_deletion(EC2_CLIENT, snapshot)
            tag_snapshot_as_copied(EC2_CLIENT, snapshot)
            return "Began copy of " + snapshot
    return "No snapshot to copy"


def get_snapshot_to_share(ec2_client):
    snapshot = ""
    try:
        tag_response = ec2_client.describe_tags(
            Filters=[
                {
                    'Name': 'tag:AmiFactoryShared',
                    'Values': [
                        'false'
                    ]
                },
                {
                    'Name': 'resource-type',
                    'Values': ['snapshot']
                },
            ]
        )
        if tag_response['Tags']:
            snapshot = tag_response['Tags'][0]['ResourceId']
    except ClientError as err:
        print(err)
    return snapshot


def get_snapshot_info(snapshot_id):
    snapshot_info = {}
    try:
        snapshot_info = EC2_CLIENT.describe_snapshots(
            SnapshotIds=[
                snapshot_id
            ]
        )
    except ClientError as err:
        print(err)
    return snapshot_info


def can_share_snapshot(snapshot_info):
    tag_approved = False
    snapshot_completed = False
    for snapshot in snapshot_info['Snapshots']:
        if snapshot['State'] == 'completed':
            snapshot_completed = True
        for tag in snapshot['Tags']:
            if tag['Key'] == 'ApprovalStatus' and tag['Value'] == 'RHEL_Approved':
                tag_approved = True
    if tag_approved and snapshot_completed:
        return True
    return False


def get_account_list(dynamodb, account_table_name):
    account_table = dynamodb.Table(account_table_name)
    account_list = []
    try:
        response = account_table.get_item(
            TableName=account_table_name,
            Key={
                'Accounts': 'RHEL_Internal'
            }
        )
        account_list = response['Item']['AccountIds']
        print(response)
    except ClientError as err:
        print(err)
    return account_list


def add_snapshot_account_permissions(ec2_client, snapshot_id, account_list):
    try:
        response = ec2_client.modify_snapshot_attribute(
            Attribute='createVolumePermission',
            OperationType='add',
            SnapshotId=snapshot_id,
            UserIds=account_list
        )
        print(response)
        return True
    except ClientError as err:
        print(err)
        return False

def get_client_key_alias(session, region, key_alias_list):
    if key_alias_list == 'None':
        return 'None'
    ec2_client = session.client('kms', region_name=region)
    response = ec2_client.list_aliases()
    for ka in key_alias_list.split(','):
        for response_alias in response['Aliases']:
            if response_alias['AliasName'] == 'alias/' + ka.strip():
                return ka
    return 'None'

def copy_snapshots_to_accounts(account_list, snapshot_id, partition, region, snapshot_info, key_alias_list):
    snapshot_copy_results = []
    try:
        for account in account_list:
            session = assume_role(account, partition, 'vaec-SnapshotCopyRole')
            ec2_client = session.client('ec2', region_name=region)
            key_alias=get_client_key_alias(session, region, key_alias_list)
            new_snapshot = copy_snapshot(
                ec2_client, snapshot_id, partition, region, key_alias, account)
            snapshot_copy_results.append({
                'Account': account,
                'SnapshotId': new_snapshot
            })
            tag_snapshot(ec2_client, snapshot_info, new_snapshot)
            print(snapshot_copy_results)
    except ClientError as err:
        print(err)
    return snapshot_copy_results


def assume_role(account_number, partition, role_name):
    assume_role_arn = 'arn:' + partition + ':iam::' + \
        account_number + ':role/' + role_name
    try:
        sts_client = boto3.client('sts')
        sts_response = sts_client.assume_role(
            RoleArn=assume_role_arn,
            RoleSessionName='ami_factory'
        )
        session = boto3.Session(
            aws_access_key_id=sts_response['Credentials']['AccessKeyId'],
            aws_secret_access_key=sts_response['Credentials']['SecretAccessKey'],
            aws_session_token=sts_response['Credentials']['SessionToken']
        )
        return session
    except ClientError as err:
        print(err)
        return False


def copy_snapshot(ec2_client, snapshot_id, partition, region, key_alias, account):
    try:
        if key_alias != 'None':
            alias = 'arn:' + partition + ':kms:' + region + \
                ':' + account + ':alias/' + key_alias
            copy_response = ec2_client.copy_snapshot(
                Encrypted=True,
                KmsKeyId=alias,
                SourceSnapshotId=snapshot_id,
                SourceRegion=region
            )
        else:
            copy_response = ec2_client.copy_snapshot(
                Encrypted=True,
                SourceSnapshotId=snapshot_id,
                SourceRegion=region
            )
        print('Copy_Status:')
        print(copy_response)
        return copy_response['SnapshotId']
    except ClientError as err:
        print(err)
        return False


def tag_snapshot(ec2_client, snapshot_info, snapshot_id):
    snap_tags = snapshot_info['Snapshots'][0]['Tags']
    try:
        ec2_client.create_tags(
            Resources=[
                snapshot_id
            ],
            Tags=snap_tags
        )
        print('Snapshot tagged: True')
        return True
    except ClientError as err:
        print(err)
        return False

def tag_snapshot_for_deletion(ec2_client, snapshot_id):
    try:
        today = datetime.date.today()
        delete_date = today + datetime.timedelta(days=7)
        delete_date = str(delete_date)
        today = str(today)
        today = datetime.datetime.strptime(today, "%Y-%m-%d").strftime("%Y%m%d")
        format_date = datetime.datetime.strptime(delete_date, "%Y-%m-%d").strftime("%Y%m%d")
        ec2_client.create_tags(
            Resources=[
                snapshot_id
            ],
            Tags=[
                {
                    'Key': 'DeleteAfter',
                    'Value': format_date
                },
                {
                    'Key': 'CreatedOn',
                    'Value': today
                },
                {
                    'Key': 'CreatedBy',
                    'Value': 'vaec-ami-factory'
                }   
            ]
        )
        print('Delete After tag added')
        return True
    except ClientError as err:
        print(err)
        return False


def tag_snapshot_as_copied(ec2_client, snapshot_id):
    try:
        ec2_client.create_tags(
            Resources=[
                snapshot_id
            ],
            Tags=[
                {
                    'Key': 'AmiFactoryShared',
                    'Value': 'true'
                }
            ]
        )
        print('Snapshot tagged: True')
        return True
    except ClientError as err:
        print(err)
        return False
