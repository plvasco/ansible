import boto3
import json
import os
from botocore.exceptions import ClientError

CUSTOM_KMS_KEY_ID = os.environ['shared_kms_key']
EC2_CLIENT = boto3.client('ec2')


def lambda_handler(event, context):
    is_tag_approved = is_tag_set_to_approved(event)
    ami_id = get_ami_id_from_event(event)
    if is_tag_approved and ami_id:
        snapshot = get_snapshot_info_from_ami(EC2_CLIENT, ami_id)
        if snapshot:
            snapshot['SnapshotId'] = encrypt_snapshot(
                EC2_CLIENT, snapshot['SnapshotId'], CUSTOM_KMS_KEY_ID, context)
            snapshot['Encrypted'] = True
            snapshot['KmsKeyId'] = CUSTOM_KMS_KEY_ID
            tag_snapshot(EC2_CLIENT, snapshot)
            return "Completed"
    print(json.dumps(event))
    return "There was a problem. Please review cloudwatch logs"


def get_ami_id_from_event(event):
    ami_id = ""
    try:
        for item in event['detail']['requestParameters']['resourcesSet']['items']:
            if item['resourceId'].startswith('ami'):
                ami_id = item['resourceId']
    except Exception as err:
        print(err)
    return ami_id


def is_tag_set_to_approved(event):
    is_approved = False

    try:
        for item in event['detail']['requestParameters']['tagSet']['items']:
            if item['key'].upper() == 'APPROVAL_STATUS' and item['value'].upper() == 'RHEL_APPROVED':
                is_approved = True
    except Exception as err:
        print(err)
    print('Tags Approved: ' + str(is_approved))
    return is_approved


def get_snapshot_info_from_ami(ec2_client, ami_id):
    snapshot_info = {}
    try:
        images_response = ec2_client.describe_images(
            ImageIds=[ami_id]
        )
        for image in images_response['Images']:
            for mapping in image['BlockDeviceMappings']:
                snapshot_info['SnapshotId'] = mapping['Ebs']['SnapshotId']
                snapshot_info['Encrypted'] = mapping['Ebs']['Encrypted']
                snapshot_info['DeviceName'] = mapping['DeviceName']
                snapshot_info['ImageId'] = image['ImageId']
                snapshot_info['Name'] = image['Name']
                snapshot_info['Architecture'] = image['Architecture']
                snapshot_info['VirtualizationType'] = image['VirtualizationType']
                if mapping['Ebs']['Encrypted'] and 'KmsKeyId' in mapping['Ebs']:
                    snapshot_info['KmsKeyId'] = mapping['Ebs']['KmsKeyId']
    except ClientError as err:
        print(err)
    print('snapshot_info:')
    print(snapshot_info)
    return snapshot_info


def encrypt_snapshot(ec2_client, snapshot_id, kms_key_id, context):
    try:
        copy_response = ec2_client.copy_snapshot(
            Encrypted=True,
            KmsKeyId=kms_key_id,
            SourceSnapshotId=snapshot_id,
            SourceRegion=context.invoked_function_arn.split(':')[3]
        )
        print('Encryption_Status:')
        print(copy_response)
        return copy_response['SnapshotId']
    except ClientError as err:
        print(err)
        return False


def tag_snapshot(ec2_client, snapshot_info):
    try:
        ec2_client.create_tags(
            Resources=[
                snapshot_info['SnapshotId']
            ],
            Tags=[
                {
                    'Key': 'ImageId',
                    'Value': snapshot_info['ImageId']
                },
                {
                    'Key': 'DeviceName',
                    'Value': snapshot_info['DeviceName']
                },
                {
                    'Key': 'ApprovalStatus',
                    'Value': 'RHEL_Approved'
                },
                {
                    'Key': 'AmiName',
                    'Value': snapshot_info['Name']
                },
                {
                    'Key': 'Architecture',
                    'Value': snapshot_info['Architecture']
                },
                {
                    'Key': 'VirtualizationType',
                    'Value': snapshot_info['VirtualizationType']
                },
                {
                    'Key': 'AmiFactoryShared',
                    'Value': 'false'
                }
            ]
        )
        print('Snapshot tagged: True')
        return True
    except ClientError as err:
        print(err)
        return False
