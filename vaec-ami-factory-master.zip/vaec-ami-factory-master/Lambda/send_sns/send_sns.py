import json
import boto3
import os
from botocore.exceptions import ClientError


sns_client = boto3.client('sns')
topic_arn = os.environ['sns_topic']


def lambda_handler(event, context):
    send_event_to_topic(sns_client, event)
    
def send_event_to_topic(sns_client,event):
    message = json.dumps(event)
    
    try:
        send_sns_response = sns_client.publish(
            TopicArn = topic_arn,
            Message = message
        )
    except ClientError as err:
        print(err)
    