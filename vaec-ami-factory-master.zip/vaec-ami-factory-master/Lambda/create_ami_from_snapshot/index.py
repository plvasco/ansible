import boto3
import json
import os
from datetime import datetime
from botocore.exceptions import ClientError

EC2_CLIENT = boto3.client('ec2')
SNS_TOPIC_ARN = os.environ['sns_topic_arn']


def lambda_handler(event, context):
    snapshot_id = get_snapshot_to_share(EC2_CLIENT)
    if snapshot_id:
        snapshot_info = get_snapshot_info(snapshot_id)
        if snapshot_info:
            create_ami = can_create_ami(snapshot_info)
        if create_ami:
            ami_info = create_ami_from_snapshot(
                EC2_CLIENT, snapshot_id, snapshot_info)
            tag_snapshot_as_copied(EC2_CLIENT, snapshot_id)
            if SNS_TOPIC_ARN != 'None':
                message = "A New AMI has been published by VAEC.\n\n"
                message += "Name: " + ami_info['Name'] + '\n'
                message += "Architecture: " + ami_info['Architecture'] + '\n'
                message += "Virtualization Type: " + \
                    ami_info['VirtualizationType'] + '\n'
                message += "Volume Size: " + ami_info['VolumeSize'] + '\n'
                subject = "New AMI available"
                send_notification(SNS_TOPIC_ARN, message, subject, context)
            return "Created AMI " + ami_info['Name']
    return "No AMI Created"


def get_snapshot_to_share(ec2_client):
    snapshot = ""
    try:
        tag_response = ec2_client.describe_tags(
            Filters=[
                {
                    'Name': 'tag:AmiFactoryShared',
                    'Values': [
                        'false'
                    ]
                },
                {
                    'Name': 'resource-type',
                    'Values': ['snapshot']
                },
            ]
        )
        if tag_response['Tags']:
            snapshot = tag_response['Tags'][0]['ResourceId']
    except ClientError as err:
        print(err)
    return snapshot


def get_snapshot_info(snapshot_id):
    snapshot_info = {}
    try:
        snapshot_info = EC2_CLIENT.describe_snapshots(
            SnapshotIds=[
                snapshot_id
            ]
        )
    except ClientError as err:
        print(err)
    return snapshot_info


def can_create_ami(snapshot_info):
    tag_approved = False
    snapshot_completed = False
    for snapshot in snapshot_info['Snapshots']:
        if snapshot['State'] == 'completed':
            snapshot_completed = True
        for tag in snapshot['Tags']:
            if tag['Key'] == 'ApprovalStatus' and tag['Value'] == 'RHEL_Approved':
                tag_approved = True
    if tag_approved and snapshot_completed:
        return True
    return False


def create_ami_from_snapshot(ec2_client, snapshot_id, snapshot_info):
    image_info = {}
    root_device = "/dev/sda1"
    arch = 'x86_64'
    virt_type = 'hvm'
    ts = datetime.now().strftime('%Y%m%d%H%M%S')
    ami_name = 'vaec' + str(ts)
    volume_size = snapshot_info['Snapshots'][0]['VolumeSize']
    for tag in snapshot_info['Snapshots'][0]['Tags']:
        if tag['Key'] == 'DeviceName':
            root_device = tag['Value']
        if tag['Key'] == 'AmiName':
            ami_name = tag['Value'] + str(ts)
        if tag['Key'] == 'VirtualizationType':
            virt_type = tag['Value']
        if tag['Key'] == 'Architecture':
            arch = tag['Value']

    try:
        ami_register = ec2_client.register_image(
            Name=ami_name,
            Architecture=arch,
            RootDeviceName=root_device,
            BlockDeviceMappings=[
                {
                    "DeviceName": root_device,
                    "Ebs": {
                        "SnapshotId": snapshot_id,
                        "VolumeSize": volume_size,
                        "DeleteOnTermination": True,
                        "VolumeType": "gp2"
                    }
                }
            ],
            VirtualizationType=virt_type
        )

        image_id = ami_register['ImageId']
        image_info['ImageId'] = image_id
        image_info['Name'] = ami_name
        image_info['Architecture'] = arch
        image_info['VirtualizationType'] = virt_type
        image_info['VolumeSize'] = str(volume_size)
        tag_ami(ec2_client, snapshot_info, image_id)
        return image_info
    except ClientError as err:
        print(err)
        return False


def tag_ami(ec2_client, snapshot_info, image_id):
    snap_tags = snapshot_info['Snapshots'][0]['Tags']
    try:
        ec2_client.create_tags(
            Resources=[
                image_id
            ],
            Tags=snap_tags
        )
        print('Snapshot tagged: True')
        return True
    except ClientError as err:
        print(err)
        return False


def send_notification(outbound_topic_arn, message, subject, context):
    """
    Send Violation.

    Appends additional information to the message from the Lambda Context
    Sends the message created using an API call to Amazon SNS.
    """
    find_sns_region = outbound_topic_arn.split(":")
    sns_region = find_sns_region[3]
    message += "\n\n"
    message += "This notification was generated by the Lambda function " + \
        context.invoked_function_arn
    sendclient = boto3.client('sns', region_name=sns_region)
    try:
        sendclient.publish(
            TopicArn=outbound_topic_arn,
            Message=message,
            Subject=subject
        )
    except ClientError as err:
        print(err)
        return False


def tag_snapshot_as_copied(ec2_client, snapshot_id):
    try:
        ec2_client.create_tags(
            Resources=[
                snapshot_id
            ],
            Tags=[
                {
                    'Key': 'AmiFactoryShared',
                    'Value': 'true'
                }
            ]
        )
        print('Snapshot tagged: True')
        return True
    except ClientError as err:
        print(err)
        return False
