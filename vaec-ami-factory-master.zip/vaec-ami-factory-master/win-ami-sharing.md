# VAEC Windows AMI Sharing

## Summary
VAEC currently has a solution for sharing Linux AMIs without a billing code.  This solution takes an encrypted AMI generated on-premises by ITOPS (IT Operations), and shares it from the “central” account to all specified accounts.  The final state is a copy of the AMI, encrypted, that resides in the specified account.  Now the VAEC needs a similar solution for Windows marketplace AMIs, specifically Windows 2012 and 2016.

## AMI Sharing Process
The primarily difference from the existing solution is that Windows marketplace AMI sharing will require handling of billing codes.  Currently AMIs with billing codes cannot be copied cross-account.  To address this, this solution will need to execute the following operations in order to create a private copy of the AMI in the specified account:

## AMI Creation (currently customer responsibility)
1.	Customer creates an encrypted Windows AMI in central account, customized with needed agents, etc.

## AMI Sharing with specified accounts - technical steps
1.	Make note of the original marketplace AMI that was used to create the custom AMI in the central account
2.	central account CMK is shared with target account
3.	encrypted snapshot(s) are shared with target account
4.	Steps from hereon are in target account.  In the target account, launch the original marketplace AMI
5.	Stop the newly launched EC2.
6.	If possible, used the shared encrypted snapshot to create a local encrypted EBS volume with the VAEC-AMI CMK.
  - Otherwise, copy the shared encrypted snapshot to a local snapshot encrypted with the VAEC-AMI key, and create an encrypted volume from that
7.	Swap the root volume with the local volume
8.	Launch the EC2
9.	Sysprep the Windows EC2
10.	Shutdown EC2
11.	Create final encrypted AMI with provided key in target account

## AMI sharing, business requirements
1.	The Windows AMI sharing solution user experience should mimic the existing Linux solution as much as possible
2.	Will discuss with COMS if re-using the existing DDB table makes sense, or if an entirely new one should be created

## Future Considerations, Enhancements
- Integration of sharing solution with AMI creation.  AMI creation tools have not been decided yet. SSM?  Packer with Ansible?
- AMI lifecycle.  When do we perform deletion?  Yet to be discussed.
