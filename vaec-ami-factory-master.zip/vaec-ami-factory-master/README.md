# AMI Factory

## WorkFlow

The AMI factory workflow begins by tagging an AMI with the following key/value pair _{"Approval_Status": "Approved"}_. To carry along the tags: _Name_, _Environment_, _ProjectShort_, _ProjectName_ and _VAECID_, add the tags to the AMI with the correct values. 

Once the AMI is tagged, a CloudWatch CreateTags event triggers a Lambda function that checks to ensure that the tags are approved, and that an AMI is tagged. After the check, the AMI snapshot is copied and encrypted using the kms key that is shared cross account. The snapshot id then tagged with the AMI metadata that will be used to recreate the AMI in the child accounts. 

Once the Copy Snapshot api call is completed a CloudWatch event monitoring successful snapshot copies triggers a Lambda to begin the process of copying the snapshots to all child accounts. The Lambda function reviews the tags of the snapshot and if it was tagged correctly, will grab a list of all accounts that will receive the copy of the snapshots from the dynamodb table. Then it modifies the snapshot attributes to allow all accounts from the list the ability to copy the snapshot. Once completed, this function will assume a role for every account in the list and copy the snapshot to that account with the KMS key specified as a CloudFormation parameter.

Once the snapshot copy is completed on the child account, a CloudWatch event trigger a Lambda function to create an AMI from the snapshot. This AMI is generated using the tagging data from the snapshot, and is named the same as the original AMI with a timestamp at the end. This is to ensure that an AMI in the master account can copy the same AMI over multiple times.

The workflow also contains a Lambda function that is launched in the master account with the ability to add or removed account ids from the account id table. The sample event to accomplish this is included with the deployment package.


## Deployment

### Master/parent account

To deploy the AMI factory in the master account, all zipped lambda functions except _CreateAMI.zip_ must be placed in a bucket within a folder labelled lambda. Once completed, launch the _ami_factory_parent.yaml_ template in the CloudFormation console. The parameters are as follows:

Note: Also add the account ID of the child account as one of the external accounts allowed to use the sharedKMS Key in IAM -> Encrytion Keys

The CrossAccountKMS Alias must exist in the child account.
~~~
pAmiRegistryReadCapacityUnits:
    Type: Number
    Default: 5
    Description: Sets the desired minimum number of consistent reads of items (up to 1KB in size) per second for the specified table before Amazon DynamoDB balances the load.
  pAmiRegistryWriteCapacityUnits:
    Type: Number
    Default: 5
    Description: Sets the desired minimum number of consistent writes of items (up to 1KB in size) per second for the specified table before Amazon DynamoDB balances the load.
  pS3BucketName:
    Type: String
    AllowedPattern : ".+"
    Description: Amazon S3 Bucket Name which contains the lambda folder with .zip file
  pSharedKMSKeyId:
    Type: String
    Description: The KMS Key ID that will be used to encrypt the snapshots for sharing
  pCrossAccountKMSAliasName:
    Type: String
    Description: The alias name of the KMS key created in Accounts to share the AMI. If set to None, it will use the default KMS key. 
    Default: None
~~~

### Child account

To deploy the AMI factory in the child account, The zipped lambda function _CreateAMI.zip_ must be placed in a bucket within a folder labelled lambda. Once completed, launch the _ami_factory_child.yaml_ template in the CloudFormation console. The parameters are as follows:
~~~
  pParentAccountId:
    Type: String
    Description: The account number where the Snapshot will be copied from
    Default: 111111111111
  pS3BucketName:
    Type: String
    Description: The name of the Bucket containing the CreateAmi Lambda information
  pSnsTopicArn:
    Type: String
    Description: The SNS Topic arn to send completion notifications for Account owners. If the value is set to None, no notifications will be sent
    Default: None
~~~

The _ami_factory_child.yaml_ template should be deployed in every account that the AMIs will be copied to. 

Once the deployments are completed, the add-remove-accounts lambda function can be initialized to add the account numbers to the dynamodb table. This step must be completed in order to share the AMIs to the child accounts. There are two sample events included to demonstrate adding and removing accounts from the table.

### Initiate sharing

#### Windows AMI Sharing

Four (4) components affect the initation of sharing an AMI from core-gov-internal to another AWS Account:
* DynamoDB Table: vaec-ami-factory-parent-rAccountListTable-1SAB8B7MTZMNK
* Lambda Function: vaec-ami-factory-parent-run-ssm
* Lambda Function: vaec-ami-factory-parent-copy-windows-ami
* Cloudwatch Events Rule: vaec-ami-factory-parent-rCheckForAmiTagCloudWatchE-L0BL681K5319

1. Open the DynamoDB Dashboard and find Table listed above. Edit the only item in the table. Update **AccountIds List** with the 12 digit AWS Account ID(s).
2. On your target AMI in core-gov-internal, add or update tag **Approval\_Status** with value **WINDOWS\_APPROVED**
3. Cloudwatch Events Rule listed above runs every 5 minutes and triggers vaec-ami-factory-parent-run-ssm to scan all AMIs for the Approval\_Status Tag. When an AMI is found a series of SSM tasks kick off to prepare the AMI to be shared to the target account.
4. When vaec-ami-factory-parent-run-ssm completes it triggers vaec-ami-factory-parent-copy-windows-ami to then copy prepped AMI to the target account.

Todo:

Provide populated Name Tag on the copied AMI.

#### Linux AMI Sharing

placeholder

Finally, to share an AMI, create an AMI tag and set the key to Approval_Status and set the value to Approved. This will kick off the AMI sharing process. 
