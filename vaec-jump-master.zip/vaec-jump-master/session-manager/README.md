# Using Session Manager for accessing EC2 Instances

AWS Session Manager (part of System Manager) provides the ability access the SSH terminal through the AWS Console. Instructions for using  for SSH to Linux or Powershell to Windows instances (shell only, no RDP/GUI) are included below.

 
## Preparation

- SSM agent provided by AWS needs to be installed on EC2 instance. This is pre-installed on most AWS and VAEC AMIs, but may be a problem with older AMIs

- Create EC2 Role for SSM if it doesn't exist. Create a CloudFormation stack using this template if needed:  https://github.ec.va.gov/AWS/vaec-project-iam/blob/master/examples/project-ssm-role-example.yml

- For each EC2 instance that you need access to, assign EC2-SSM role to instance:
   -  In the Amazon EC2 console, choose Instances from the navigation pane
   -  Select the instance that you want to attach the IAM role to, choose Actions, Instance Settings, and then choose Attach/Replace IAM role
   -  For IAM role, choose your IAM role, and then choose Apply


## Accessing the instance

1. Navigate to Services -> AWS System Manager -> Managed Instances to verify your instance is managed by AWS System Manager

2. Once verified navigate to AWS System Manager -> Session Manager -> Start Session -> Select your instance -> Start session

3. Another tab will be created with your SSH terminal

4. Once you have completed your SSH session, Navigate to Session Manager - Locate your session and terminate

## Reference
- https://aws.amazon.com/blogs/aws/new-session-manager/
- https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html
