$hostname = [System.Net.Dns]::GetHostByName($env:computerName).HostName
New-RDSessionDeployment -ConnectionBroker $hostname -WebAccessServer $hostname -SessionHost $hostname
Add-RDServer -Server $hostname -Role "RDS-GATEWAY" -ConnectionBroker $hostname -GatewayExternalFqdn $hostname
