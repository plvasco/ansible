$RunOnceKey = "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
Set-ItemProperty $RunOnceKey "NextRun" "C:\Windows\System32\WindowsPowerShell\v1.0\Powershell.exe -ExecutionPolicy Unrestricted -File C:\installrds.ps1"

Import-Module RemoteDesktop

Add-WindowsFeature –Name RDS-RD-Server –IncludeAllSubFeature -Restart

