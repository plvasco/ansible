# Windows bastion host in project-specific VPC

## Pre-requisite
- RDP to the project Windows bastion host in AWS VPC through Remote Desktop Gateway:
  - Each user requires an EPAS/e-token, and request their zero-ID be associated with _cldwinp_userprofiles_. [Complete ePAS Request for Systems Hosted in VAEC](https://kb.vaec.va.gov/display/VK/Complete+ePAS+Request+for+Systems+Hosted+in+VAEC).
- Start a Windows instance in your project VPC to become the designated bastion host.
  - `RD Gateway is not a Windows jump server`.


## Set up instructions

Steps to set up a multi-user, Windows bastion host in a project-specific VPC:

1. **Verify AMI:** Ensure that a VAEC-provisioned Windows 2016 AMI or Windows 2019 AMI is available in the AWS account.

2. **Create EC2 instance:** Select appropriate instance type based on number of users, installed applications.
 
3. **Set up multi-user RDP:** A multi-user RDP license is required otherwise Windows only allows 2 concurrent admin users.

   - Instructions to set up a _temporary license_ for multi-user RDP:
~~~
Add-WindowsFeature –Name RDS-RD-Server –IncludeAllSubFeature

New-ItemProperty -Path "Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name MaxInstanceCount -Value 50 -Force | Out-Null

restart-computer 
REF LINK:  https://www.virtualizationhowto.com/2020/10/reset-120-day-rds-grace-period-on-2016-and-2019/

~~~

   - Instructions to set up a _permanent license_ for multi-user RDP:
     - An ESEC request is required to allow Windows server in VPC to communicate with on-prem VA TS license server.

Source | Destination | Ports | System
--- | --- | --- | ---
Bastion host IPs, Subnet or VPC | tslicense1.va.gov (10.245.237.68), tslicense2.va.gov (10.204.98.102), tslicense.va.gov (10.204.98.101)| TCP Dynamic (49152 - 65535), 135/TCP, 135/UDP | Windows Terminal Server licensing

   - Once connectivity is established, execute the following steps to configure server with VA license server:
     - Click on Start and type `gpedit` and go into _Edit Group Policy_
     - Navigate to: _Computer Configuration\Administrative Templates\Windows Components\Remote Desktop Services\Remote Desktop Session Host\Licensing_
     - Open "Use the specified Remote Desktop license servers"
       - Change it to _Enabled_ and enter `tslicense1.va.gov`
     - Open "Set the Remote Desktop licensing mode"
       - Change it to _Enabled_ and set it to `Per Device`
     - Restart the server

4. **Domain Join:**  Join the Windows instance/s with VA AD: [VAEC Self Join Process for Windows](https://kb.vaec.va.gov/display/VK/VAEC+Self-Join+Process+for+Windows). This also allows users to directly sign in using e-token.

## RDP to the project bastion host
  - Instructions for a user inside the VA network to RDP to their Windows Remote Instance in AWS: [VAEC How to Guide - AWS Windows RDP](https://kb.vaec.va.gov/pages/viewpage.action?pageId=2130559&preview=%2F2130559%2F6389926%2FAWS+Windows+RDP.docx&searchId=HFUECP4P7).

### Note:
- Sample command to join server to a specific OU:
~~~
$OUPath = "OU=DEV,OU=ECS,OU=Servers,OU=AWS,OU=VAEC,DC=va,DC=gov"
Add-Computer -domainname va.gov -OUPath $OUPath -cred $(get-credential) -passthru –verbose 
~~~

- Along with the VAEC self join steps, this list has futher details and videos showing exactly how to build the server, join it, and how to connect to it using RD Gateway:
  - https://dvagov.sharepoint.com/:f:/s/OITEPMOECSOCOMS/Epnb1gP6R9VCjgfR87b0cgABrK9PuBLLD3BOwitWKH1o5Q?e=F7e4jp 

