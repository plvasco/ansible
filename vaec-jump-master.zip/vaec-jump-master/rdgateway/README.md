# VAEC Remote Desktop Gateway

## Overview
This solution allows users connect from their GFE/Laptop to Windows Remote Instance in AWS with RDP client
- There is no _hop_ - The connection is from GFE/Laptop directly to Windows Remote Instance, but this goes through _transparent_ Remote Desktop Gateway for authentication.

## User How-To
Instructions for a User inside the VA network to RDP to their Windows Remote Instance in AWS:  [VAEC How to Guide - AWS Windows RDP.docx](https://kb.vaec.va.gov/pages/viewpage.action?pageId=2130559)

### RD Gateway hostnames
- AWS GovCloud West: `rdgateway.west.vaec.va.gov`
- AWS GovCloud East: `rdgateway.east.vaec.va.gov`


## Windows RDP using RD Gateway

<img src="vaec-rdgateway.jpg" />

[vaec-rdgateway.drawio](vaec-rdgateway.drawio)


## Deployment
The CloudFormation stack [vaec-rd-gateway.yml](vaec-rd-gateway.yml) uses the following parameters:

Parameter | GovWest | GovEast
 --- | --- | ---
pEnvTag | Production | Production
pKeyPairName | entcoress | entjump-east
pVpcId |  vpc-7a82241f |vpc-07b77963673e3320e
pSubnetIds | subnet-d3cb51b7,subnet-f34fd185 | subnet-05bd31581c8586d66,subnet-0c24f70c9b0f2b5a4
pAmiIdApp  | ami-3db0ca5c |  ami-059dd9a829db83e1e
pInstanceType | m5.large | t3.medium

## Remaining tasks
- Develop automated configuration script
  - RD Gateway installation
  ~~~
  Install-WindowsFeature RDS-Gateway,RSAT-RDS-Gateway
  ~~~
  - AD domain join
~~~
$OUPath = "OU=Cloud RDS Infrastructure,OU=Prod,OU=ECS,OU=Servers,OU=AWS,OU=VAEC,DC=va,DC=gov"
Add-Computer -domainname va.gov -OUPath $OUPath -cred $(get-credential) -passthru –verbose
~~~
  - RD Gateway configuration
    - Start RD Gateway Manager application
      - Select server ->
         - Policies -> Create New Authorization Policy -> Create RD CAP and RD RAP ->
             - "Default CAP" -> Select Smart Card -> Add VA\cldwinp_userprofiles to group membership
             - "Default RAP" -> Allow users to connect to any network resource

- Autoscaling
  - Run Windows update
  - Run automated configuration script
- Evaluate ELB
- Turn off IIS


## Reference
- https://docs.aws.amazon.com/quickstart/latest/rd-gateway/overview.html
- https://aws.amazon.com/quickstart/architecture/rd-gateway/
