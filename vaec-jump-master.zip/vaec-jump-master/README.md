# Accessing VA instances in VPCs from VA network

For accessing application on specific ports or say DB server in AWS from GFE, ESEC request was required to open ports. Instead, consider using Azure Virtual Desktop [VA Remote Access Information | DigitalVA](https://www.oit.va.gov/resources/remote-access/) with e-token, since VA has opened wide port-range for AVD NEMA desktops.

## Ports allowed by VA
- Access from VA network to AWS VAEC Jump VPCs on ssh (port 22) and RDP (port 3389). 
- Access from+to VA network to all AWS VPCs on http (port 80) and https (port 443)
- Users who need to access servers in their own VPCs are required to go through jump hosts provisioned by VAEC in _shared_ Jump VPC.

## SSH through Unix Jump Hosts
- There are two Unix jump hosts in AWS in each Region:

| GovWest | Gov East|
| --- | --- |
vac10acsecs201.va.gov, vac10acsecs202.va.gov | vac11acsecs201.va.gov, vac11acsecs202.va.gov


- Access to the above servers required ePAS etoken (URL= ...)
- Request following two profiles in epas: 
  - `cldunixp_userprofiles`
  - your application specific profile, for example `cldunixs_prj_user_dev`
- Instructions for ssh using etoken (URL= ...)

## RDP to remote Windows instance
Windows remote instances can be accessed by RDP (TCP/3389) using [Remote Desktop Gateway](rdgateway/README.md).

## Shell access using Session Manager
EC2 instances can be accessed from AWS Console using AWS Session Manager. Please review [EC2 instance access using Session Manager](session-manager/README.md).

## Access to non-standard ports using port forwarding
- Access to non-standard ports can be done using ssh port-forwarding from the Unix jump hosts
- Instructions for port forwarding using VA Unix jump hosts:
  - [VAEC How to Guide - DRAFT Reflection SSH Port Forwarding via RH Jump box](https://vaww.portal.va.gov/sites/ECS/Environments/AWS/VAEC%20How%20to%20Guide%20-%20DRAFT%20Reflection%20SSH%20Port%20Forwarding%20via%20RH%20Jump%20box.docx)
- Instructions for port forwarding using AWS Session Manager:
  - https://aws.amazon.com/blogs/aws/new-port-forwarding-using-aws-system-manager-sessions-manager/
