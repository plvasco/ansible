import boto3
import logging
import json
import sessionmod
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

dryrun=False

# --------------------------------------------------------------------------------------------------------

def lambda_handler(event, context):

    if 'Records' in event:
        # Process SQS Event
        if event['Records'][0]['eventSource'] == 'aws:sqs':
            logger.info("Received SQS event: " + json.dumps(event))
            for record in event['Records']:
                json_body = record.get('body')
                logger.info("JSON payload: " + json_body)
                process_payload(json.loads(json_body))
        else:
            ex="Invalid event not processed:" + json.dumps(event)
            logger.exception(ex)
            raise ex
    #Scenario when the Lambda function is invoked from AWS CLI or AWS API
    else :
        process_payload(event)

# --------------------------------------------------------------------------------------------------------
def process_payload(eventinfo):
    try:
        msg = cleanup_payload(eventinfo)

        if msg['action'] == 'pcx-create':
            if 'verify_connection_id' not in msg or msg['verify_connection_id'] not in ['True', 'False']:
                    msg['verify_connection_id'] = 'True'
            pcx = pcx_create(msg)
            if pcx:
                pcx_rt_update(pcx, 'Add')
        elif msg['action'] == 'pcx-delete':
            pcx = pcx_delete(msg)

    except Exception as ex:
        logger.exception(ex)

def cleanup_payload(in_dict):
    out_dict = {}
    for (k,v) in in_dict.items():
        out_dict[k.strip()] = v.strip()
    return out_dict


# --------------------------------------------------------------------------------------------------------
def pcx_delete(msg):
    try:
        req_session_assumed = sessionmod.aws_session3(msg['requester_owner_id'], msg['requester_region'])
        req_ec2r = req_session_assumed.resource('ec2')

        pcx = req_ec2r.VpcPeeringConnection(msg['pcx_id'])
        if pcx:
            pcx_rt_update(pcx, 'Remove')
            logger.info('Delete pcx %s' %(pcx.id))
            pcx.delete(DryRun=dryrun)
    except Exception as ex:
        logger.exception(ex)

# --------------------------------------------------------------------------------------------------------
def pcx_create(msg):
    try:
        pcx = None

        # Obtain and verify parameters
        req_vpc_info = get_vpc_info(msg['requester_owner_id'], msg['requester_region'], msg['requester_vpc_id'])

        accpt_vpc_info = get_vpc_info(msg['accepter_owner_id'], msg['accepter_region'], msg['accepter_vpc_id'])

        if not msg['verify_connection_id'] == 'False':
            to_continue=True
            if not req_vpc_info['vaec:ConnectionID']:
                logger.error('%s - invalid or no [vaec:]ConnectionID' %(msg['requester_vpc_id']))
                to_continue=False
            if not accpt_vpc_info['vaec:ConnectionID']:
                logger.error('%s - invalid or no [vaec:]ConnectionID' %(msg['accepter_vpc_id']))
                to_continue=False
            if req_vpc_info['vaec:ConnectionID'].split('-')[0] == accpt_vpc_info['vaec:ConnectionID'].split('-')[0]:
                logger.error('VPCs are in same tier, no pcx needed')
                to_continue=False
            if not to_continue:
                return pcx

        # pcx Name tag
        pcx_name_tag= msg.get('pcx_name_tag',
                              req_vpc_info['Name'] + '-peering-' + accpt_vpc_info['Name'])

        pcx_tags = [{ 'Key': 'Name', 'Value': pcx_name_tag }]
        #    { 'Key': 'vaec:requester:ConnectionID', 'Value': req_vpc_info['vaec:ConnectionID'] },
        #    { 'Key': 'vaec:accepter:ConnectionID', 'Value': accpt_vpc_info['vaec:ConnectionID'] },
        # print(pcx_tags)

        # Requester - create pcx and tag
        req_session_assumed = sessionmod.aws_session3(msg['requester_owner_id'], msg['requester_region'])
        req_ec2r = req_session_assumed.resource('ec2')

        logger.info('Create pcx %s' %(str(msg)))
        pcx = req_ec2r.create_vpc_peering_connection(
            DryRun=dryrun,
            PeerOwnerId = msg['accepter_owner_id'],
            PeerVpcId = msg['accepter_vpc_id'],
            VpcId = msg['requester_vpc_id'],
            PeerRegion = msg['accepter_region'],
        )

        logger.info('Requester tag %s %s' %(pcx.id,str(pcx_tags)))
        req_ec2r.create_tags(Resources=[pcx.id], Tags= pcx_tags)

        # pcx wait_until_exists
        pcx.wait_until_exists(
                DryRun = dryrun,
                Filters = [ {'Name': 'status-code', 'Values': ['pending-acceptance', 'active', 'rejected'] } ]
            )

        # Accepter - accept pcx and tag
        accpt_session_assumed = sessionmod.aws_session3(msg['accepter_owner_id'], msg['accepter_region'])
        accpt_ec2r = accpt_session_assumed.resource('ec2')

        accpt_pcx = accpt_ec2r.VpcPeeringConnection(pcx.id)

        logger.info('Accepter accept %s' %(pcx.id))
        accpt_pcx.accept()

        logger.info('Accepter tag %s %s' %(pcx.id, str(pcx_tags)))
        accpt_ec2r.create_tags(Resources=[pcx.id], Tags= pcx_tags)

    except Exception as ex:
        # logger.info('Delete pcx %s' %(pcx.id))
        # if pcx:
            # pcx.delete(DryRun=dryrun)
        logger.error(ex)
        raise(ex)

    # print(pcx)
    return pcx

# --------------------------------------------------------------------------------------------------------
def get_vpc_info(acctid, region, vpcid):
    ret_val= { 'Name': '', 'vaec:ConnectionID': '' }
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        rec2r = session_assumed.resource('ec2')

        vpc = rec2r.Vpc(vpcid)
        if vpc.tags:
            cid1=''
            cid2=''
            for t in vpc.tags:
                if t['Key'] == 'Name':
                    ret_val['Name'] = t['Value'].strip()
                elif t['Key'] == 'vaec:ConnectionID':
                    cid1 = t['Value'].strip()
                elif t['Key'] == 'ConnectionID':
                    cid2 = t['Value'].strip()

            # prefer 'vaec:ConnectionID' over 'ConnectionID'
            if cid1:
                ret_val['vaec:ConnectionID'] = cid1
            else:
                ret_val['vaec:ConnectionID'] = cid2

            # Check for valid tier
            if ret_val['vaec:ConnectionID'] and ret_val['vaec:ConnectionID'].split('-')[0] not in ['311', '312', '313']:
               ret_val['vaec:ConnectionID'] = ''


    except Exception as ex:
        logger.error(ex)
        raise(ex)

    return ret_val


# --------------------------------------------------------------------------------------------------------
def pcx_rt_update(pcx, rt_action):

    try:
        # pcx wait_until_status is 'active'
        pcx.wait_until_exists(
                DryRun = dryrun,
                Filters = [ {'Name': 'status-code', 'Values': ['active'] } ]
            )
        pcx.reload()

        # Assume sessions
        req_session_assumed = sessionmod.aws_session3(pcx.requester_vpc_info['OwnerId'], pcx.requester_vpc_info['Region'])


        req_ec2c = req_session_assumed.client('ec2')

        accpt_session_assumed = sessionmod.aws_session3(pcx.accepter_vpc_info['OwnerId'], pcx.accepter_vpc_info['Region'])
        accpt_ec2c = accpt_session_assumed.client('ec2')

        # While CIDRs are available in pcx object, sometimes it's not available right away
        # and causes script to fail
        #
        # if pcx.requester_vpc_info.get('CidrBlockSet'):
            # requester_vpc_cidrs = pcx.requester_vpc_info.get('CidrBlockSet')
        # else:
            # requester_vpc_cidrs = [{'CidrBlock': pcx.requester_vpc_info['CidrBlock']}]

        # if pcx.accepter_vpc_info.get('CidrBlockSet'):
            # accepter_vpc_cidrs = pcx.accepter_vpc_info.get('CidrBlockSet')
        # else:
            # accepter_vpc_cidrs = [{'CidrBlock': pcx.accepter_vpc_info['CidrBlock']}]


        # Obtain VPC CIDRs
        rvpc = req_ec2c.describe_vpcs(VpcIds=[pcx.requester_vpc.id])['Vpcs'][0]
        avpc = accpt_ec2c.describe_vpcs(VpcIds=[pcx.accepter_vpc.id])['Vpcs'][0]

        if rvpc['CidrBlockAssociationSet']:
            requester_vpc_cidrs = rvpc['CidrBlockAssociationSet']
        else:
            requester_vpc_cidrs = [{'CidrBlock': rvpc['CidrBlock']}]

        if avpc['CidrBlockAssociationSet']:
            accepter_vpc_cidrs = avpc['CidrBlockAssociationSet']
        else:
            accepter_vpc_cidrs = [{'CidrBlock': avpc['CidrBlock']}]



        # Requester rtb
        logger.info('Requester rtb %s routes', rt_action)
        for acidr in accepter_vpc_cidrs:
            upd_pcx_rt(req_ec2c, pcx.requester_vpc.id, acidr['CidrBlock'], pcx.id, rt_action)

        # Accepter rtb
        logger.info('Accepter rtb %s routes', rt_action)
        for rcidr in requester_vpc_cidrs:
            upd_pcx_rt(accpt_ec2c, pcx.accepter_vpc.id, rcidr['CidrBlock'], pcx.id, rt_action)

    except Exception as ex:
        logger.error(ex)
        raise(ex)


def upd_pcx_rt(ec2client, vpcid, dest_cidr, pcxid, rt_action):
    rtbls=ec2client.describe_route_tables(
       Filters=[{ 'Name': 'vpc-id', 'Values': [vpcid] }, { 'Name': 'association.main', 'Values': ['false'] }])
    for rtassoc in rtbls['RouteTables']:
        rtid=rtassoc['RouteTableId']
        logger.info('%s route: VPC=%s RTB=%s Destination=%s Target=%s' % (rt_action, vpcid, rtid, dest_cidr, pcxid))
        try:
            if rt_action == 'Add':
                ec2client.create_route(DestinationCidrBlock=dest_cidr, RouteTableId=rtid, VpcPeeringConnectionId=pcxid, DryRun=dryrun)
            elif rt_action == 'Remove':
                ec2client.delete_route(DestinationCidrBlock=dest_cidr,RouteTableId=rtid, DryRun=dryrun)
        except Exception as ex:
            logger.error('%s route: VPC=%s RTB=%s Destination=%s Target=%s - %s' %(rt_action, vpcid, rtid, dest_cidr, pcxid, ex))

#--------------------------------------------------------------------------------------------------------
# Example cli: python3 vaec-pcx-handler.py  --event '....'

if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser(description='VPC peering connection handler')
    parser.add_argument('--nodryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled.')
    parser.add_argument('--event', dest='eventinfo', required=False, help='SQS message with Lambda event info')
    args = parser.parse_args()

    dryrun=args.nodryrun

    def main():
        lambda_handler(json.loads(args.eventinfo), "")
        # lambda_handler(json.loads(eventinfo), "")

    main()
