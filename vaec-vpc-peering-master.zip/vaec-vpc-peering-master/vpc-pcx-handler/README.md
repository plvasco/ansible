# VAEC VPC Peering Handler

Manage VPC peering connections and related routing table updates:
- Same account or cross-account
- Same region or cross-region 
- Requester account and Accepter account must have the _vaec-authorizer_role_
- VPCs must be tagged with the _vaec:ConnectionID_ (or the legacy _ConnectionID_)

This solution is implemented in _core_gov_internal and peering connections are managed by placing messages in SQS queue `vaec-vpc-pcx-handler-rQueue-12ZTKQ1YCTCI2`.

## When is VPC peering required
- Each VAEC VPC has a tag with key=_ConnectionID_ and value=_31X-XXX_, where the prefix denotes the security tier:
  - Development=313, Stage=312, Production=311
- Regardless of the VA AWS account number that VPC belongs to, network routing already exists for VPCs in the same tier (i.e. same ConnectionID prefix) to communicate with each other - _no VPC peering is required in this case_.
- Traffic that crosses tiers (_311 <-> 312_, _311 <-> 313_ or _311 <-> 313_) is routed to the VA TIC by default.
- **On a case-by-case basis only:** To keep the cross-tier traffic in AWS (and not route it throught the TIC), ECSO/Security may approve cross-tier VPC peering connections with appropriate justification.
- **Projects are not permitted to create VPC peering connections.**

## Request required information

- To request cross-tier VPC peering connections, please open a ticket at https://wfm.vaec.va.gov:
  - Type = "Service Request with Approvals"
  - ECSO approvers = <Joseph.Fourcade@va.gov> and <Robert.Ballon@va.gov>
  - Description should include a list of VPC requested peering connections as follows:

| Account ID | VPC Name | VPC ID | Region | ConnectionID | Peer Account ID | Peer VPC Name | Peer VPC ID | Peer Region | Peer ConnectionID | 
 --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
<12-digit account#> | XXX:Env1:VPC | vpc-xxx | us-gov-xxst-1 | 31x-xx | <12-digit account#> | XXX:Env2:VPC | vpc-xxx | us-gov-xxst-1 | 31x-xxx

## Create peering connection and routes
- As a convention, peering connections Requester VPC is higher tier (311/312), and Acceptor is lower tier (312/313).

- Place SQS message with the following payload in VPC peering queue:
~~~
{
  "action": "pcx-create",
  "requester_owner_id": "477244352852",
  "requester_region": "us-gov-west-1",
  "requester_vpc_id": "vpc-1e1a5b7a",
  "accepter_owner_id": "477194928391",
  "accepter_region": "us-gov-west-1",
  "accepter_vpc_id": "vpc-2825304d" 
}
~~~

- By default, peering connections in the same tier (Development-313, Stage-312 or Production-311) will be skipped since peering is not necessary. To override include:
~~~
 "verify_connection_id" : "False"
~~~
- By default, the peering connection tag Name = _"requester_vpc_Name-peering-accepter_vpc_Name"_. To override, provide alternate name: 
~~~
  "pcx_name_tag": "Requester-VPC-peering-Accepter-VPC"
~~~

## Delete peering connection and routes
Place SQS message with the following payload in VPC peering queue:

~~~
{
  "action": "pcx-delete",
  "pcx_id": "pcx-059e69c7819c99440",
  "requester_owner_id": "477244352852",
  "requester_region": "us-gov-west-1",
  "requester_vpc_id": "vpc-1e1a5b7a"
}
~~~
