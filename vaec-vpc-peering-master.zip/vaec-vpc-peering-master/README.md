# VAEC VPC peering


## VAEC VPC Peering Handler

This is the new solution to centrally manage VPC peering connections and related routing table updates from core-gov-internal for any combination of VPC peering connections: same account, different accounts, same region, different regions.

Refer [vpc-pcx-handler](vpc-pcx-handler).


## VPC peering inventory

Script to inventory VPC peering connections in VA AWS also de-duplicates based on Requester and Accepter:
[vaec_inventory_vpc_peering.py](https://github.ec.va.gov/AWS/vaec-organizations/blob/master/inventory/vaec_inventory_vpc_peering.py)


## Legacy VAEC VPC Peering

[legacy-vpc-peering](legacy-vpc-peering) contains the legacy solution that requires deployment of CloudFormation stacks in Accepter and Requester accounts. **This is no longer recommended and deployed, and only included here for reference**.

