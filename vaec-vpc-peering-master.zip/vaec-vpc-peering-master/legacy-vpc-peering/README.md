# vaec-vpc-peering
Cross-account and cross-region VPC Peer and Routing Table update Lambda Functions and Requester Role. The Accepter account must have created the role to authorize the VPC Peer request


## project-vpc-peering-authorizer-role.yml

- Stand-alone authorizer role to allow a *Requester* account to create peering connections and routes, then accept a VPC Peering on behalf of an accepter account. 
- Create this stack in *Accepter* account
  - No need to deploy if peering is in same account. Leave the_PeerRoleName_ blank for same account.
  - Provide the *Requester* account ID
  - Deploy using following stack name {projectshort}-vpc-peering-authorizer-role.yml

## vaec-vpc-peering-authorizer-role.yml
- For peering from core-gov-internal and security-gov-internal accounts. Not needed since this is already deployed using landingzone.

## vaec-vpc-peering-lambda.yml
- This stack creates the Lambda functions that execute the Local VPC Peering and route creation then executes the remote VPC accept and route creation. For custom deployments no modifications are necessary.
- Deploy in *Requester* account as-is  with stack name _vaec-vpc-peering-lambda_. The next stack depends on specifically named Stack exports. 


## vaec-vpc-peering.yml
When deploying this stack name should be \[ProjectShort\]-\[Tier\]-VPC-peering-B\[ProjectShort\]-\[Tier\]-VPC 

e.g. Proj1-Production-VPC-peering-Proj2-Stage-VPC

This stack creates Lambda backed custom resources that trigger lambda functions to create local and remote routes.

Parameters required:
 * RequesterVPC (Requester/Local VPC ID in requester account where Lambda functions deployed)
 * PcxTagName (Same as stack name)
 * PeerRoleName (Authorizer role deployed in accepter account, leave blank for same account)
 * AccepterVPC (Accepter/Peer VPC ID)
 * AccepterVPCOwner (Accepter/Peer AWS Account ID)
 * AccepterRegion (Accepter/Peer VPC region)
