# project-vm-migration

Repository of solutions for VM migration to AWS.

There are multiple options for VM migration to AWS cloud including the following:

1. VMImport/Export commands - best for fewer non-concurrent VM migrations, converting VM's to AMI's/EC2 instances
2. Server Migration Services - best for multiple concurrent VM migrations and staged migrations with replication scheduling, leverages virtual appliance 'connector' requiring direct access to vSphere/Hyper-V environments
3. VMware Cloud on AWS (VMware only) - best for migrating VMware workloads to AWS without VM conversion to EC2, running VMware vSphere VM's natively in the AWS cloud.

The [VM Migration Options Flowchart](https://github.ec.va.gov/AWS/vaec-vm-migration/blob/migration_options/diagrams/VM%20Migrations%20Flow%20Image.PNG) illustrates the path and choices made when deciding which tool is appropriate.
Initial considerations are:

* type of VM ie: VMware or Hyper-V
* number of VM's to migrate
* multi-VM application migration requiring staging/concurrent migrations
* retaining original vm format
* accessibility of exported images (OVA) and/or access to original hypervisor environments (vSphere, HyperV/SCCM)

![VM Migration Options Flowchart](https://github.ec.va.gov/AWS/vaec-vm-migration/blob/migration_options/diagrams/VM%20Migrations%20Flow%20Image.PNG)

## Using VMImport - project-vmimport.yml

The steps for VMImport command method using these [Requirements](https://docs.aws.amazon.com/vm-import/latest/userguide/vmie_prereqs.html) to implement this [process](https://docs.aws.amazon.com/vm-import/latest/userguide/vmimport-image-import.html) are outlined in the [VMImport User Guide](https://docs.aws.amazon.com/vm-import/latest/userguide/vm-import-ug.pdf).

The stack _project-vmimport.yml_ creates resources for a project to store their exported VM Image files, then with the provided permissions import them. This stack to be **created by VAEC-administrator** since the required IAM service role is not within permissions boundary.

This stack creates:
* S3 Bucket
* Service Role that VM Import Assumes to register AMI
* VM Import Instance Profile
* VM Import Policy that grants permissions create/import VMs to AMIs

### VM Import from Instance with attached role

![VM Import by Instance](https://github.ec.va.gov/AWS/vaec-vm-migration/blob/master/diagrams/instance-import.png)

1. The project admin exports VM in open format at remote data center.
2. Prepare an EC2 instance that will execute the VM Import commands:
   - Install the AWS CLI on the instance if not already present using [this method](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-install.html).
   - Attach IAM role that was created by_project-vmimport.yml_ stack (role name specified by _pRoleName_ parameter) to the instance. This role grants permissions to the S3 bucket and to execute VM Import commands.
   - Note: Do not attach "vmimport" which is a service role which will be created by the stack.
4. From instance run commands to upload exported VM Images to stack created bucket.
5. From instance run "aws ec2 import-image..." to create AMI

# Server Migration Services

Steps for migration of VM's using Server Migration Services according to these [Requirements](https://docs.aws.amazon.com/server-migration-service/latest/userguide/prereqs.html)

The following OS's are supported for migration using SMS [Supported OS's](https://docs.aws.amazon.com/server-migration-service/latest/userguide/prereqs.html#os_prereqs)

[Server Migrations Services User Guide](https://docs.aws.amazon.com/server-migration-service/latest/userguide/server-migration.html)

1. Create a new IAM user for your Server Migration Connector to communicate with AWS. Save the generated access key and secret key for use during the initial connector setup. For information about managing IAM users and permissions, see [Creating an IAM User in Your AWS Account](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_users_create.html)

2. Attach the managed IAM policy ServerMigrationConnector to the IAM user. For more information, see [Managed Policies and Inline Policies](https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_managed-vs-inline.html)

3. If AMI encryption is required with customer KMS key (CMK), then the CMK must allow _AWSServiceRoleForSMS_ role to use the key.<br/>Following steps shows how to grant the _AWSServiceRoleForSMS_ role access to use the CMK:<br/>
3.1 Go to Key Management Service in AWS Console and find the customer key.<br/>
3.2 Edit the key policy, statement  "Sid": "Allow use of the key": Add the ARN for _AWSServiceRoleForSMS_ role as a Principal oh ok. 
  
## project-sms-service-role.yml
Use the following YML to create an IAM role that grants permissions to AWS SMS to place migrated resources into your Amazon EC2 account.

## Installing the SMS Connector VMware

Setting up AWS SMS to migrate VMs from VMware to Amazon EC2 steps found [here](https://docs.aws.amazon.com/server-migration-service/latest/userguide/VMware.html)

## Replicating VM's Using the AWS SMS Console

Instructions and workflow for performing replication of on-premise VMs to AWS for migration can be found [here](https://docs.aws.amazon.com/server-migration-service/latest/userguide/console_workflow.html)

## VM export image user guide

https://docs.aws.amazon.com/vm-import/latest/userguide/vmexport_image.html#start-image-export 
