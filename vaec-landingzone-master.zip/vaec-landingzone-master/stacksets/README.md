# CloudFormation StackSets

- StackSets are deployed once to _core-gov-internal_, and member Organizations accounts automatically get deployed.
- StackSets don't deploy to Organizations management account, so each required stack is deployed individually to _core-gov-internal_.
- Unless explicitly noted, StackSets are deployed only in _us-gov-west-1_ region


## StackSets external to this repository:
- [vaec-cls / awslogs / vaec-cloudwatch-account-logging-rule.yml](https://github.ec.va.gov/AWS/vaec-cls/blob/master/awslogs/vaec-cloudwatch-account-logging-rule.yml)
  - Regions: _us-gov-west-1_ + _us-gov-east-1_

