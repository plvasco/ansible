import boto3
from botocore.exceptions import ClientError
import urllib3
import argparse

parser = argparse.ArgumentParser(description='VAEC IDP ADFS for SSO')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='us-gov-west-1 or us-east-2')
parser.add_argument('--metadata-url', dest='metadata_url', default='https://prod.adfs.federation.va.gov/federationmetadata/2007-06/federationmetadata.xml', help='default=https://prod.adfs.federation.va.gov/federationmetadata/2007-06/federationmetadata.xml')
parser.add_argument('--idp-name', dest='idp_name', default='ADFS', help='default=ADFS')
args = parser.parse_args()

def create_idp(metadata_url, idp_name, region_id):
    try:
        iamc = boto3.client('iam',region_name=region_id)

        http=urllib3.PoolManager(cert_reqs='CERT_NONE')
        r = http.request('GET', metadata_url)
        # print("# --------------------\n%s\n# --------------------" % (r.data))

        resp = iamc.create_saml_provider(SAMLMetadataDocument=str(r.data,'utf-8'), Name=idp_name)
        print(resp)

    except ClientError as ex:
        print(ex)
        if not ex.response['Error']['Code'] == 'EntityAlreadyExists':
            raise

if __name__=='__main__':
    # print('%s arguments:\nmetadata_url=%s\nidp_name=%s\nregion_id=%s\n' %(__file__, args.metadata_url, args.idp_name, args.region_id))
    create_idp(args.metadata_url, args.idp_name, args.region_id)



