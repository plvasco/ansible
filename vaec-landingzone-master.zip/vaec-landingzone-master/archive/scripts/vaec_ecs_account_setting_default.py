import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_ecs_account_setting_default.py
#python3 vaec_ecs_account_setting_default.py --account-id all
#python3 vaec_ecs_account_setting_default.py --account-id 477194928391

parser = argparse.ArgumentParser(description='VAEC ECS account setting default')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--role', dest='remote_role', default='vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        session_name=__file__.split('.py')[0].replace('/', '_')
        sessionmod.iterate_accounts_regions(ecs_put_account_setting_default, args.remote_account_id, args.region_id, args.remote_role, session_name)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def ecs_put_account_setting_default(acctid, region, role, session_name):
    try:
        session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(acctid, role)),
                        session_name, region)
        recsc = session_assumed.client('ecs')
        
        response = recsc.put_account_setting_default(name='serviceLongArnFormat', value='enabled')
        logger.info(response['setting'])

        response = recsc.put_account_setting_default(name='taskLongArnFormat', value='enabled')
        logger.info(response['setting'])

        response = recsc.put_account_setting_default(name='containerInstanceLongArnFormat', value='enabled')
        logger.info(response['setting'])

    except Exception as ex:
        logger.error(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
