import argparse
import sys
import boto3
import sessionmod
from botocore.exceptions import ClientError
import logging

## Module defaults
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

parser = argparse.ArgumentParser(description='Create csv file for GuardDuty based on accounts active in AWS Organizations')
parser.add_argument('--role', dest='remote_role', default='vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or comma-separated list of account-id')
parser.add_argument('--action', dest='action', default='check', choices=['create', 'update', 'check', 'delete'], help='create, update, check, delete. Default = check')
parser.add_argument('--config-role-name', dest='config_role_name', default='vaec/vaec-awsconfig-role', help='Config role ARN')
parser.add_argument('--s3-bucket-name', dest='s3_bucket_name', default='vaec-awsconfig-logs', help='Config recorder delivery channel-centralized s3 bucket name in security-logs-internal account')
parser.add_argument('--delivery-frequency', dest='delivery_frequency', default='TwentyFour_Hours', help="One_Hour'|'Three_Hours'|'Six_Hours'|'Twelve_Hours'|'TwentyFour_Hours")
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')

args = parser.parse_args()


#---------------------------------------------------------------------------
def main(argv):
    try:
        #region_id='us-gov-west-1'
        session_name=__file__.split('.py')[0].replace('/', '_')
        if args.action == 'create':
            sessionmod.iterate_accounts_regions(create_aws_config,
                                args.remote_account_id,
                                args.region_id,
                                args.remote_role,
                                session_name,
                                args.config_role_name,
                                args.s3_bucket_name,
                                args.delivery_frequency)
        elif args.action == 'update':
            sessionmod.iterate_accounts_regions(update_aws_config,
                                args.remote_account_id,
                                args.region_id,
                                args.remote_role,
                                session_name,
                                args.config_role_name,
                                args.s3_bucket_name,
                                args.delivery_frequency)
        elif args.action == 'check':
            sessionmod.iterate_accounts_regions(check_aws_config,
                                args.remote_account_id,
                                args.region_id,
                                args.remote_role,
                                session_name)
        elif args.action == 'delete':
            sessionmod.iterate_accounts_regions(delete_aws_config,
                                args.remote_account_id,
                                args.region_id,
                                args.remote_role,
                                session_name,
                                args.config_role_name,
                                args.s3_bucket_name,
                                args.delivery_frequency)
    except Exception as ex:
        raise ex

#---------------------------------------------------------------------------
def is_valid_iam_role(session_name, remote_account_id, region_id, remote_role, config_role_arn):
    is_valid_role=False
    try:
        ssm_session_assumed = sessionmod.aws_session(
                                ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                                session_name, region_id)
        iamc = ssm_session_assumed.client('iam')

        paginator = iamc.get_paginator('list_roles')
        page_iterator = paginator.paginate(PathPrefix='/vaec/')
        for page in page_iterator:
            for role in page['Roles']:
                if role['Arn'] == config_role_arn:
                    is_valid_role=True
                    break
    except ClientError as ex:
        logger.exception(ex)
        raise ex

    if is_valid_role:
        logger.info("%s %s Valid Role ARN: %s" % (region_id, remote_account_id, config_role_arn))
    else:
        logger.info("%s %s Invalid Role ARN: %s" % (region_id, remote_account_id, config_role_arn))
    return is_valid_role

#---------------------------------------------------------------------------
def create_aws_config(remote_account_id,
                      region_id,
                      remote_role,
                      session_name,
                      config_role_name,
                      s3_bucket_name,
                      delivery_frequency):
    try:
        ssm_session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        session_name, region_id)
        config_client = ssm_session_assumed.client('config')
        config_role_arn = "arn:aws-us-gov:iam::" + remote_account_id + ":role/" + config_role_name
        if not is_valid_iam_role(session_name, remote_account_id, region_id, remote_role, config_role_arn):
            return

        recorder_name='vaec-config-recorder-'+remote_account_id
        recorder_response = config_client.describe_configuration_recorders()
        if recorder_response['ConfigurationRecorders']:
            logger.info("%s %s AWS Config Recorder exists, updating" % (region_id, remote_account_id))
            update_aws_config(remote_account_id,
                                  region_id,
                                  remote_role,
                                  session_name,
                                  config_role_name,
                                  s3_bucket_name,
                                  delivery_frequency)
            return
        else:
            logger.info("%s %s AWS Config Recorder not found, creating." % (region_id, remote_account_id))
            create_aws_config_recorder(config_client,
                                       recorder_name,
                                       config_role_arn,
                                       s3_bucket_name,
                                       delivery_frequency)
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def update_aws_config(remote_account_id,
                      region_id,
                      remote_role,
                      session_name,
                      config_role_name,
                      s3_bucket_name,
                      delivery_frequency):
    try:
        ssm_session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        session_name, region_id)
        config_client = ssm_session_assumed.client('config')
        config_role_arn = "arn:aws-us-gov:iam::" + remote_account_id + ":role/" + config_role_name
        if not is_valid_iam_role(session_name, remote_account_id, region_id, remote_role, config_role_arn):
            return
        recorder_name='vaec-config-recorder-'+remote_account_id
        recorder_response = config_client.describe_configuration_recorders()
        if recorder_response['ConfigurationRecorders']:
            #Record already exist
            for recorder in recorder_response['ConfigurationRecorders']:
                recorder_status_response = config_client.describe_configuration_recorder_status(
                                                ConfigurationRecorderNames=[recorder['name']])
                recorder_status=recorder_status_response['ConfigurationRecordersStatus'][0]
                update_aws_config_recorder(config_client,
                                               recorder,
                                               recorder_status,
                                               recorder_name,
                                               config_role_arn,
                                               s3_bucket_name,
                                               delivery_frequency)

                #logger.info("%s %s AWS Config recorder is configured, Name: %s, Recording: %b, Operation Status: %s" % (region_id, remote_account_id, recorder_status['name'], recorder_status['lastStatus']))
        else:
            logger.info("%s %s AWS Config Recorder not found, cannot update." % (region_id, remote_account_id))
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def delete_aws_config(remote_account_id,
                      region_id,
                      remote_role,
                      session_name,
                      config_role_name,
                      s3_bucket_name,
                      delivery_frequency):
    try:
        ssm_session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        session_name, region_id)
        config_client = ssm_session_assumed.client('config')
        config_role_arn = "arn:aws-us-gov:iam::" + remote_account_id + ":role/" + config_role_name
        recorder_name='vaec-config-recorder-'+remote_account_id
        recorder_response = config_client.describe_configuration_recorders()
        if recorder_response['ConfigurationRecorders']:
            #Record already exist
            for recorder in recorder_response['ConfigurationRecorders']:
                recorder_status_response = config_client.describe_configuration_recorder_status(
                                                ConfigurationRecorderNames=[recorder['name']])
                #print(recorder_status_response)
                recorder_status=recorder_status_response['ConfigurationRecordersStatus'][0]
                delete_aws_config_recorder(config_client,
                                               recorder,
                                               recorder_status,
                                               recorder_name,
                                               config_role_arn,
                                               s3_bucket_name,
                                               delivery_frequency)

                #logger.info("%s %s AWS Config recorder is configured, Name: %s, Recording: %b, Operation Status: %s" % (region_id, remote_account_id, recorder_status['name'], recorder_status['lastStatus']))
        else:
            logger.info("%s %s AWS Config Recorder not found, cannot delete." % (region_id, remote_account_id))

    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def check_aws_config(remote_account_id,
                     region_id,
                     remote_role,
                     session_name):
    try:

        ssm_session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        session_name, region_id)
        config_client = ssm_session_assumed.client('config')
        name='vaec-aws-inspector'+remote_account_id
        recorder_response = config_client.describe_configuration_recorders()
        del_channel_response = config_client.describe_delivery_channels()
        if recorder_response['ConfigurationRecorders']:
            for recorder in recorder_response['ConfigurationRecorders']:
                recorder_status_response = config_client.describe_configuration_recorder_status(
                                                ConfigurationRecorderNames=[recorder['name']])
                recorder_status=recorder_status_response['ConfigurationRecordersStatus'][0]
                if recorder_status['recording']:
                    logger.info("%s %s AWS Config Recorder is enabled - Name: %s, Recorder status: %r, Operation Status: %s, Role ARN: %s, s3Bucket: %s" \
                                 % (remote_account_id, region_id, \
                                 recorder_status['name'], \
                                 recorder_status['recording'], \
                                 recorder_status['lastStatus'], \
                                 recorder['roleARN'], \
                                 del_channel_response['DeliveryChannels'][0]['s3BucketName']))
                else:
                    logger.info("%s %s AWS Config Recorder is NOT enabled - Name: %s, Recorder status: %r -------" \
                                     % (remote_account_id, region_id, \
                                     recorder_status['name'], \
                                     recorder_status['recording']))
        else:
            logger.info("%s %s AWS Config Recorder not found" % (region_id, remote_account_id))
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def is_aws_config_recorder_enabled(config_client):
    returnValue=False
    try:
        response = config_client.describe_configuration_recorder_status()
        #print(response)
        for recorder in response['ConfigurationRecordersStatus']:
            if recorder['recording'] == True:
                returnValue=True
                break
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return returnValue

#---------------------------------------------------------------------------
def create_aws_config_recorder(config_client,
                               recorder_name,
                               config_role_arn,
                               s3_bucket_name,
                               delivery_frequency):

    try:
        logger.info("Creating configuration recorder: " + config_role_arn)
        response = config_client.put_configuration_recorder(
                                    ConfigurationRecorder={
                                        'name': recorder_name,
                                        'roleARN': config_role_arn,
                                        'recordingGroup': {
                                            'allSupported': True,
                                            'includeGlobalResourceTypes': True
                                        }
                                    }
                                )

        logger.info("Creating delivery channel: " + s3_bucket_name)
        response = config_client.put_delivery_channel(
                                DeliveryChannel={
                                    'name': "vaec-delivery-channel",
                                    's3BucketName': s3_bucket_name,
                                    'configSnapshotDeliveryProperties': {
                                        'deliveryFrequency': delivery_frequency
                                    }
                                }
                            )
        logger.info("Starting recorder: " + recorder_name)
        response = config_client.start_configuration_recorder(ConfigurationRecorderName=recorder_name)
                            #'deliveryFrequency': 'One_Hour'|'Three_Hours'|'Six_Hours'|'Twelve_Hours'|'TwentyFour_Hours'

    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def update_aws_config_recorder(config_client,
                               existing_config_recorder,
                               recorder_status,
                               recorder_name,
                               config_role_arn,
                               s3_bucket_name,
                               delivery_frequency):

    try:
        logger.info("Updating existing config recorder: %s", existing_config_recorder['name'])
        #if not existing_config_recorder['roleARN'] == config_role_arn or not recorder_status['recording']:

        if not existing_config_recorder['roleARN'] == config_role_arn:
            logger.info("role mismatch, Updating existing config recorder")
            #logger.info("config_role_arn: " + config_role_arn)
            response = config_client.put_configuration_recorder(
                                    ConfigurationRecorder={
                                        'name': existing_config_recorder['name'],
                                        'roleARN': config_role_arn,
                                        'recordingGroup': {
                                            'allSupported': True,
                                            'includeGlobalResourceTypes': True
                                        }
                                    }
                                )

        del_channel_response = config_client.describe_delivery_channels()
        if del_channel_response['DeliveryChannels'] :
            del_channel=del_channel_response['DeliveryChannels'][0]
            status_response = config_client.describe_delivery_channel_status(DeliveryChannelNames=[del_channel['name']])
            #print(status_response['DeliveryChannelsStatus'])
            if status_response['DeliveryChannelsStatus'][0]['configStreamDeliveryInfo']['lastStatus']=='Failure' or not del_channel['s3BucketName']==s3_bucket_name:
                logger.info("bucket mismatch or delivery channel is in error status, recreating delivery channel")
                if recorder_status['recording']:
                    response = config_client.stop_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
                config_client.delete_delivery_channel(DeliveryChannelName=del_channel['name'])
                if 'snsTopicARN' in del_channel:
                    response = config_client.put_delivery_channel(
                                            DeliveryChannel={
                                                'name': del_channel['name'],
                                                's3BucketName': s3_bucket_name,
                                                'snsTopicARN': del_channel['snsTopicARN'],
                                                'configSnapshotDeliveryProperties': {
                                                    'deliveryFrequency': delivery_frequency
                                                }
                                            }
                                        )
                else:
                    response = config_client.put_delivery_channel(
                                            DeliveryChannel={
                                                'name': del_channel['name'],
                                                's3BucketName': s3_bucket_name,
                                                'configSnapshotDeliveryProperties': {
                                                    'deliveryFrequency': delivery_frequency
                                                }
                                            })

                    response = config_client.start_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
        else:
            #Delivery channel don't exist., Create one
            logger.info("Config recorder delivery channel not found, creating one")
            response = config_client.put_delivery_channel(
                                    DeliveryChannel={
                                        'name': "vaec-delivery-channel",
                                        's3BucketName': s3_bucket_name,
                                        'configSnapshotDeliveryProperties': {
                                            'deliveryFrequency': delivery_frequency
                                        }
                                    }
                                )


        recorder_status_response = config_client.describe_configuration_recorder_status(
                                        ConfigurationRecorderNames=[existing_config_recorder['name']])
        recorder_status=recorder_status_response['ConfigurationRecordersStatus'][0]
        if not recorder_status['recording']:
            logger.info("Recording is OFF, turning it ON")
            response = config_client.start_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
                            #'deliveryFrequency': 'One_Hour'|'Three_Hours'|'Six_Hours'|'Twelve_Hours'|'TwentyFour_Hours'

    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def delete_aws_config_recorder(config_client,
                               existing_config_recorder,
                               recorder_status,
                               recorder_name,
                               config_role_arn,
                               s3_bucket_name,
                               delivery_frequency):

    try:
        logger.info("Deleting existing config recorder: %s", existing_config_recorder['name'])
        response = config_client.stop_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
        config_client.delete_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
        #if not existing_config_recorder['roleARN'] == config_role_arn or not recorder_status['recording']:
        del_channel_response = config_client.describe_delivery_channels()

        if del_channel_response['DeliveryChannels'] :
            del_channel=del_channel_response['DeliveryChannels'][0]
            logger.info("Deleting existing config delivery channel: %s", del_channel['name'])
            config_client.delete_delivery_channel(DeliveryChannelName=del_channel['name'])

    except ClientError as ex:
        logger.exception(ex)
        raise ex

if __name__== "__main__":
  main(sys.argv)
