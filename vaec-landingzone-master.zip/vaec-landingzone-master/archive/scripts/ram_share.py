import boto3
import argparse
import logging
import os
import sys
import time
import sessionmod

logger = logging.getLogger()
from botocore.exceptions import ClientError

try:
  log_level= os.environ['LOG_LEVEL'].lower()
except:
  log_level = 'info'

if log_level.lower() == 'critical':
  logger.setLevel(logging.CRITICAL)
elif log_level.lower() == 'error':
  logger.setLevel(logging.ERROR)
elif log_level.lower() == 'warning':
  logger.setLevel(logging.WARNING)
elif log_level.lower() == 'info':
  logger.setLevel(logging.INFO)
elif log_level.lower() == 'debug':
  logger.setLevel(logging.DEBUG)
else:
  logger.setLevel(logging.NOTSET)


def share_resources(accountid,creds,resourceShareArn,ram_local,region):
 try:
  response = ram_local.associate_resource_share(
      resourceShareArn=resourceShareArn,
      principals=[
        accountid
      ]
  )
  #introduce delay
  time.sleep(20)
  ram_remote = boto3.client('ram',
               region_name=region,
               aws_access_key_id = creds['AccessKeyId'],
               aws_secret_access_key = creds['SecretAccessKey'],
               aws_session_token = creds['SessionToken'])

  paginator = ram_remote.get_paginator('get_resource_share_invitations')
  page_iterator = paginator.paginate()
  for page in page_iterator:
   for invitation in page['resourceShareInvitations']:
    print(invitation)
    if invitation['status'] == 'PENDING' and invitation['resourceShareArn'] == resourceShareArn:
      ram_remote.accept_resource_share_invitation(
        resourceShareInvitationArn=invitation['resourceShareInvitationArn']
      )
 except Exception as ex:
  logger.info(ex)
  print(ex,accountid)
  raise ex

def get_credentials(accountid,sts_client,role_name):

    try:
      AccepterRoleArn = ('arn:aws-us-gov:iam::%s:role/%s' % (accountid, role_name))
      assumedRoleObject = sts_client.assume_role(
                          RoleArn=AccepterRoleArn,
                          RoleSessionName="RoleToAuthorizeRoleCreation")
      credential = assumedRoleObject['Credentials']
      #print('STS Successful: ', accountid)
      return credential
    except Exception as ex:
      logger.info(ex)
      print(ex,accountid)
      raise ex

def get_ram_share_arn_from_ssm(boto3_session,
                          account_id,
                          ssm_param_name,
                          region_id):
    access_policy=None
    ram_share_arn=None
    try:
        logs_client = boto3_session.client("logs",region_name=region_id)
        ssm_client = boto3_session.client('ssm', region_name=region_id)
        response = ssm_client.get_parameter(Name=ssm_param_name)
        ram_share_arn = response['Parameter']['Value']
        print("SSM Parameter Name:>>>> "+ssm_param_name)
        print("ram_share_arn:>>>> "+ram_share_arn)

    except Exception as ex:
            logger.error(ex)
            raise ex
    return ram_share_arn
    
def main(argv):
  session_name=__file__.split('.py')[0].replace('/', '_')
  parser = argparse.ArgumentParser(description='RAM share from core-gov-internal')
  parser.add_argument('-a', '--account_id', help='Account ID', required=True)
  parser.add_argument('-r', '--role_name', help='Role Name', required=True)
  #parser.add_argument('-arn', '--RAM_SHARE_ARN', help='Resource Access Manager Share ARN', required=True)
  parser.add_argument('-region', '--AWS_REGION', help='AWS Region', required=True)

  args = parser.parse_args()

  try:
    ram_local = boto3.client('ram',region_name=args.AWS_REGION)
    sts_client = boto3.client('sts',region_name=args.AWS_REGION)
  except Exception as ex:
    logger.info(ex)
  #resourceShareArn=args.RAM_SHARE_ARN
  accountid = args.account_id
  remote_role = args.role_name
  region_id = args.AWS_REGION
  ssm_session_assumed = sessionmod.aws_session(
                  ("arn:aws-us-gov:iam::%s:role/%s" %(accountid, remote_role)),
                  session_name, region_id)
  tgw_ram_share_parameter_name="/vaec/ram/share-arn-tgw1"
  dns_rr_ram_share_parameter_name="/vaec/ram/share-arn-dns-rr1"
  tgw_ram_share_arn=get_ram_share_arn_from_ssm(ssm_session_assumed,
                            accountid,
                            tgw_ram_share_parameter_name,
                            region_id)
  dns_rr_ram_share_arn=get_ram_share_arn_from_ssm(ssm_session_assumed,
                            accountid,
                            dns_rr_ram_share_parameter_name,
                            region_id)

  #resourceShareArn='arn:aws-us-gov:ram:us-gov-west-1:348286891446:resource-share/94b57f54-4f17-7c84-9bcf-70999375b23c'

  # with open('account_list.txt') as f:
  #   file_data = f.read().splitlines()
  #
  # for accountid in file_data:
  creds = get_credentials(accountid,sts_client,args.role_name)
  if creds:
    share_resources(accountid,creds,tgw_ram_share_arn,ram_local,args.AWS_REGION)
    share_resources(accountid,creds,dns_rr_ram_share_arn,ram_local,args.AWS_REGION)


if __name__ == "__main__":
  main(sys.argv)
