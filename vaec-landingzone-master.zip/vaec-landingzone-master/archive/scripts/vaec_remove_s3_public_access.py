"""
#!/usr/bin/env python
 
Overview:
Removes S3 Public Access.

Params:
Account ID
Role Name

"""

import os
import sys
import boto3
import argparse


def main(argv):
    parser = argparse.ArgumentParser(description='Removes S3 Public Access.')
    parser.add_argument('-a', '--account_id', help='Account ID', required=True)
    parser.add_argument('-r', '--role_name', help='Role Name', required=True)

    args = parser.parse_args()

    """ Set up AWS Session + Client + Resources """
    s3control = boto3.client('s3control',
				    region_name='us-gov-west-1',
				    aws_access_key_id = os.environ['AWS_ACCESS_KEY_ID'],
				    aws_secret_access_key = os.environ['AWS_SECRET_ACCESS_KEY'],
				    aws_session_token = os.environ['AWS_SESSION_TOKEN'])	
				
    response = s3control.put_public_access_block(
				    PublicAccessBlockConfiguration={
					       'BlockPublicAcls': True,
					       'IgnorePublicAcls': True,
					       'BlockPublicPolicy': True,
					       'RestrictPublicBuckets': True
				    },
				    AccountId=args.account_id)

if __name__ == '__main__':
    main(sys.argv)
