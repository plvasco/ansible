import boto3
from botocore.exceptions import ClientError
import urllib2
import ssl
import sys

def get_args():
    if len(sys.argv) != 3:
        error_message = 'Please supply a total of 2 arguments to this script: ADFS URL and AWS Identity Provider Name'
        sys.exit(error_message)
    else:
        METADATA_URL=sys.argv[1]
        IDP_NAME=sys.argv[2]
        print('Running script with arguments:\n')
        print('METADATA_URL: {METADATA_URL}'.format(METADATA_URL=METADATA_URL))
        print('IDP_NAME: {IDP_NAME}'.format(IDP_NAME=IDP_NAME))
        return {
            'metadata_url': METADATA_URL,
            'idp_name': IDP_NAME
        }

def create_idp(metadata_url,idp_name):

    iam = boto3.client("iam",region_name='us-gov-west-1')

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    try:
        response = urllib2.urlopen(metadata_url, context=ctx)
    except ClientError as e:        
        print('Unable to fetch Federation Metadat from url: ',str(e))
        
    provider_xml = response.read()

    try:
        resp = iam.create_saml_provider(SAMLMetadataDocument=provider_xml,Name=idp_name)    
    except ClientError as e:
        raise

if __name__=='__main__':
    
    args = get_args()
    metadata_url = args['metadata_url']
    idp_name = args['idp_name']

    create_idp(metadata_url,idp_name)
