import argparse
import sys
import boto3
import sessionmod
from botocore.exceptions import ClientError

#python3 vaec_create_gd_acctlist.py --account-id 272417811699,477244352852,477194928391
#python3 vaec_create_gd_acctlist.py --gd-acctlist-file /tmp/mygd_acctlist.csv


parser = argparse.ArgumentParser(description='Create csv file for GuardDuty based on accounts active in AWS Organizations')
parser.add_argument('--role', dest='remote_role', required=False, default='vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or comma-separated list of account-id')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
parser.add_argument('--gd-acctlist-file', dest='gd_acctlist_file', default='/tmp/gd_acctlist.csv', help='Output file name, default=/tmp/gd_acctlist.csv')

args = parser.parse_args()

#---------------------------------------------------------------------------
def main(argv):
    try:
        region_id='us-gov-west-1'
        session_name=__file__.split('.py')[0].replace('/', '_')
        lsession_assumed = sessionmod.aws_session(
                    ("arn:aws-us-gov:iam::%s:role/%s" %('348286891446', 'vaec-authorizer-role')),
                    session_name, region_id)

        # Get list of active accounts in AWS Organizations with email
        lorgc = lsession_assumed.client('organizations')
        active_account_list = sessionmod.get_active_account_list_with_email(lorgc)
        
        f=open(args.gd_acctlist_file, 'w')
        for acct in active_account_list:
            if (args.remote_account_id == 'all') or (acct['Id'] in args.remote_account_id):
                f.write('%s,%s\n' % (acct['Id'], acct['Email']))

    except ClientError as ex:
        print(ex)
        raise ex

if __name__== "__main__":
  main(sys.argv)
