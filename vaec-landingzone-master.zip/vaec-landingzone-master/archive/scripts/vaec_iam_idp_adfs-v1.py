import boto3
import urllib3
import argparse
import logging
import sessionmod
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

# ----------------------------------------------------------------
#python3 vaec_iam_idp_adfs.py --account-id 477194928391 --action create --nodryrun
#python3 vaec_iam_idp_adfs.py --account-id 477194928391 --region us-gov-west-1 --action delete
#python3 vaec_iam_idp_adfs.py --account-id 460514156203 --region us-east-2 --action create --nodryrun


parser = argparse.ArgumentParser(description='Create or delete VAEC IDP ADFS for SSO')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', choices=['us-gov-west-1', 'us-east-2'], help='us-gov-west-1, us-east-2')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
parser.add_argument('--action', dest='action', required=True, choices=['create', 'delete'], help='create, delete')
parser.add_argument('--metadata-url', dest='metadata_url', default='https://prod.adfs.federation.va.gov/federationmetadata/2007-06/federationmetadata.xml', help='Metadata URL')
parser.add_argument('--idp-name', dest='idp_name', default='ADFS', help='VA ADFS IDP name')
args = parser.parse_args()

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)
        sessionmod.iterate_orgs_accounts(fn_iam_idp_adfs, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_iam_idp_adfs(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        iamc = session_assumed.client('iam')

        if args.action == 'create':
            logger.info('[Dryrun=%s],Create,%s,%s,%s,%s' %(args.to_dryrun, region, acctid, args.idp_name, args.metadata_url))
            if not args.to_dryrun:
                create_idp(iamc, args.metadata_url, args.idp_name)

        elif args.action == 'delete':
            logger.info('[Dryrun=%s],Delete,%s,%s,%s' %(args.to_dryrun, region, acctid, args.idp_name))
            if not args.to_dryrun:
                iamc.delete_saml_provider(SAMLProviderArn=("arn:%s:iam::%s:saml-provider/%s" %(sessionmod.get_partition(region),acctid,args.idp_name)))

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def create_idp(iamc, metadata_url, idp_name):
    try:
        # http=urllib3.PoolManager(cert_reqs='CERT_NONE')
        http=urllib3.PoolManager()
        r = http.request('GET', metadata_url)
        resp = iamc.create_saml_provider(SAMLMetadataDocument=str(r.data,'utf-8'), Name=idp_name)
        logger.info(resp)

    except ClientError as ex:
        logger.error(ex)
        if not ex.response['Error']['Code'] == 'EntityAlreadyExists':
            raise

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
