import boto3
from botocore.exceptions import ClientError

iam_client = boto3.client('iam',region_name='us-gov-west-1')

def update_password_policy():
    try:
        response = iam_client.update_account_password_policy(
            MinimumPasswordLength=14,
            RequireSymbols=True,
            RequireNumbers=True,
            RequireUppercaseCharacters=True,
            RequireLowercaseCharacters=True,
            AllowUsersToChangePassword=True,
            MaxPasswordAge=60,
            PasswordReusePrevention=24,
            HardExpiry=True
	)
        return response
    except ClientError as e:
        raise

if __name__=='__main__':
    update_password_policy()
