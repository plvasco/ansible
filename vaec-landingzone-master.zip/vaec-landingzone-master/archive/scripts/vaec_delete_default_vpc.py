import logging
import boto3
import json
import os
from botocore.exceptions import ClientError
def delete_vpc():
    setup_logging()
    response_data = {}
    # Get a list of regions and loop through them
    region_list = get_regions()
    log.info('Got regions! ' + str(region_list))
    for region in region_list:
        print("region: ", region)
        ec2 = boto3.client('ec2', region_name=region)
	    # Get the default VPC for that region
        resp = ec2.describe_vpcs(Filters=[{'Name': 'isDefault', 'Values': ['true']}])
        if len(resp['Vpcs']) == 0:
            print('No default VPCs')
            log.info('No default VPCs')
            continue
        vpc = str(resp['Vpcs'][0]['VpcId'])
	# For each subnet, delete it
        for subnet in get_subnets(vpc, ec2):
            try:
                ec2.delete_subnet(SubnetId=subnet)
                log.info('Deleted subnet %s' % subnet)
                print('Deleted subnet %s' % subnet)
            except ClientError as e:
                raise

	    # Find IGW for this VPC
        resp = ec2.describe_internet_gateways(Filters=[{'Name': 'attachment.vpc-id', 'Values': [vpc]}])
        if len(resp['InternetGateways']) == 0:
            log.info('No IGW!')
            print('No IGW!')
            break
        igw = str(resp['InternetGateways'][0]['InternetGatewayId'])
	# Detach and delete it
        try:
            ec2.detach_internet_gateway(InternetGatewayId=igw, VpcId=vpc)
            log.info('Detached IGW %s from %s' % (igw, vpc))
            ec2.delete_internet_gateway(InternetGatewayId=igw)
            log.info('Deleted IGW %s' % igw)
        except ClientError as e:
            raise
	    # Finally remove the VPC
        try:
            ec2.delete_vpc(VpcId=vpc)
            print('Deleted VPC %s' % vpc)
            log.info('Deleted VPC %s' % vpc)
        except ClientError as e:
            raise
	    # End loop

def get_regions():
    li = []
    ec2 = boto3.client('ec2', region_name='us-gov-west-1')
    for region in ec2.describe_regions()['Regions']:
	    li.append(region['RegionName'])
    return li
def get_subnets(vpc, ec2):
    li = []
    for s in ec2.describe_subnets(Filters=[{'Name': 'vpc-id', 'Values': [vpc]}])['Subnets']:
	    li.append(s['SubnetId'])
    return li
def setup_logging():
    global log
    log = logging.getLogger()
    log_levels = {'INFO': 20, 'WARNING': 30, 'ERROR': 40}
    if 'logging_level' in os.environ:
	    log_level = os.environ['logging_level'].upper()
	    if log_level in log_levels:
		    log.setLevel(log_levels[log_level])
	    else:
		    log.setLevel(log_levels['ERROR'])
		    log.error("The logging_level environment variable is not set \
					  to INFO, WARNING, or ERROR. \
					  The log level is set to ERROR")
    else:
	    log.setLevel(log_levels['ERROR'])
	    log.warning('The logging_level environment variable is not set. \
				  The log level is set to ERROR')
    log.info('Logging setup complete - set to log level ' +
			  str(log.getEffectiveLevel()))

if __name__=='__main__':
    delete_vpc()
