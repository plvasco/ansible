# GuardDuty

Scripts copied from [https://github.com/aws-samples/amazon-guardduty-multiaccount-scripts]

Updated to work in GovCloud:

Change
~~~
    sts_client = boto3.client('sts')
~~~
to 
~~~
    sts_client = boto3.client('sts', region_name ='us-gov-west-1')
~~~
