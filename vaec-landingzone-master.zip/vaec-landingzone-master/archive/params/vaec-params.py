#!/usr/bin/python

import paramsmod
import argparse
import sys

#Example single account
#python3 vaec-params.py --region us-gov-east-1 --account-id 477194928391
#python3 vaec-params.py --region us-gov-east-1 --param-file test.csv  --role vaec-authorizer-role --account-id 477194928391

#---------------------------------------------------------------------------
# Use this for updating parameters for single account

def main(argv):
    parser = argparse.ArgumentParser(description='Handles TGW VPC attachments in core - tags, attach, route')
    parser.add_argument('--role', dest='remote_role', required=False, default= 'vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
    parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
    parser.add_argument('--param-file', dest='param_file', required=False, default='parameter-store.csv.j2', help='CSV J2 file')
    parser.add_argument('--account-id', dest='remote_account_id', required=True, help='Remote account ID')
    args = parser.parse_args()

    # Provide empty values for Jinja parameters - which will cause them to be ignored
    account_params = {
        'pVAECId': '',
        'pProjectShort': '',
        'pProjectName': '',
        'pAppCode': '',
    }
    paramsmod.process_account(args.remote_account_id, args.region_id, args.remote_role, args.param_file, account_params)

if __name__== "__main__":
  main(sys.argv)
