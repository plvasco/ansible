#!/usr/bin/python

import boto3
import csv
import logging
import jinja2
from botocore.exceptions import ClientError

#CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger = logging.getLogger()
logger.addHandler(out_hdlr)
logger.setLevel(logging.INFO)


#---------------------------------------------------------------------------
def process_account(remote_account_id, region_id, remote_role, param_file, account_params):
    try:
        logger.debug("Remote account: %s Region: %s Account params: %s" % (remote_account_id, region_id, str(account_params)))

        ssm_session_assumed = aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        'ssm_params_session', region_id)
        ssm_client = ssm_session_assumed.client('ssm')
        
        logger.info("#-------\nRemote account:%s Region:%s" % (remote_account_id, region_id))

        with open(param_file, mode='r') as paramcsvj2:
            template = jinja2.Template(paramcsvj2.read())
            jinja_rendered_output = template.render(**account_params)
            paramreader = csv.DictReader(jinja_rendered_output.splitlines())

            for row in paramreader:
                process_parameter_row(ssm_client, row, region_id)
 
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
# Assume remote account role
def aws_session(role_arn, session_name, region):

    try:
        logger.debug("Assuming Cross Account Role: " + role_arn)
        sts_client = boto3.client('sts', region_name=region)
        response = sts_client.assume_role(RoleArn=role_arn, RoleSessionName=session_name)
        session = boto3.Session(
                        aws_access_key_id=response['Credentials']['AccessKeyId'],
                        aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                        aws_session_token=response['Credentials']['SessionToken'],
                        region_name=region)
        return session
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
# CFN_Parameter,Type,Description,Name,Value_us-gov-west-1,Value_us-gov-east-1
def process_parameter_row(ssm_client, parameter, awsregion):
    try:
        paramname=parameter['Name']
        paramvalue=parameter['Value_' + awsregion]
        paramtype=parameter['Type']
        
        # Ignore empty parameter Name or Value
        if paramname and paramvalue:

            # Check if parameter already exists
            try:
                response = ssm_client.get_parameter(Name=paramname)
                isfound=True
            except:
                isfound=False
            
            # If parameter already exists, check if it needs to be updated
            toput=True
            if (isfound and
                response['Parameter']['Name']  == paramname and
                response['Parameter']['Value'] == paramvalue and
                response['Parameter']['Type']  == paramtype):
                    logger.info("Skip %s (no update required)" % (paramname))
                    toput=False

            if toput:
                if isfound:
                    logger.info("Update %s '%s' '%s' '%s'" % (paramname, paramvalue, paramtype, parameter['Description']))
                else:
                    logger.info("Add %s '%s' '%s' '%s'" % (paramname, paramvalue, paramtype, parameter['Description']))

                response = ssm_client.put_parameter(
                                Name=paramname,
                                Description=parameter['Description'],
                                Value=paramvalue,
                                Type=paramtype,
                                Overwrite=True,
                                #AllowedPattern='string',
                                #Tier='Standard'
                            )
                response = ssm_client.add_tags_to_resource(
                                ResourceType='Parameter',
                                ResourceId=paramname,
                                Tags=[
                                    {
                                        'Key': 'managed-by',
                                        'Value': 'ECS'
                                    },
                                ]
                            )

    except ClientError as ex:
        logger.exception(ex)
        raise ex
