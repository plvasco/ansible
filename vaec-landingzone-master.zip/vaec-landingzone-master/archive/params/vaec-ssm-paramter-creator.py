#!/usr/bin/python

import boto3
import csv
import sys
import logging
import argparse
from botocore.exceptions import ClientError

#CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
logger = logging.getLogger()
logger.setLevel(logging.INFO)

#Example command to test this program is below
#python3 vaec-ssm-paramter-creator.py --region us-gov-east-1 --csvFileName test.csv  --remote_role vaec-authorizer-role --remote_account 477194928391


# dryrun=args.nodryrun
dryrun=False
ec2_client=None

# Function to assume remote account role
def aws_session(role_arn=None, session_name='my_session', region='us-gov-west-1'):
    """
    If role_arn is given assumes a role and returns boto3 session
    otherwise return a regular session with the current IAM user/role
    """

    try:
        if role_arn:
            print("Assuming Cross Account Role: " + role_arn)
            client = boto3.client('sts', region_name=region)
            response = client.assume_role(RoleArn=role_arn, RoleSessionName=session_name)
            session = boto3.Session(
                                    aws_access_key_id=response['Credentials']['AccessKeyId'],
                                    aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                    aws_session_token=response['Credentials']['SessionToken'])
            return session
        else:
            logger.debug("Assuming Local Account Role: ")
            return boto3.Session()
    except ClientError as e:
        logger.exception("Failed to get boto3 session object : %s" % e)
        raise e


#
#---------------------------------------------------------------------------

def main(argv):
    parser = argparse.ArgumentParser(description='Handles TGW VPC attachments in core - tags, attach, route')
    parser.add_argument('--nodryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled.')
    parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
    parser.add_argument('--csvFileName', dest='csvFileName', required=True, help='AWS Regionidentifier')
    parser.add_argument('--remote_role', dest='remote_role', required=True, help='AWS Regionidentifier')
    parser.add_argument('--remote_account', dest='remote_account', required=True, help='AWS Regionidentifier')
    args = parser.parse_args()
    try:
        cross_account_role_arn = "arn:aws-us-gov:iam::" + args.remote_account +":role/"+args.remote_role
        ssm_session_assumed = aws_session(role_arn=cross_account_role_arn, session_name='ssm_session', region=args.region_id)
        ssm_client = ssm_session_assumed.client('ssm', region_name=args.region_id)
        with open(args.csvFileName, mode='r') as csvfile:
            #csv_file_reader = csv.DictReader(csvfile)
            csv_file_reader = csv.reader(csvfile, delimiter=',')
            # Skip headers in csv file
            next(csv_file_reader)
            for parameter_row in csv_file_reader:
                logger.debug(parameter_row)
                process_parameter_row(ssm_client, parameter_row)
    except ClientError as e:
        logger.exception("Failed to get boto3 session object : %s" % e)
        raise e

def process_parameter_row(ssm_client, parameter):
    try:
        #CFN_Parameter,CFN_Parameter_Type,Parameter_Description,Parameter_Key,Parameter_Value,Region
        response = ssm_client.put_parameter(
                            Name=parameter[3],
                            Description=parameter[2],
                            Value=parameter[4],
                            Type=parameter[1],
                            #Type='String'|'StringList'|'SecureString',
                            #KeyId='string',
                            Overwrite=True,
                            #AllowedPattern='string',
                            #Tier='Standard'
                        )
        response = ssm_client.add_tags_to_resource(
                        ResourceType='Parameter',
                        ResourceId=parameter[3],
                        Tags=[
                            {
                                'Key': 'managed-by',
                                'Value': 'ECS'
                            },
                        ]
                    )

    except ClientError as e:
        logger.exception("Failed to get boto3 session object : %s" % e)
        raise e



if __name__== "__main__":
  main(sys.argv)
