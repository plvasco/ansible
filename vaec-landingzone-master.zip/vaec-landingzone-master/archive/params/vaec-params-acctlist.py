#!/usr/bin/python

import paramsmod
import argparse
import sys
import csv
from botocore.exceptions import ClientError

#Example account list
#python3 vaec-params-acctlist.py --region us-gov-east-1 --account-list-file acct-list-test.csv
#python3 vaec-params-acctlist.py --region us-gov-west-1 --param-file test.csv --account-list-file acct-list-test.csv

#---------------------------------------------------------------------------
# Use this for updating parameters for multiple accounts -- provide csv account list with values for Jinja parameter substitution

def main(argv):
    parser = argparse.ArgumentParser(description='Add or update SSM Parameter Store in specific region and account list')
    parser.add_argument('--role', dest='remote_role', required=False, default= 'vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
    parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
    parser.add_argument('--param-file', dest='param_file', required=False, default='parameter-store.csv.j2', help='Parameter CSV J2 file')
    parser.add_argument('--account-list-file', dest='account_list_file', default='VAEC-AWS-Accounts.csv', help='AWS account list CSV file')
    args = parser.parse_args()

    try:
        with open(args.account_list_file, mode='r') as accountlistcsv:
            accountlistreader = csv.DictReader(accountlistcsv)
            for account_row in accountlistreader:
                account_params = {
                    'pVAECId': account_row['VAECID'],
                    'pProjectShort': account_row['ProjectShort'],
                    'pProjectName': account_row['ProjectName'],
                    'pAppCode': account_row['AppCode'],
                }
                
                if account_row['AccountStatus'].strip().lower() == 'active':
                    paramsmod.process_account(account_row['GovCloudNum'], args.region_id, args.remote_role, args.param_file, account_params)

    except ClientError as ex:
        logger.exception(ex)
        raise ex

if __name__== "__main__":
  main(sys.argv)
