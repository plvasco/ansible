#!/usr/bin/python

import boto3
import csv
import sys
import logging
import argparse
import jinja2
from botocore.exceptions import ClientError

#CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
logger = logging.getLogger()
logger.setLevel(logging.INFO)
# Jenkins - load_ssm_params_all_accounts

#Example single account
#python3 vaec-params.py --region us-gov-east-1 --account-id 477194928391
#python3 vaec-params.py --region us-gov-east-1 --param-file test.csv  --role vaec-authorizer-role --account-id 477194928391

#Example account list
#python3 vaec-params.py --region us-gov-east-1 --account-list-file acct-list-test.csv
#python3 vaec-params.py --region us-gov-west-1 --param-file test.csv --account-list-file acct-list-test.csv


#---------------------------------------------------------------------------
# Function to assume remote account role
def aws_session(role_arn, session_name, region):

    try:
        logger.debug("Assuming Cross Account Role: " + role_arn)
        sts_client = boto3.client('sts', region_name=region)
        response = sts_client.assume_role(RoleArn=role_arn, RoleSessionName=session_name)
        session = boto3.Session(
                        aws_access_key_id=response['Credentials']['AccessKeyId'],
                        aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                        aws_session_token=response['Credentials']['SessionToken'])
        return session
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
# Use this for updating parameters for single account

def main_single_account(argv):
    parser = argparse.ArgumentParser(description='Handles TGW VPC attachments in core - tags, attach, route')
    parser.add_argument('--role', dest='remote_role', required=False, default= 'vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
    parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
    parser.add_argument('--param-file', dest='param_file', required=False, default='parameter-store.csv.j2', help='CSV J2 file')
    parser.add_argument('--account-id', dest='remote_account_id', required=True, help='Remote account ID')
    args = parser.parse_args()

    # Provide empty values for Jinja parameters - which will cause them to be ignored
    account_params = {
        'pVAECId': '',
        'pProjectShort': '',
        'pProjectName': '',
        'pAppCode': '',
    }
    logger.debug("Remote account: %s Region: %s Account params: %s" % (args.remote_account_id, args.region_id, str(account_params)))
    process_account(args.remote_account_id, args.region_id, args.remote_role, args.param_file, account_params)


#---------------------------------------------------------------------------
# Use this for updating parameters for multiple accounts -- provide csv account list with values for Jinja parameter substitution

def main(argv):
    parser = argparse.ArgumentParser(description='Add or update SSM Parameter Store in specific region and account list')
    parser.add_argument('--role', dest='remote_role', required=False, default= 'vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
    parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
    parser.add_argument('--param-file', dest='param_file', required=False, default='parameter-store.csv.j2', help='Parameter CSV J2 file')
    parser.add_argument('--account-list-file', dest='account_list_file', default='VAEC-AWS-Accounts.csv', help='AWS account list CSV file')
    args = parser.parse_args()

    try:
        with open(args.account_list_file, mode='r') as accountlistcsv:
            accountlistreader = csv.DictReader(accountlistcsv)
            for account_row in accountlistreader:
                account_params = {
                    'pVAECId': account_row['VAECID'],
                    'pProjectShort': account_row['ProjectShort'],
                    'pProjectName': account_row['ProjectName'],
                    'pAppCode': account_row['AppCode'],
                }
                logger.debug("Remote account: %s Region: %s Account params: %s" % (account_row['GovCloud#'], args.region_id, str(account_params)))
                process_account(account_row['GovCloud#'], args.region_id, args.remote_role, args.param_file, account_params)

    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def process_account(remote_account_id, region_id, remote_role, param_file, account_params):
    try:
        ssm_session_assumed = aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),'ssm_session', region_id)
        ssm_client = ssm_session_assumed.client('ssm', region_name=region_id)
        
        print("#-------\nRemote account:%s Region:%s" % (remote_account_id, region_id))

        with open(param_file, mode='r') as paramcsvj2:
            template = jinja2.Template(paramcsvj2.read())
            jinja_rendered_output = template.render(**account_params)
            paramreader = csv.DictReader(jinja_rendered_output.splitlines())

            for row in paramreader:
                process_parameter_row(ssm_client, row, region_id)
 
    except ClientError as ex:
        logger.exception(ex)
        raise ex


#---------------------------------------------------------------------------
# CFN_Parameter,Type,Description,Name,Value_us-gov-west-1,Value_us-gov-east-1

def process_parameter_row(ssm_client, parameter, awsregion):
    try:
        paramname=parameter['Name']
        paramvalue=parameter['Value_' + awsregion]
        paramtype=parameter['Type']
        
        # Ignore empty parameter Name or Value
        if paramname and paramvalue:

            # Check if parameter already exists
            try:
                response = ssm_client.get_parameter(Name=paramname)
                isfound=True
            except:
                isfound=False
            
            # If parameter already exists, check if it needs to be updated
            toput=True
            if (isfound and
                response['Parameter']['Name']  == paramname and
                response['Parameter']['Value'] == paramvalue and
                response['Parameter']['Type']  == paramtype):
                    print("Skip %s (no update required)" % (paramname))
                    toput=False

            if toput:
                if isfound:
                    print("Update %s '%s' '%s' '%s'" % (paramname, paramvalue, paramtype, parameter['Description']))
                else:
                    print("Add %s '%s' '%s' '%s'" % (paramname, paramvalue, paramtype, parameter['Description']))

                response = ssm_client.put_parameter(
                                Name=paramname,
                                Description=parameter['Description'],
                                Value=paramvalue,
                                Type=paramtype,
                                Overwrite=True,
                                #AllowedPattern='string',
                                #Tier='Standard'
                            )
                response = ssm_client.add_tags_to_resource(
                                ResourceType='Parameter',
                                ResourceId=paramname,
                                Tags=[
                                    {
                                        'Key': 'managed-by',
                                        'Value': 'ECS'
                                    },
                                ]
                            )

    except ClientError as ex:
        logger.exception(ex)
        raise ex


if __name__== "__main__":
  main(sys.argv)
