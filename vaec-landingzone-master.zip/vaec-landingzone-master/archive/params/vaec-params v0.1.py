#!/usr/bin/python

import boto3
import csv
import sys
import logging
import argparse
from botocore.exceptions import ClientError

#CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
logger = logging.getLogger()
logger.setLevel(logging.INFO)
# Jenkins - load_ssm_params_all_accounts

#Example command to test this program is below
#python3 vaec-ssm-paramter-creator.py --region us-gov-east-1 --paramfile test.csv  --role vaec-authorizer-role --account-id 477194928391


#---------------------------------------------------------------------------
# Function to assume remote account role
def aws_session(role_arn, session_name, region):

    try:
#        print("Assuming Cross Account Role: " + role_arn)
        sts_client = boto3.client('sts', region_name=region)
        response = sts_client.assume_role(RoleArn=role_arn, RoleSessionName=session_name)
        session = boto3.Session(
                        aws_access_key_id=response['Credentials']['AccessKeyId'],
                        aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                        aws_session_token=response['Credentials']['SessionToken'])
        return session
    except ClientError as ex:
        logger.exception(ex)
        raise ex


#---------------------------------------------------------------------------

def main(argv):
    parser = argparse.ArgumentParser(description='Handles TGW VPC attachments in core - tags, attach, route')
    parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
    parser.add_argument('--paramfile', dest='paramfile', required=False, default='parameter-store.csv.j2', help='CSV J2 file')
    parser.add_argument('--role', dest='remote_role', required=False, default= 'vaec-authorizer-role', help='IAM authorizer role from remote AWS account ID')
    parser.add_argument('--account-id', dest='remote_account_id', required=True, help='Remote account ID')
    args = parser.parse_args()
    try:
        awsregion=args.region_id
        ssm_session_assumed = aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(args.remote_account_id, args.remote_role)),'ssm_session', awsregion)
        ssm_client = ssm_session_assumed.client('ssm', region_name=args.region_id)
        
        print("#-------\nRemote account:%s Region:%s" % (args.remote_account_id, awsregion))
        with open(args.paramfile, mode='r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                    process_parameter_row(ssm_client, dict(row), awsregion)
 
    except ClientError as ex:
        logger.exception(ex)
        raise ex


#---------------------------------------------------------------------------
# CFN_Parameter,Type,Description,Name,Value_us-gov-west-1,Value_us-gov-east-1

def process_parameter_row(ssm_client, parameter, awsregion):
    try:
        paramname=parameter['Name']
        paramvalue=parameter['Value_' + awsregion]
        paramtype=parameter['Type']
        
        if paramname and paramvalue:
            try:
                response = ssm_client.get_parameter(Name=paramname)
                isfound=True
            except:
                isfound=False
            
            toput=True
            if (isfound and
                response['Parameter']['Name']  == paramname and
                response['Parameter']['Value'] == paramvalue and
                response['Parameter']['Type']  == paramtype):
                    print("Skip %s (no update required)" % (paramname))
                    toput=False
            
            if toput:
                    if isfound:
                        print("Update %s '%s' '%s' '%s'" % (paramname, paramvalue, paramtype, parameter['Description']))
                    else:
                        print("Add %s '%s' '%s' '%s'" % (paramname, paramvalue, paramtype, parameter['Description']))

                    # response = ssm_client.put_parameter(
                                    # Name=paramname,
                                    # Description=parameter['Description'],
                                    # Value=paramvalue,
                                    # Type=paramtype,
                                    # Overwrite=True,
                                    # #AllowedPattern='string',
                                    # #Tier='Standard'
                                # )
                    # response = ssm_client.add_tags_to_resource(
                                    # ResourceType='Parameter',
                                    # ResourceId=paramname,
                                    # Tags=[
                                        # {
                                            # 'Key': 'managed-by',
                                            # 'Value': 'ECS'
                                        # },
                                    # ]
                                # )

    except ClientError as ex:
        logger.exception(ex)
        raise ex


if __name__== "__main__":
  main(sys.argv)
