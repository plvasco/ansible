#!/usr/bin/python

import boto3
import csv
import sys
import logging
import argparse
import jinja2
from botocore.exceptions import ClientError

#CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

#Example command to test this program is below
#python3 vaec-ssm-paramter-creator.py --region us-gov-east-1 --csvFileName test.csv  --remote_role vaec-authorizer-role --remote_account 477194928391


# dryrun=args.nodryrun
dryrun=False
ec2_client=None

# Function to assume remote account role
def aws_session(role_arn=None, session_name='my_session', region='us-gov-west-1'):
    """
    If role_arn is given assumes a role and returns boto3 session
    otherwise return a regular session with the current IAM user/role
    """

    try:
        if role_arn:
            print("Assuming Cross Account Role: " + role_arn)
            client = boto3.client('sts', region_name=region)
            response = client.assume_role(RoleArn=role_arn, RoleSessionName=session_name)
            session = boto3.Session(
                                    aws_access_key_id=response['Credentials']['AccessKeyId'],
                                    aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                                    aws_session_token=response['Credentials']['SessionToken'])
            return session
        else:
            logger.debug("Assuming Local Account Role: ")
            return boto3.Session()
    except ClientError as e:
        logger.exception("Failed to get boto3 session object : %s" % e)
        raise e


#
#---------------------------------------------------------------------------

def main(argv):
    parser = argparse.ArgumentParser(description='Handles TGW VPC attachments in core - tags, attach, route')
    parser.add_argument('--nodryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled.')
    parser.add_argument('--region', dest='region_id', required=True, help='AWS Region identifier')
    parser.add_argument('--csvJinjaFileName', dest='csvJinjaFileName', required=True, help='CSV based Parameter file with jina parameters')
    parser.add_argument('--csvAccountList', dest='csvAccountList', required=True, help='CSV Based account List')
    parser.add_argument('--remote_role', dest='remote_role', required=True, help='AWS Regionidentifier')
    #parser.add_argument('--remote_account', dest='remote_account', required=True, help='AWS Regionidentifier')
    args = parser.parse_args()
    try:
        with open(args.csvAccountList, mode='r') as csvAccountfile:
            csv_account_list_reader = csv.reader(csvAccountfile, delimiter=',')
            # Skip headers in csv file
            next(csv_account_list_reader)
            for account_row in csv_account_list_reader:
                remote_account = account_row[2]
                vaec_id = account_row[4]
                project_short = account_row[5]
                project_name = account_row[6]
                logger.debug("remote_account: " + remote_account + ", vaec_id: " + vaec_id +", project_short: " + project_short + ", project_name: " + project_name)

                account_params = {
                'pProjectShort': project_short,
                'pProjectName': project_name,
                'pVAECId': vaec_id
                }
                with open(args.csvJinjaFileName) as jinja_csv_file:
                    template = jinja2.Template(jinja_csv_file.read())
                    jinja_rendered_output = template.render(**account_params)
                    #logger.debug(output)
                    cross_account_role_arn = "arn:aws-us-gov:iam::" + remote_account +":role/"+args.remote_role
                    ssm_session_assumed = aws_session(role_arn=cross_account_role_arn, session_name='ssm_session', region=args.region_id)
                    ssm_client = ssm_session_assumed.client('ssm', region_name=args.region_id)
                    csv_file_reader = csv.reader(jinja_rendered_output.splitlines(), delimiter=',')
                    # Skip headers in csv file
                    next(csv_file_reader)
                    for parameter_row in csv_file_reader:
                        print(parameter_row)
                        logger.debug(parameter_row)
                        process_parameter_row(ssm_client, parameter_row)
    except ClientError as e:
        logger.exception("Failed to get boto3 session object : %s" % e)
        raise e

def process_parameter_row(ssm_client, parameter):
    try:
        #CFN_Parameter,CFN_Parameter_Type,Parameter_Description,Parameter_Key,Parameter_Value,Region
        response = ssm_client.put_parameter(
                            Name=parameter[3],
                            Description=parameter[2],
                            Value=parameter[4],
                            Type=parameter[1],
                            #Type='String'|'StringList'|'SecureString',
                            #KeyId='string',
                            Overwrite=True,
                            #AllowedPattern='string',
                            #Tier='Standard'
                        )
        response = ssm_client.add_tags_to_resource(
                        ResourceType='Parameter',
                        ResourceId=parameter[3],
                        Tags=[
                            {
                                'Key': 'managed-by',
                                'Value': 'ECS'
                            },
                        ]
                    )

    except ClientError as e:
        logger.exception("Failed to get boto3 session object : %s" % e)
        raise e



if __name__== "__main__":
  main(sys.argv)
