# vaec-landingzone
VAEC Landingzone to be deployed across all AWS accounts

