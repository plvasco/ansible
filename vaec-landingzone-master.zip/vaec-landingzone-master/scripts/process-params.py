import argparse
import sys
import boto3
import sessionmod
import tagmod
import paramsmod
import os
import logging
from botocore.exceptions import ClientError

## Module defaults
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger = logging.getLogger(__name__)
logger.addHandler(out_hdlr)
logger.setLevel(logging.INFO)

#python3 process-params.py --region us-gov-east-1 --account-id 477194928391,272417811699
#python3 process-params.py --account-id 477194928391,272417811699

parser = argparse.ArgumentParser(description='Process Parameter Store key-value pairs for account/s')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
parser.add_argument('--param-file', dest='param_file', required=False, default='parameter-store.csv.j2', help='CSV J2 file')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or csv delimited account-id')
parser.add_argument('--force', dest='to_enforce', action='store_true', default=False, help='Force changing parameter values if different, Default is disabled')
args = parser.parse_args()

paramsmod.to_enforce = args.to_enforce

#---------------------------------------------------------------------------

def main(argv):
    try:
        # logger.debug(args)
        paramsmod.to_dryrun = args.to_dryrun
        lsession_assumed = sessionmod.aws_session3(sessionmod.get_orgs_mgmt_account('us-gov-west-1'), 'us-gov-west-1')
        lorgc = lsession_assumed.client('organizations')

        if os.path.exists(args.param_file):
            sessionmod.iterate_orgs_accounts(process_account_all_parameters,args.remote_account_id, args.region_id,  lorgc)
        else:
            logger.error('Parameter file does not exist: %s' %(args.param_file))
            sys.exit(1)

    except Exception as ex:
        print(ex)

#---------------------------------------------------------------------------
# Update Parameter Store for single account

def process_account_all_parameters(acctid, region, lorgc):
    # Get tags from Org member
    existing_tag_dict = tagmod.tags_list2dict(
                            tagmod.get_tags_from_orgs_resource(lorgc, acctid))
    account_params = {}
    account_params['pProjectShort'] = existing_tag_dict.get('vaec:ProjectShort', '')
    account_params['pProjectName'] = existing_tag_dict.get('vaec:ProjectName', '')
    account_params['pVAECId'] = existing_tag_dict.get('vaec:VAECID', '')
    account_params['pCKId'] = existing_tag_dict.get('vaec:CKID', '')
    account_params['pAppCode'] = existing_tag_dict.get('vaec:AppCode', '')

    paramsmod.process_account_parameters(acctid, region, args.param_file, account_params)

if __name__== "__main__":
  main(sys.argv)
