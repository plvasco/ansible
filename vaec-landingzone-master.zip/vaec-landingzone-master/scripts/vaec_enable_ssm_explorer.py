import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_enable_ssm_explorer.py
#python3 vaec_enable_ssm_explorer.py --account-id all --region all
#python3 vaec_enable_ssm_explorer.py --account-id 477194928391,272417811699 --region all

parser = argparse.ArgumentParser(description='VAEC enable SSM Explorer')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or comma separated list of account-ids')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')
args = parser.parse_args()

# ----------------------------------------------------------------
ssm_explorer_settings= [
        {"SettingId": "/ssm/opsdata/ExplorerOnboarded",
         "SettingValue": 'true'
        },
        {"SettingId": "/ssm/opsdata/ManagedInstance",
         "SettingValue": "Enabled"
        },
        {"SettingId": "/ssm/opsitem/ssm-patchmanager",
         "SettingValue": "Enabled"
        },
        {"SettingId": "/ssm/opsitem/EC2",
         "SettingValue": "Enabled"
        },
        {"SettingId": "/ssm/opsdata/OpsData-TrustedAdvisor",
         "SettingValue": "Enabled"
        }
    ]

ssm_role= 'AWSServiceRoleForAmazonSSM'

# ----------------------------------------------------------------

def main():
    try:
        # logger.debug(args)

        session_name=__file__.split('.py')[0].replace('/', '_')
        sessionmod.iterate_orgs_accounts(fn_enable_ssm_explorer, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_enable_ssm_explorer(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)

        # aws-service-role
        iamc = session_assumed.client('iam')
        service_role_exists = False
        list_roles = iamc.list_roles()
        for role in list_roles['Roles']:
            if role['RoleName'] == ssm_role:
                service_role_exists = True

        if not service_role_exists:
            response = iamc.create_service_linked_role(AWSServiceName='ssm.amazonaws.com')
            logger.info("%s %s - created %s" %(region, acctid, response['Role']['Arn']))
        else:
            logger.info("%s %s - IAM Role %s already exists" %(region, acctid, ssm_role))

        # SSM Explorer settings
        rssmc = session_assumed.client('ssm')
        for s in ssm_explorer_settings:
            response = rssmc.update_service_setting(SettingId=s['SettingId'], SettingValue=s['SettingValue'])
            logger.info("%s %s set %s = %s" %(region, acctid, s['SettingId'], s['SettingValue']))

    except Exception as ex:
        logger.error(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
