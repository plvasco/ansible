import argparse
import boto3
import logging
import sessionmod
import paramsmod

out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger = logging.getLogger(__name__)
logger.addHandler(out_hdlr)
logger.setLevel(logging.INFO)

# python3 delete-params.py --account-id 477194928391,272417811699 --region us-gov-west-1 --param-name 'vaec/temp/temp1'
# python3 delete-params.py --account-id 477194928391,272417811699 --param-path 'vaec/temp'

parser = argparse.ArgumentParser(description='Delete SSM parameters')
parser.add_argument('--account-id', dest='remote_account_id', required=True,  help='comma-separated account-id')
parser.add_argument('--region', dest='region_id', required=True, help='all or comma-separated region-id')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
group = parser.add_mutually_exclusive_group(required=True)
group.add_argument('--param-name', dest='param_name', help='comma-separated list of SSM Parameter names')
group.add_argument('--param-path', dest='param_path', help='Parameter path')

args = parser.parse_args()

if args.param_name:
    param_name_list = [x.strip() for x in args.param_name.split(',')]

paramsmod.to_dryrun = args.to_dryrun

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        if args.remote_account_id == 'all':
            logger.error("To prevent accidental deletion across accounts, --account-id = all is disabled")
        else:
            sessionmod.iterate_orgs_accounts(fn_vaec_delete_parameters, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_vaec_delete_parameters(acctid, region):
    try:
        logger.info('%s,%s' %(region, acctid))
        session_assumed = sessionmod.aws_session3(acctid, region)
        ssmc = session_assumed.client('ssm')

        if args.param_name:
            paramsmod.delete_parameters_by_name(ssmc, param_name_list)
        elif args.param_path:
            paramsmod.delete_parameters_by_path(ssmc, args.param_path)

    except Exception as ex:
        logger.error('%s,%s,%s' %(region, acctid, ex))

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
