import boto3
import urllib3
import argparse
import logging
import sessionmod
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

# ----------------------------------------------------------------
#python3 vaec_iam_idp_adfs.py --account-id 477194928391 --action create --nodryrun
#python3 vaec_iam_idp_adfs.py --account-id 477194928391 --region us-gov-west-1 --action delete
#python3 vaec_iam_idp_adfs.py --account-id 460514156203 --region us-east-2 --action update --nodryrun


parser = argparse.ArgumentParser(description='Create or delete VAEC IDP ADFS for SSO')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or account-id')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', choices=['us-gov-west-1', 'us-east-2'], help='us-gov-west-1, us-east-2')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
parser.add_argument('--action', dest='action', required=True, choices=['create', 'delete', 'update'], help='create, delete, update')
parser.add_argument('--metadata-url', dest='metadata_url', default='https://prod.adfs.federation.va.gov/federationmetadata/2007-06/federationmetadata.xml', help='Metadata URL')
parser.add_argument('--idp-name', dest='idp_name', default='ADFS', help='VA ADFS IDP name')
args = parser.parse_args()

idp_name = args.idp_name.strip()
metadata_url = args.metadata_url.strip()
saml_metadata_doc = None

if args.action in ['create', 'update']:
    http = urllib3.PoolManager()
    r = http.request('GET', metadata_url)
    saml_metadata_doc = str(r.data,'utf-8')

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)
        sessionmod.iterate_orgs_accounts(fn_iam_idp_adfs, args.remote_account_id, args.region_id)

    except Exception as ex:
        raise(ex)

# ----------------------------------------------------------------
def fn_iam_idp_adfs(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)
        iamc = session_assumed.client('iam')
        saml_provider_arn=('arn:{}:iam::{}:saml-provider/{}'.format(sessionmod.get_partition(region), acctid, idp_name))

        if args.action == 'create':
            logger.info('[Dryrun={}],{},{},{},{},{}'.format(args.to_dryrun, args.action, region, acctid, idp_name, metadata_url))
            if not args.to_dryrun:
                resp = iamc.create_saml_provider(SAMLMetadataDocument=saml_metadata_doc, Name=idp_name)
                logger.info(resp)

        elif args.action == 'update':
            logger.info('[Dryrun={}],{},{},{},{},{}'.format(args.to_dryrun, args.action, region, acctid, saml_provider_arn, metadata_url))
            if not args.to_dryrun:
                resp = iamc.update_saml_provider(SAMLMetadataDocument=saml_metadata_doc, SAMLProviderArn=saml_provider_arn)
                logger.info(resp)

        elif args.action == 'delete':
            logger.info('[Dryrun={}],{},{},{},{}'.format(args.to_dryrun, args.action, region, acctid, saml_provider_arn))
            if not args.to_dryrun:
                iamc.delete_saml_provider(SAMLProviderArn=saml_provider_arn)

    except Exception as ex:
        logger.error(ex)


# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
