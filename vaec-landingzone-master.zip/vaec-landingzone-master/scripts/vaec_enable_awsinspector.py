import argparse
import sys
import boto3
import sessionmod
from botocore.exceptions import ClientError
import logging

#python3 vaec_create_gd_acctlist.py --account-id 272417811699,477244352852,477194928391
#python3 vaec_create_gd_acctlist.py --gd-acctlist-file /tmp/mygd_acctlist.csv


parser = argparse.ArgumentParser(description='Create csv file for GuardDuty based on accounts active in AWS Organizations')
parser.add_argument('--role', dest='remote_role', required=False, default='vaec-authorizer-role', help='IAM authorizer role from remote AWS account')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or comma-separated list of account-id')
parser.add_argument('--action', dest='action', default='check', help='check or enable. whether AWS Inspector is already enable. Default is enabled')
parser.add_argument('--sns-topic-name', dest='sns_topic_name', required=True, help='SNS Topic name for AWS Inspector findings')
parser.add_argument('--sns-email-subscriber', dest='sns_email_subscriber', required=True, help='SNS Email Subscriber for AWS Inspector findings')
parser.add_argument('--enable-inspector-tags', dest='enable_inspector_tags', action='store_true', default=False, help='Add Tags for Inspector Assessment. Default is disabled')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')


args = parser.parse_args()
## Module defaults
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger = logging.getLogger()
logger.addHandler(out_hdlr)
logger.setLevel(logging.INFO)

inspector_name='vaec-inspector'

rule_package_arn={"us-west-1" : ['arn:aws:inspector:us-west-1:166987590008:rulespackage/0-TKgzoVOa',
                                'arn:aws:inspector:us-west-1:166987590008:rulespackage/0-xUY8iRqX',
                                'arn:aws:inspector:us-west-1:166987590008:rulespackage/0-TxmXimXF',
                                'arn:aws:inspector:us-west-1:166987590008:rulespackage/0-byoQRFYm',
                                'arn:aws:inspector:us-west-1:166987590008:rulespackage/0-yeYxlt0x'],
                  "us-west-2" :  ['arn:aws:inspector:us-west-2:758058086616:rulespackage/0-9hgA516p',
                               'arn:aws:inspector:us-west-2:758058086616:rulespackage/0-H5hpSawc',
                               'arn:aws:inspector:us-west-2:758058086616:rulespackage/0-rD1z6dpl',
                               'arn:aws:inspector:us-west-2:758058086616:rulespackage/0-JJOtZiqQ',
                               'arn:aws:inspector:us-west-2:758058086616:rulespackage/0-vg5GGHSD'],
                  "us-east-1":  ['arn:aws:inspector:us-east-1:316112463485:rulespackage/0-gEjTy7T7'
                              'arn:aws:inspector:us-east-1:316112463485:rulespackage/0-rExsr2X8'
                              'arn:aws:inspector:us-east-1:316112463485:rulespackage/0-PmNV0Tcd'
                              'arn:aws:inspector:us-east-1:316112463485:rulespackage/0-R01qwB5Q'
                              'arn:aws:inspector:us-east-1:316112463485:rulespackage/0-gBONHN9h'],
                  "us-east-2": ['arn:aws:inspector:us-east-2:646659390643:rulespackage/0-JnA8Zp85'
                                'arn:aws:inspector:us-east-2:646659390643:rulespackage/0-m8r61nnh'
                                'arn:aws:inspector:us-east-2:646659390643:rulespackage/0-cE4kTR30'
                                'arn:aws:inspector:us-east-2:646659390643:rulespackage/0-AxKmMHPX'
                                'arn:aws:inspector:us-east-2:646659390643:rulespackage/0-UCYZFKPV'],
                 "us-gov-east-1": ['arn:aws-us-gov:inspector:us-gov-east-1:206278770380:rulespackage/0-3IFKFuOb'
                                  'arn:aws-us-gov:inspector:us-gov-east-1:206278770380:rulespackage/0-pTLCdIww',
                                  'arn:aws-us-gov:inspector:us-gov-east-1:206278770380:rulespackage/0-vlgEGcVD'],
                 "us-gov-west-1": ['arn:aws-us-gov:inspector:us-gov-west-1:850862329162:rulespackage/0-4oQgcI4G',
                                  'arn:aws-us-gov:inspector:us-gov-west-1:850862329162:rulespackage/0-Ac4CFOuc',
                                  'arn:aws-us-gov:inspector:us-gov-west-1:850862329162:rulespackage/0-rOTGqe5G']}
rule_package_account_ids = {"us-west-1" : '166987590008',
                        "us-west-2" :'758058086616',
                        "us-east-1":'316112463485',
                        "us-east-2":'646659390643',
                        "us-gov-east-1":'206278770380',
                        "us-gov-west-1":'850862329162'}



#---------------------------------------------------------------------------
def main(argv):
    try:
        session_name=__file__.split('.py')[0].replace('/', '_')
        #inspector_name='vaec-inspector-'+args.remote_account_id

        target_name=inspector_name+"-target-1"
        template_name=inspector_name+"-template-1"
        if args.action=="check":
            sessionmod.iterate_accounts_regions(check_aws_inspector,
                                    args.remote_account_id,
                                    args.region_id,
                                    args.remote_role,
                                    target_name,
                                    template_name,
                                    session_name)
        elif args.action=="enable":
            sessionmod.iterate_accounts_regions(enable_aws_inspector,
                                    args.remote_account_id,
                                    args.region_id,
                                    args.remote_role,
                                    args.sns_topic_name,
                                    args.sns_email_subscriber,
                                    args.enable_inspector_tags,
                                    target_name,
                                    template_name,
                                    session_name)
            function_name=enable_aws_inspector
        elif args.action=="delete":
            sessionmod.iterate_accounts_regions(delete_aws_inspector,
                                    args.remote_account_id,
                                    args.region_id,
                                    args.remote_role,
                                    args.sns_topic_name,
                                    args.sns_email_subscriber,
                                    target_name,
                                    template_name,
                                    session_name)


    except ClientError as ex:
        print(ex)
        raise ex


def enable_aws_inspector(remote_account_id,
                        region_id,
                        remote_role,
                        sns_topic_name,
                        sns_email_subscriber,
                        enable_inspector_tags,
                        target_name,
                        template_name,
                        session_name):
    try:
        logger.debug("Enabling AWS Inspector in Remote account: %s Region: %s" % (remote_account_id, region_id))

        ssm_session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        session_name, region_id)
        #sns_topic_name='vaec-aws-inspector'+remote_account_id
        sns_client = ssm_session_assumed.client('sns')
        sns_topic_arn=create_sns_topic(sns_client, sns_topic_name, remote_account_id, sns_email_subscriber,region_id)


        if not is_aws_inspector_assessment_template_exists(ssm_session_assumed, target_name, template_name):
            logger.info("#-------AWS Inspector template <%s> don't exist in Account:%s Region:%s ------- Creating a new one" % (template_name, remote_account_id, region_id))

            create_aws_inspector_assessment(ssm_session_assumed,
                                            target_name,
                                            template_name,
                                            sns_topic_arn,
                                            enable_inspector_tags,
                                            region_id)
            logger.info("#-------Successfully created a new AWS Inspector template and target in Account:%s Region:%s -------" % (remote_account_id, region_id))
    except ClientError as ex:
        logger.exception(ex)
        raise ex


def check_aws_inspector(remote_account_id,
                        region_id,
                        remote_role,
                        target_name,
                        template_name,
                        session_name):
    try:
        logger.debug("Remote account: %s Region: %s" % (remote_account_id, region_id))

        ssm_session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        session_name, region_id)
        inspector_client = ssm_session_assumed.client('inspector')

        if is_aws_inspector_assessment_template_exists(ssm_session_assumed,target_name,template_name):
            logger.info("#------- AWS Inspector assessment template <%s> already exist in Account:%s Region:%s -------" % (template_name, remote_account_id, region_id))
        else:
            logger.info("#------- AWS Inspector assessment template <%s> does not exist in Account:%s Region:%s -------" % (template_name, remote_account_id, region_id))
        #logger.info("#------- Account:%s Region:%s -------" % (remote_account_id, region_id))
    except ClientError as ex:
        logger.exception(ex)
        raise ex

def is_aws_inspector_assessment_template_exists(ssm_session_assumed, target_name,template_name):
    returnValue=None;

    try:
        inspector_client = ssm_session_assumed.client('inspector')
        #response = inspector_client.list_assessment_templates(filter={
        #                                'namePattern': template_name})
        response = inspector_client.list_assessment_targets(
                                        #filter={'assessmentTargetNamePattern': 'string'}
                                            )

        #print(response['assessmentTargetArns'])
        if response['assessmentTargetArns']:
            response = inspector_client.list_assessment_templates(assessmentTargetArns=response['assessmentTargetArns'],
                    filter={'namePattern': template_name})

            #print(response['assessmentTemplateArns'])

            if response['assessmentTemplateArns']:
                logger.info("<<<<<<<<< Assessment template already exist, name:%s, ARN:%s", template_name, response['assessmentTemplateArns'][0])
                returnValue=response['assessmentTemplateArns'][0]

        # for template in response['assessmentTemplates'] :
        #     if template['name'] == template_name:
        #         logger.info("<<<<<<<<< Assessment template already exist, name:%s, arn:%s, targetArn: %s", template['name'], template['arn'], template['assessmentTargetArn'])
        #         returnValue=True
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return returnValue

def create_sns_topic(sns_client, sns_topic_name, remote_account_id, email_address, region_id):
    snsTopicArn=None
    try:
        returnDict=is_sns_topic_exists(sns_client, sns_topic_name, remote_account_id, email_address)
        if returnDict['existFlag']:
            snsTopicArn = returnDict['topicArn']
        else:
            logger.info("<<<<<<<<< SNS topic %s don't exist, creating a new one")
            response_sns = sns_client.create_topic(
                                            Name=sns_topic_name,
                                            # Attributes={
                                            #      'KmsMasterKeyId': 'alias/aws/sns'
                                            #  },
                                            Tags=[
                                                {
                                                    'Key': 'Name',
                                                    'Value': sns_topic_name
                                                },
                                                {
                                                    'Key': 'vaec:managed-by',
                                                    'Value': 'ECS'
                                                }
                                            ]
                                        )
            snsTopicArn = response_sns['TopicArn']
            response_sub = sns_client.subscribe(
                        TopicArn=response_sns['TopicArn'],
                        Protocol='email',
                        Endpoint=email_address,
                        # Attributes={
                        #      'Policy ': 'string'
                        # },
                        ReturnSubscriptionArn= False
                    )
            response_perm = sns_client.add_permission(
                            TopicArn=response_sns['TopicArn'],
                            Label=remote_account_id,
                            AWSAccountId=[
                                remote_account_id,
                            ],
                            ActionName=[
                                'Publish','Subscribe'
                            ]
                        )
            response_perm = sns_client.add_permission(
                            TopicArn=response_sns['TopicArn'],
                            Label=rule_package_account_ids[region_id],
                            AWSAccountId=[
                                rule_package_account_ids[region_id],
                            ],
                            ActionName=[
                                'Publish'
                            ]
                        )
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return snsTopicArn

def is_sns_topic_exists(sns_client, sns_topic_name, remote_account_id, email_address):

    token=None
    returnValue=False;
    returnDict={'existFlag':False, 'topicArn':None}
    try:

        response_sns_topics = sns_client.list_topics()
        #print(response_sns_topics)
        for sns_topic in response_sns_topics['Topics']:
            #print(sns_topic)
            response_tags = sns_client.list_tags_for_resource(
                                            ResourceArn=sns_topic['TopicArn'])
            #print(response_tags)
            for tag in response_tags['Tags']:
                if tag['Key'] == 'Name' :
                    if tag['Value'] == sns_topic_name:
                        returnDict['existFlag']=True;
                        returnDict['topicArn']=sns_topic['TopicArn'];
                    break
            if returnDict['existFlag']:
                logger.info("<<<<<<<<< SNS topic %s already exist, topicArn:%s", sns_topic_name, sns_topic['TopicArn'] )
                break
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return returnDict

def create_aws_inspector_assessment(ssm_session_assumed,
                                    target_name,
                                    template_name,
                                    sns_topic_arn,
                                    enable_inspector_tags,
                                    region_id):

    try:

        #create_aws_inspector_assessment_target(inspector_client, target_name)
        create_aws_inspector_assessment_template(ssm_session_assumed,
                                                target_name,template_name,
                                                sns_topic_arn,
                                                enable_inspector_tags,
                                                region_id)

    except ClientError as ex:
        logger.exception(ex)
        raise ex

def create_aws_inspector_assessment_target(inspector_client, assessment_target_name, enable_inspector_tags):
    targetArn=None
    api_response=None
    try:

        response = inspector_client.list_assessment_targets(
                                                filter={'assessmentTargetNamePattern': assessment_target_name}
                                                    )
        #print(response['assessmentTargetArns'])
        if response['assessmentTargetArns']:
            targetArn=response['assessmentTargetArns'][0]
        else:
            if enable_inspector_tags:
                response = inspector_client.create_resource_group(
                                                resourceGroupTags=[
                                                    {
                                                        'key': 'vaec:inspector-gss',
                                                        #'key': 'Inspector-GSS',
                                                        'value': 'true'
                                                    },
                                                ]
                                            )
                api_response = inspector_client.create_assessment_target(
                                assessmentTargetName=assessment_target_name,
                                resourceGroupArn=response['resourceGroupArn']
                                )
            else:
                api_response = inspector_client.create_assessment_target(
                                assessmentTargetName=assessment_target_name,
                                resourceGroupArn=response['resourceGroupArn']
                                )
            targetArn=api_response['assessmentTargetArn']
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return targetArn

def create_aws_inspector_assessment_template(ssm_session_assumed, target_name,template_name, sns_topic_arn, enable_inspector_tags, region_id):

    response_template=None
    roleArn=None
    try:
        #response_sns_topic=create_sns_topic(sns_client, sns_topic_name)
        inspector_client = ssm_session_assumed.client('inspector')
        targetArn=create_aws_inspector_assessment_target(inspector_client, target_name, enable_inspector_tags)
        response_template = inspector_client.create_assessment_template(
                            assessmentTargetArn=targetArn,
                            assessmentTemplateName=template_name,
                            durationInSeconds=3600,
                            rulesPackageArns=rule_package_arn[region_id],
                            # userAttributesForFindings=[
                            #     {
                            #         'key': 'vaec:managed-by',
                            #         'value': 'ECS'
                            #     }
                            #  ]
                           )
        roleArn=is_role_exist(ssm_session_assumed, template_name)
        if not roleArn:
            logger.info("IAM Event role does not exist creating new one")
            roleArn=create_iam_role_for_assesment_event(template_name,ssm_session_assumed)

        create_assesment_event(response_template['assessmentTemplateArn'],
                                template_name,
                                roleArn,
                                ssm_session_assumed)

        response_subscribe = inspector_client.subscribe_to_event(
                            resourceArn=response_template['assessmentTemplateArn'],
                            event='FINDING_REPORTED',
                            topicArn=sns_topic_arn
                        )
        # response_subscribe = inspector_client.subscribe_to_event(
        #                     resourceArn=response_template['assessmentTemplateArn'],
        #                     event='ASSESSMENT_RUN_STARTED',
        #                     topicArn=sns_topic_arn
        #                 )
        # response = inspector_client.start_assessment_run(
        #                 assessmentTemplateArn=response_template['assessmentTemplateArn'],
        #                 assessmentRunName=template_name+"-run"
        #             )

    except ClientError as ex:
        logger.exception(ex)
        raise ex

def create_assesment_event(inspector_assessment_template_arn,
                           template_name,
                           roleArn,
                           ssm_session_assumed):

    #event_rule_name= template_name+"-events-rule-1"
    event_rule_name= inspector_name+"-events-rule-1"
    events_client = ssm_session_assumed.client('events')
    try:

        response = events_client.put_rule(
                        Name=event_rule_name,
                        ScheduleExpression='rate(7 days)',
                        #EventPattern='string',
                        State='ENABLED',
                        Description='VAEC-Event-Rule for Inspector Assessesment'
                    )
        response = events_client.put_targets(
                            Rule=event_rule_name,
                            Targets=[
                                {
                                    'Id': event_rule_name,
                                    'Arn': inspector_assessment_template_arn,
                                    'RoleArn': roleArn,
                                    #'Input': 'string',
                                    #'InputPath': 'string',
                                }])
    except ClientError as ex:
        logger.exception(ex)
        raise ex

def is_assesement_event_rule_exist(template_name,
                           ssm_session_assumed):

    event_rule_name= inspector_name+"-events-rule-1"
    returnValue=False
    ruleArn=None
    try:
        events_client = ssm_session_assumed.client('events')
        response = events_client.list_rules(
                            NamePrefix=event_rule_name,
                        )
        for rule in response['Rules']:
            if rule['Name'] == event_rule_name:
                returnValue=True
                ruleArn=rule['Arn']
                break
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return ruleArn

def is_assesement_event_target_exist(inspector_assessment_template_arn,
                           template_name,
                           ssm_session_assumed):

    event_rule_name= inspector_name+"-events-rule-1"
    returnValue=False
    targetArn=None
    try:
        events_client = ssm_session_assumed.client('events')
        response = events_client.list_targets_by_rule(
                            NamePrefix=event_rule_name,
                        )
        for target in response['Targets']:
            if target['Id'] == event_rule_name:
                returnValue=True
                targetArn=target['Arn']
                break
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return targetArn


def delete_assesment_event_rule(template_name,
                           ssm_session_assumed):

    event_rule_name= inspector_name+"-events-rule-1"


    try:
        events_client = ssm_session_assumed.client('events')
        event_rule_arn=is_assesement_event_rule_exist(template_name,ssm_session_assumed)
        if event_rule_arn:
            logger.info("Event rule %s exist. Deleting it, removing targets" % (event_rule_name))
            response = events_client.remove_targets(
                        Rule=event_rule_name,
                        Ids=[
                            event_rule_name,
                        ]
                    )
            logger.info("Deleting event rule %s" % (event_rule_name))
            response = events_client.delete_rule(
                            Name=event_rule_name
                            )
        else:
            logger.info("Event rule <%s> does not exist. doing nothing" % (event_rule_name))
    except ClientError as ex:
        logger.exception(ex)
        raise ex

def create_iam_role_for_assesment_event(template_name,
                        ssm_session_assumed):

    roleArn:None
    try:
        role_name= inspector_name+"-events-role"
        iam_client = ssm_session_assumed.client('iam')
        response = iam_client.create_role(
                    Path='/vaec/',
                    RoleName=role_name,
                    AssumeRolePolicyDocument='{"Version": "2008-10-17","Statement": [{"Effect": "Allow","Principal": {"Service": "events.amazonaws.com"},"Action": "sts:AssumeRole"}]}',
                    Description='Event role for scheduling AWS assessement run',
                    Tags=[
                        {
                            'Key': 'vaec:managed-by',
                            'Value': 'ECS'
                        },
                    ]
                    )
        roleArn=response['Role']['Arn']
        response = iam_client.put_role_policy(
                        RoleName=role_name,
                        PolicyName=template_name+"-event-rule-inline-policy",
                        PolicyDocument='{"Version":"2012-10-17","Statement":{"Effect":"Allow","Action":"inspector:StartAssessmentRun","Resource":"*"}}',
                    )
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return roleArn

def is_role_exist(ssm_session_assumed,
                    template_name):
    roleArn=None
    role_name= inspector_name+"-events-role"
    logger.info("Checking whether role %s exist" % (role_name))
    returnValue=False
    try:
        iam_client = ssm_session_assumed.client('iam')
        response = iam_client.get_role(
                        RoleName=role_name
                        )

        roleArn = response['Role']['Arn']
    except ClientError as ex:
        #logger.exception(ex)
        logger.info("Role %s does not exist" % (role_name))
        #raise ex
    return roleArn


def delete_aws_inspector(remote_account_id,
                        region_id,
                        remote_role,
                        sns_topic_name,
                        sns_email_subscriber,
                        target_name,
                        template_name,
                        session_name):
    try:
        logger.debug("Enabling AWS Inspector in Remote account: %s Region: %s" % (remote_account_id, region_id))

        ssm_session_assumed = sessionmod.aws_session(
                        ("arn:aws-us-gov:iam::%s:role/%s" %(remote_account_id, remote_role)),
                        session_name, region_id)
        #sns_topic_name='vaec-aws-inspector'+remote_account_id
        delete_assesment_event_rule(template_name,ssm_session_assumed)

        roleArn=is_role_exist(ssm_session_assumed, template_name)
        role_name=inspector_name+"-events-role"
        if roleArn:
            policy_name=inspector_name+"-event-rule-inline-policy"

            iam_client = ssm_session_assumed.client('iam')
            response = iam_client.delete_role_policy(
                            RoleName=role_name,
                            PolicyName=policy_name
                        )

            response = iam_client.delete_role(
                            RoleName=role_name)
        else:
            logger.info("Assessment event IAM role <%s> does not exist. doing nothing" % (role_name))
        sns_client = ssm_session_assumed.client('sns')
        returnDict=is_sns_topic_exists(sns_client, sns_topic_name, remote_account_id, sns_email_subscriber)
        if returnDict['existFlag']:
            response = sns_client.delete_topic(
                                TopicArn=returnDict['topicArn']
                            )
        else:
            logger.info("<<<<<<<<< SNS topic %s don't exist. Nothing to delete", sns_topic_name)

        inspector_client = ssm_session_assumed.client('inspector')
        templateArn=is_aws_inspector_assessment_template_exists(ssm_session_assumed, target_name, template_name)
        if templateArn:
            logger.info("#-------AWS Inspector template <%s> exist in Account:%s Region:%s ------- Deleting it..." % (template_name, remote_account_id, region_id))
            response = inspector_client.describe_assessment_templates(assessmentTemplateArns=[templateArn])
            targetArn=response['assessmentTemplates'][0]['assessmentTargetArn']
            response = inspector_client.delete_assessment_template(assessmentTemplateArn=templateArn)
            if targetArn:
                response = inspector_client.delete_assessment_target(assessmentTargetArn=targetArn)
            logger.info("#-------Successfully deleted AWS Inspector template and target in Account:%s Region:%s -------" % (remote_account_id, region_id))
        else:
            logger.info("<<<<<<<<< Inspector template %s don't exist. Nothing to delete", template_name)
    except ClientError as ex:
        logger.exception(ex)
        raise ex

if __name__== "__main__":
  main(sys.argv)
