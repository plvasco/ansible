#!/bin/bash
# Legacy script - no longer in use since early-2020

# -------------- Manual instructions in Splunk UI ----------------------
# 1.	Log into Splunk Heavy Forwarder
#    -	EnterpriseSecurity:SplunkHeavyForwarder01 (10.247.2.57)
#    -	http://10.247.2.57:8000
#    -	UserID = admin, password documented with VAEC credentials
#    -	Since port 8000 is not open, access would be via Windows jumpbox account, or RDP tunneling via SSH port forward on Unix Jump boxes
# 2.	Select “Splunk Add-on for AWS” app on the left.
# 3.	Select “Configuration”.
# 4.	Select “IAM Role”.
# 5.	Clone an existing IAM role such as “VAEC_core_gov_internal”.
# 6.	Replace account ID with new account ID and name according to naming standard.
#     -	Be sure to verify the Role name – new accounts have arn:aws-us-gov:iam::<AccountId>:role/vaec-splunk-role
# 7.	Click Save.
# 8.	Select “Inputs”.
# 9.	Clone an existing input such as “VAEC_core_gov_internal”
# 10.	Name the input following the naming standard.
# 11.	Be sure to verify the Role name – new accounts have vaec-splunk-role
# 12.	Under “Assume Role”, select the role you just created.
# 13.	Leave all other fields as default and select save.

# -------------- Automation of the above ----------------------
# ssh to 10.247.2.57, sudo to ec2-user and execute the following:
# ./awsacct.sh "uid:pass" <acctname> <awsacctid>
#  acctname = vaec_proj instead of vaec-proj (use _ instead of -)

uidpw=$1
acctname=$2
acctid=$3

## [A] Add IAM role
curl -k -u $uidpw https://localhost:8089/servicesNS/nobody/Splunk_TA_aws/splunk_ta_aws_iam_roles \
-d name=$acctname \
-d arn=arn:aws-us-gov:iam::$acctid:role/vaec-splunk-role

## [B] Add input
curl -k -u $uidpw https://localhost:8089/servicesNS/nobody/Splunk_TA_aws/splunk_ta_aws_aws_description \
-d name=${acctname}_Description \
-d apis="ec2_volumes/3600, ec2_instances/3600, ec2_reserved_instances/3600, ebs_snapshots/3600, classic_load_balancers/3600, application_load_balancers/3600, vpcs/3600, vpc_network_acls/3600, vpc_subnets/3600, rds_instances/3600, ec2_key_pairs/3600, ec2_security_groups/3600, ec2_images/3600, ec2_addresses/3600, lambda_functions/3600, s3_buckets/3600, iam_users/3600" \
-d account=VAEC-Splunk-Role \
-d aws_iam_role=$acctname \
-d index=aws-description \
-d regions=us-gov-west-1 \
-d sourcetype=aws:description
