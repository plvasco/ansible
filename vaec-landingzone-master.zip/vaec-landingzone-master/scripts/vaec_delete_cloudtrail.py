import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_delete_cloudtrail.py --nodryrun
#python3 vaec_delete_cloudtrail.py --account-id all --region us-gov-east-1 --trail-to-delete "xyz,abc" --nodryrun 
#python3 vaec_delete_cloudtrail.py --account-id 477194928391,272417811699 --trail-to-delete "xyz,abc" --nodryrun

parser = argparse.ArgumentParser(description='VAEC delete CloudTrail')
parser.add_argument('--account-id', dest='remote_account_id', required=True, help='all or comma separated list of account-ids')
parser.add_argument('--region', dest='region_id', default='us-gov-west-1', help='all or region-id')
parser.add_argument('--trail-to-delete', dest='trail_to_delete', required=True, help='comma separated list of trails to delete')
parser.add_argument('--skip-account-id', dest='skip_account_id', default='348286891446', help='Comma-separated list of account-ids to skip')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
args = parser.parse_args()

ct_to_delete_list = [t.strip() for t in args.trail_to_delete.split(',')]
skip_account_list = [s.strip() for s in args.skip_account_id.split(',')]

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        sessionmod.iterate_orgs_accounts(fn_ct_delete, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_ct_delete(acctid, region):
    try:
        if acctid in skip_account_list:
            logger.info("%s %s skipped" % (acctid, region))
            return

        session_assumed = sessionmod.aws_session3(acctid, region)
        ctc = session_assumed.client('cloudtrail')
        paginator = ctc.get_paginator('list_trails')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            for t in page['Trails']:
                if t['Name'] in ct_to_delete_list:
                    trail_acctid = t['TrailARN'].split(':')[4]
                    if trail_acctid == acctid:
                        logger.info("[Dryrun=%s] deleting %s" %(args.to_dryrun, t['TrailARN']))
                        if not args.to_dryrun:
                            response = ctc.delete_trail(Name=t['TrailARN'])
                    else:
                        logger.error("[Dryrun=%s] cannot delete %s, belongs to account %s" %(args.to_dryrun, t['TrailARN'], trail_acctid))

    except Exception as ex:
        logger.error(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
