import argparse
import boto3
import sessionmod
from botocore.exceptions import ClientError
import logging

## Module defaults
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

parser = argparse.ArgumentParser(description='Manage AWS Config Recorder and configure Delivery Channel')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or comma-separated list of account-id')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
parser.add_argument('--action', dest='action', default='check', choices=['create', 'update', 'check', 'delete'], help='create, update, check, delete. Default = check')
parser.add_argument('--config-role-name', dest='config_role_name', default='vaec/vaec-awsconfig', help='Config role ARN')
parser.add_argument('--s3-bucket-name', dest='s3_bucket_name', default='vaec-awsconfig-logs', help='Config recorder delivery channel-centralized s3 bucket name in security-logs-internal account')
parser.add_argument('--delivery-frequency', dest='delivery_frequency', default='Three_Hours', choices=['One_Hour', 'Three_Hours', 'Six_Hours', 'Twelve_Hours', 'TwentyFour_Hours'], help='Config snapshot delivery frequency')

args = parser.parse_args()

#---------------------------------------------------------------------------
def main():
    try:
        sessionmod.iterate_orgs_accounts(fn_aws_config, args.remote_account_id, args.region_id)
    except Exception as ex:
        raise ex

#---------------------------------------------------------------------------
def fn_aws_config(remote_account_id, region_id):
    try:
        partition=sessionmod.get_partition(region_id)
        config_role_arn = ("arn:%s:iam::%s:role/%s" %(partition, remote_account_id, args.config_role_name))

        include_global_resource_types=False
        if region_id == sessionmod.get_primary_region(partition):
            include_global_resource_types=True

        session_assumed = sessionmod.aws_session3(remote_account_id, region_id)
        config_client = session_assumed.client('config')

        if args.action == 'create':
            if is_valid_iam_role(session_assumed, remote_account_id, region_id, config_role_arn):
                create_aws_config(remote_account_id, region_id, config_client, config_role_arn, args.s3_bucket_name, args.delivery_frequency, include_global_resource_types)

        elif args.action == 'update':
            if is_valid_iam_role(session_assumed, remote_account_id, region_id, config_role_arn):
                update_aws_config(remote_account_id, region_id, config_client, config_role_arn, args.s3_bucket_name, args.delivery_frequency, include_global_resource_types)

        elif args.action == 'delete':
            delete_aws_config(remote_account_id, region_id, config_client, config_role_arn, args.s3_bucket_name, args.delivery_frequency)

        elif args.action == 'check':
            check_aws_config(remote_account_id, region_id, config_client)

    except Exception as ex:
        raise ex

#---------------------------------------------------------------------------
def is_valid_iam_role(session_assumed, remote_account_id, region_id, config_role_arn):
    is_valid_role=False
    try:
        iamc = session_assumed.client('iam')

        paginator = iamc.get_paginator('list_roles')
        page_iterator = paginator.paginate(PathPrefix='/vaec/')
        for page in page_iterator:
            for role in page['Roles']:
                if role['Arn'] == config_role_arn:
                    is_valid_role=True
                    break
    except ClientError as ex:
        logger.exception(ex)
        raise ex

    if is_valid_role:
        logger.info("%s %s Valid Role ARN: %s" % (region_id, remote_account_id, config_role_arn))
    else:
        logger.info("%s %s Invalid Role ARN: %s" % (region_id, remote_account_id, config_role_arn))
    return is_valid_role

#---------------------------------------------------------------------------
def create_aws_config(remote_account_id, region_id, config_client, config_role_arn, s3_bucket_name, delivery_frequency, include_global_resource_types):
    try:
        recorder_name='vaec-config-recorder-'+remote_account_id
        recorder_response = config_client.describe_configuration_recorders()
        if recorder_response['ConfigurationRecorders']:
            logger.info("%s %s AWS Config Recorder exists, updating" % (region_id, remote_account_id))
            update_aws_config(remote_account_id,
                                  region_id,
                                  config_client,
                                  config_role_arn,
                                  s3_bucket_name,
                                  delivery_frequency, include_global_resource_types)
            return
        else:
            logger.info("%s %s AWS Config Recorder not found, creating." % (region_id, remote_account_id))
            create_aws_config_recorder(config_client,
                                       recorder_name,
                                       config_role_arn,
                                       s3_bucket_name,
                                       delivery_frequency, include_global_resource_types)
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def update_aws_config(remote_account_id, region_id, config_client, config_role_arn, s3_bucket_name, delivery_frequency, include_global_resource_types):
    try:

        recorder_name='vaec-config-recorder-'+remote_account_id
        recorder_response = config_client.describe_configuration_recorders()
        if recorder_response['ConfigurationRecorders']:
            #Record already exist
            for recorder in recorder_response['ConfigurationRecorders']:
                recorder_status_response = config_client.describe_configuration_recorder_status(
                                                ConfigurationRecorderNames=[recorder['name']])
                recorder_status=recorder_status_response['ConfigurationRecordersStatus'][0]
                update_aws_config_recorder(config_client,
                                               recorder,
                                               recorder_status,
                                               recorder_name,
                                               config_role_arn,
                                               s3_bucket_name,
                                               delivery_frequency, include_global_resource_types)

                #logger.info("%s %s AWS Config recorder is configured, Name: %s, Recording: %b, Operation Status: %s" % (region_id, remote_account_id, recorder_status['name'], recorder_status['lastStatus']))
        else:
            logger.info("%s %s AWS Config Recorder not found, cannot update." % (region_id, remote_account_id))
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def delete_aws_config(remote_account_id, region_id, config_client, config_role_arn, s3_bucket_name, delivery_frequency):
    try:
        recorder_name='vaec-config-recorder-'+remote_account_id
        recorder_response = config_client.describe_configuration_recorders()
        if recorder_response['ConfigurationRecorders']:
            #Record already exist
            for recorder in recorder_response['ConfigurationRecorders']:
                recorder_status_response = config_client.describe_configuration_recorder_status(
                                                ConfigurationRecorderNames=[recorder['name']])
                #print(recorder_status_response)
                recorder_status=recorder_status_response['ConfigurationRecordersStatus'][0]
                delete_aws_config_recorder(config_client,
                                               recorder,
                                               recorder_status,
                                               recorder_name,
                                               config_role_arn,
                                               s3_bucket_name,
                                               delivery_frequency)

                #logger.info("%s %s AWS Config recorder is configured, Name: %s, Recording: %b, Operation Status: %s" % (region_id, remote_account_id, recorder_status['name'], recorder_status['lastStatus']))
        else:
            logger.info("%s %s AWS Config Recorder not found, cannot delete." % (region_id, remote_account_id))

    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def check_aws_config(remote_account_id, region_id, config_client):
    try:
        recorder_response = config_client.describe_configuration_recorders()

        if recorder_response['ConfigurationRecorders']:
            name='vaec-config-recorder-'+remote_account_id
            del_channel_response = config_client.describe_delivery_channels()
            del_channel=del_channel_response['DeliveryChannels'][0]

            for recorder in recorder_response['ConfigurationRecorders']:
                recorder_status_response = config_client.describe_configuration_recorder_status(
                                                ConfigurationRecorderNames=[recorder['name']])
                recorder_status=recorder_status_response['ConfigurationRecordersStatus'][0]
                if recorder_status['recording']:
                    logger.info("%s %s AWS Config Recorder is enabled - Name: %s, Recorder status: %r, Operation Status: %s, Role ARN: %s, s3Bucket: %s, Delivery Frequency: %s" \
                                 % (remote_account_id, region_id, \
                                 recorder_status['name'], \
                                 recorder_status['recording'], \
                                 recorder_status['lastStatus'], \
                                 recorder['roleARN'], \
                                 del_channel['s3BucketName'],
                                 del_channel.get('configSnapshotDeliveryProperties',{}).get('deliveryFrequency', None)))
                else:
                    logger.info("%s %s AWS Config Recorder is NOT enabled - Name: %s, Recorder status: %r -------" \
                                     % (remote_account_id, region_id, \
                                     recorder_status['name'], \
                                     recorder_status['recording']))
        else:
            logger.info("%s %s AWS Config Recorder not found" % (region_id, remote_account_id))
    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def is_aws_config_recorder_enabled(config_client):
    returnValue=False
    try:
        response = config_client.describe_configuration_recorder_status()
        #print(response)
        for recorder in response['ConfigurationRecordersStatus']:
            if recorder['recording'] == True:
                returnValue=True
                break
    except ClientError as ex:
        logger.exception(ex)
        raise ex
    return returnValue

#---------------------------------------------------------------------------
def create_aws_config_recorder(config_client,
                               recorder_name,
                               config_role_arn,
                               s3_bucket_name,
                               delivery_frequency, include_global_resource_types):

    try:
        logger.info("Creating Config Recorder: " + config_role_arn)
        response = config_client.put_configuration_recorder(
                                    ConfigurationRecorder={
                                        'name': recorder_name,
                                        'roleARN': config_role_arn,
                                        'recordingGroup': {
                                            'allSupported': True,
                                            'includeGlobalResourceTypes': include_global_resource_types
                                        }
                                    }
                                )

        logger.info("Creating Delivery Channel: " + s3_bucket_name)
        response = config_client.put_delivery_channel(
                                DeliveryChannel={
                                    'name': "vaec-delivery-channel",
                                    's3BucketName': s3_bucket_name,
                                    'configSnapshotDeliveryProperties': {
                                        'deliveryFrequency': delivery_frequency
                                    }
                                }
                            )
        logger.info("Starting Recorder: " + recorder_name)
        response = config_client.start_configuration_recorder(ConfigurationRecorderName=recorder_name)
                            #'deliveryFrequency': 'One_Hour'|'Three_Hours'|'Six_Hours'|'Twelve_Hours'|'TwentyFour_Hours'

    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def update_aws_config_recorder(config_client,
                               existing_config_recorder,
                               recorder_status,
                               recorder_name,
                               config_role_arn,
                               s3_bucket_name,
                               delivery_frequency, include_global_resource_types):

    try:
        logger.info("Updating existing AWS Config Recorder: %s", existing_config_recorder['name'])
        #if not existing_config_recorder['roleARN'] == config_role_arn or not recorder_status['recording']:

        if not existing_config_recorder['roleARN'] == config_role_arn:
            logger.info("\tReplace IAM Role %s --> %s" %(existing_config_recorder['roleARN'], config_role_arn))
            response = config_client.put_configuration_recorder(
                                    ConfigurationRecorder={
                                        'name': existing_config_recorder['name'],
                                        'roleARN': config_role_arn,
                                        'recordingGroup': {
                                            'allSupported': True,
                                            'includeGlobalResourceTypes': include_global_resource_types
                                        }
                                    }
                                )

        del_channel_response = config_client.describe_delivery_channels()
        if del_channel_response['DeliveryChannels'] :
            del_channel=del_channel_response['DeliveryChannels'][0]
            status_response = config_client.describe_delivery_channel_status(DeliveryChannelNames=[del_channel['name']])
            #print(status_response['DeliveryChannelsStatus'])

            to_update_del_channel=False
            if status_response['DeliveryChannelsStatus'][0]['configStreamDeliveryInfo']['lastStatus']=='Failure':
                logger.info("\tDelivery Channel is in error status - recreating")
                to_update_del_channel=True

            if not del_channel['s3BucketName'] == s3_bucket_name:
                logger.info("\tDelivery Channel bucket updating %s -> %s" %(del_channel['s3BucketName'],s3_bucket_name))
                to_update_del_channel=True

            existing_delivery_frequency = del_channel.get('configSnapshotDeliveryProperties',{}).get('deliveryFrequency', None)
            if not existing_delivery_frequency == delivery_frequency:
                logger.info("\tDelivery frequency updating %s -> %s" %(existing_delivery_frequency, delivery_frequency))
                to_update_del_channel=True

            if to_update_del_channel:
                if recorder_status['recording']:
                    response = config_client.stop_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
                config_client.delete_delivery_channel(DeliveryChannelName=del_channel['name'])
                if 'snsTopicARN' in del_channel:
                    response = config_client.put_delivery_channel(
                                            DeliveryChannel={
                                                'name': del_channel['name'],
                                                's3BucketName': s3_bucket_name,
                                                'snsTopicARN': del_channel['snsTopicARN'],
                                                'configSnapshotDeliveryProperties': {
                                                    'deliveryFrequency': delivery_frequency
                                                }
                                            }
                                        )
                else:
                    response = config_client.put_delivery_channel(
                                            DeliveryChannel={
                                                'name': del_channel['name'],
                                                's3BucketName': s3_bucket_name,
                                                'configSnapshotDeliveryProperties': {
                                                    'deliveryFrequency': delivery_frequency
                                                }
                                            })

                    response = config_client.start_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
        else:
            #Delivery channel don't exist., Create one
            logger.info("\tDelivery Channel not found, creating one")
            response = config_client.put_delivery_channel(
                                    DeliveryChannel={
                                        'name': "vaec-delivery-channel",
                                        's3BucketName': s3_bucket_name,
                                        'configSnapshotDeliveryProperties': {
                                            'deliveryFrequency': delivery_frequency
                                        }
                                    }
                                )


        recorder_status_response = config_client.describe_configuration_recorder_status(
                                        ConfigurationRecorderNames=[existing_config_recorder['name']])
        recorder_status=recorder_status_response['ConfigurationRecordersStatus'][0]
        if not recorder_status['recording']:
            logger.info("\tRecording is OFF, turning it ON")
            response = config_client.start_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])

    except ClientError as ex:
        logger.exception(ex)
        raise ex

#---------------------------------------------------------------------------
def delete_aws_config_recorder(config_client,
                               existing_config_recorder,
                               recorder_status,
                               recorder_name,
                               config_role_arn,
                               s3_bucket_name,
                               delivery_frequency):

    try:
        logger.info("Deleting existing Config Recorder: %s", existing_config_recorder['name'])
        response = config_client.stop_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
        config_client.delete_configuration_recorder(ConfigurationRecorderName=existing_config_recorder['name'])
        #if not existing_config_recorder['roleARN'] == config_role_arn or not recorder_status['recording']:
        del_channel_response = config_client.describe_delivery_channels()

        if del_channel_response['DeliveryChannels'] :
            del_channel=del_channel_response['DeliveryChannels'][0]
            logger.info("\tDeleting existing Delivery Channel: %s", del_channel['name'])
            config_client.delete_delivery_channel(DeliveryChannelName=del_channel['name'])

    except ClientError as ex:
        logger.exception(ex)
        raise ex

if __name__== "__main__":
  main()
