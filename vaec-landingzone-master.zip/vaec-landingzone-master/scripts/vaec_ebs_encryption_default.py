import argparse
import boto3
import logging
import sessionmod

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO) #CRITICAL, ERROR, WARNING, DEBUG, NOTSET, INFO
out_hdlr = logging.StreamHandler()
out_hdlr.setFormatter(logging.Formatter('%(levelname)s %(message)s'))
logger.addHandler(out_hdlr)

#python3 vaec_ebs_encryption_default.py --nodryrun
#python3 vaec_ebs_encryption_default.py --account-id all --region us-gov-east-1 --nodryrun
#python3 vaec_ebs_encryption_default.py --account-id 477194928391,272417811699 --nodryrun --encryption disable

parser = argparse.ArgumentParser(description='VAEC enable_ebs_encryption_by_default')
parser.add_argument('--account-id', dest='remote_account_id', default='all', help='all or comma separated list of account-ids')
parser.add_argument('--nodryrun', dest='to_dryrun', action='store_false', default=True, help='Disable dryrun. Default is enabled')
parser.add_argument('--encryption', dest='to_encrypt', choices=['enable', 'disable'], default='enable', help='Encryption enable/disable')
parser.add_argument('--region', dest='region_id', default='all', help='all or region-id')
args = parser.parse_args()

to_encrypt=True
if args.to_encrypt == 'disable':
    to_encrypt=False

# ----------------------------------------------------------------
def main():
    try:
        # logger.debug(args)

        sessionmod.iterate_orgs_accounts(fn_enable_ebs_encryption, args.remote_account_id, args.region_id)

    except Exception as ex:
        logger.error(ex)
        raise(ex)

# ----------------------------------------------------------------
def fn_enable_ebs_encryption(acctid, region):
    try:
        session_assumed = sessionmod.aws_session3(acctid, region)

        ec2c = session_assumed.client('ec2')
        response = ec2c.get_ebs_encryption_by_default()
        logger.info('%s %s EbsEncryptionByDefault = %s' %(acctid, region, response['EbsEncryptionByDefault']))

        if not args.to_dryrun and response['EbsEncryptionByDefault'] != to_encrypt:
            response2={}
            if to_encrypt:
                response2 = ec2c.enable_ebs_encryption_by_default()
            elif not to_encrypt:
                response2 = ec2c.disable_ebs_encryption_by_default()
            logger.info('Set %s %s EbsEncryptionByDefault = %s' %(acctid, region, response2['EbsEncryptionByDefault']))

    except Exception as ex:
        logger.error(ex)

# ----------------------------------------------------------------
if __name__ == "__main__":
    main()
