# logs

Moved to [vaec-security-logs](https://github.ec.va.gov/AWS/vaec-security-logs) repository.
