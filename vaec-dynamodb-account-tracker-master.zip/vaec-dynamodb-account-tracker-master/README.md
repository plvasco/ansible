# vaec-dynamodb-account-tracker
Custom scripts to import CSV data into a custom VAEC DynamoDB table containing AWS Account information.
